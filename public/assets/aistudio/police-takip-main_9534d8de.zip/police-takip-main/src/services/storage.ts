import { AppData, Quote, Policy, CustomRule, QuoteStatus, QuoteStage, QUOTE_STAGES, COMPANIES, AuthorizedCompany } from '../types/insurance';

export const isStandardCompany = (name?: string): boolean => {
  if (!name) return false;
  return (COMPANIES as readonly string[]).includes(name.trim());
};

export const normalizeCompany = (
  rawName?: string
): { name: string; isStandard: boolean; wasNormalized: boolean } => {
  if (!rawName || !rawName.trim()) {
    return { name: COMPANIES[0], isStandard: true, wasNormalized: false };
  }
  const clean = rawName.trim();

  // 1. Exact match with the 13 authorized companies
  if ((COMPANIES as readonly string[]).includes(clean)) {
    return { name: clean, isStandard: true, wasNormalized: false };
  }

  // 2. Locale uppercase match
  const upper = clean.toLocaleUpperCase('tr-TR');
  if ((COMPANIES as readonly string[]).includes(upper)) {
    return { name: upper, isStandard: true, wasNormalized: true };
  }

  // 3. Known aliases and minor variations
  const simplified = upper
    .replace(/[\s\-_.]+/g, ' ')
    .replace(/SIGORTA/g, 'SİGORTA')
    .trim();

  if (simplified.includes('AK SİGORTA') || simplified === 'AK' || simplified === 'AKSIGORTA') {
    return { name: 'AK SİGORTA', isStandard: true, wasNormalized: true };
  }
  if (simplified.includes('ALLIANZ')) {
    return { name: 'ALLIANZ SİGORTA', isStandard: true, wasNormalized: true };
  }
  if (simplified.includes('ANADOLU')) {
    return { name: 'ANADOLU SİGORTA', isStandard: true, wasNormalized: true };
  }
  if (simplified.includes('AXA')) {
    return { name: 'AXA SİGORTA', isStandard: true, wasNormalized: true };
  }
  if (simplified.includes('DOĞA') || simplified.includes('DOGA')) {
    return { name: 'DOĞA SİGORTA', isStandard: true, wasNormalized: true };
  }
  if (simplified.includes('EUREKO')) {
    return { name: 'EUREKO SİGORTA', isStandard: true, wasNormalized: true };
  }
  if (simplified.includes('HDI')) {
    return { name: 'HDI SİGORTA', isStandard: true, wasNormalized: true };
  }
  if (simplified.includes('HEPIYI') || simplified.includes('HEPİYİ')) {
    return { name: 'HEPIYI SİGORTA', isStandard: true, wasNormalized: true };
  }
  if (simplified.includes('MAPFRE')) {
    return { name: 'MAPFRE SİGORTA', isStandard: true, wasNormalized: true };
  }
  if (simplified.includes('NEOVA')) {
    return { name: 'NEOVA SİGORTA', isStandard: true, wasNormalized: true };
  }
  if (simplified.includes('RAY SİGORTA') || simplified === 'RAY' || simplified === 'RAYSIGORTA') {
    return { name: 'RAY SİGORTA', isStandard: true, wasNormalized: true };
  }
  if (simplified.includes('SOMPO')) {
    return { name: 'SOMPO SİGORTA', isStandard: true, wasNormalized: true };
  }
  if (simplified.includes('TÜRKİYE') || simplified.includes('TURKIYE')) {
    return { name: 'TÜRKİYE SİGORTA', isStandard: true, wasNormalized: true };
  }

  // 4. Non-standard company name that cannot be matched to the 13 authorized companies.
  // DO NOT DELETE: return as-is with isStandard: false so user can be notified to manually edit!
  return { name: clean, isStandard: false, wasNormalized: false };
};

const STORAGE_KEY = 'sigorta_takip_pro_v2';
const LEGACY_KEY = 'policeYenilemeTakip_v1';

export const getTodayIso = (): string => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

export const addDays = (days: number, fromDate = new Date()): string => {
  const d = new Date(fromDate);
  d.setDate(d.getDate() + days);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

export const calculateDaysLeft = (dateString?: string): number | null => {
  if (!dateString) return null;
  const target = new Date(dateString + 'T00:00:00');
  if (isNaN(target.getTime())) return null;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return Math.round((target.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
};

export const formatCurrency = (val?: number): string => {
  if (val === undefined || val === null || isNaN(val)) return '0 ₺';
  return new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY', maximumFractionDigits: 0 }).format(val);
};

export const formatDateTr = (dateString?: string): string => {
  if (!dateString) return '—';
  const d = new Date(dateString + 'T00:00:00');
  if (isNaN(d.getTime())) return '—';
  return d.toLocaleDateString('tr-TR', { day: '2-digit', month: '2-digit', year: 'numeric' });
};

export const generateId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substring(2, 7);
};

export const getEffectiveQuoteStatus = (q: Quote): QuoteStatus => {
  if (q.quoteStatus) return q.quoteStatus;
  if (q.outcome === 'converted') return 'kabul_edildi';
  if (q.outcome === 'rejected') return 'reddedildi';
  return 'beklemede';
};

export const getQuoteStatusMeta = (status: QuoteStatus) => {
  switch (status) {
    case 'kabul_edildi':
      return {
        label: 'Kabul Edildi',
        badgeBg: 'bg-emerald-50 text-emerald-700 border-emerald-200',
        dot: 'bg-emerald-500',
        description: 'Müşteri teklifi onayladı ve poliçeleştirildi',
      };
    case 'reddedildi':
      return {
        label: 'Reddedildi',
        badgeBg: 'bg-rose-50 text-rose-700 border-rose-200',
        dot: 'bg-rose-500',
        description: 'Teklif olumsuz sonuçlandı / yapılmadı',
      };
    case 'beklemede':
    default:
      return {
        label: 'Beklemede',
        badgeBg: 'bg-amber-50 text-amber-700 border-amber-200',
        dot: 'bg-amber-500',
        description: 'Teklif değerlendirme sürecinde',
      };
  }
};

export const getQuoteProgressPercent = (q: Quote): number => {
  const status = getEffectiveQuoteStatus(q);
  if (status === 'kabul_edildi') return 100;
  if (status === 'reddedildi') return 0;

  switch (q.stage) {
    case 'Teklif Hazırlanıyor':
      return 20;
    case 'Müşteriye Sunuldu':
      return 40;
    case 'Fiyat Değerlendirmede':
      return 60;
    case 'İndirim İstendi':
      return 70;
    case 'İndirim Alındı':
      return 80;
    case 'Müşteri Onayı Bekleniyor':
      return 90;
    default:
      return 30;
  }
};

export const sanitizeQuoteData = (q: any): Quote => {
  const {
    tax,
    tckn,
    tc,
    tcKimlik,
    tcNo,
    kimlikNo,
    vkn,
    birthDate,
    birthdate,
    birth_date,
    dogumTarihi,
    dogum_tarihi,
    identityNumber,
    ...clean
  } = q || {};

  const normCo = normalizeCompany(clean.company);

  const cleanAlternatives = Array.isArray(clean.alternatives)
    ? clean.alternatives.map((alt: any) => ({
        ...alt,
        company: normalizeCompany(alt.company).name,
      }))
    : undefined;

  return {
    ...clean,
    insured: clean.insured || '',
    phone: clean.phone || '', // preserved from existing records if present, never required
    email: clean.email || '',
    company: normCo.name,
    plate: clean.plate ? String(clean.plate).toLocaleUpperCase('tr-TR').replace(/[ .-]/g, '') : '',
    vehicleBrand: clean.vehicleBrand || '',
    vehicleModel: clean.vehicleModel || '',
    vehicleYear: clean.vehicleYear || '',
    vehicleDetail: clean.vehicleDetail || '',
    alternatives: cleanAlternatives,
  } as Quote;
};

export const sanitizePolicyData = (p: any): Policy => {
  const {
    tax,
    tckn,
    tc,
    tcKimlik,
    tcNo,
    kimlikNo,
    vkn,
    birthDate,
    birthdate,
    birth_date,
    dogumTarihi,
    dogum_tarihi,
    identityNumber,
    ...clean
  } = p || {};

  const normCo = normalizeCompany(clean.company);

  return {
    ...clean,
    insured: clean.insured || '',
    phone: clean.phone || '', // preserved from existing records if present, never required
    email: clean.email || '',
    company: normCo.name,
    plate: clean.plate ? String(clean.plate).toLocaleUpperCase('tr-TR').replace(/[ .-]/g, '') : '',
    vehicleBrand: clean.vehicleBrand || '',
    vehicleModel: clean.vehicleModel || '',
    vehicleYear: clean.vehicleYear || '',
    vehicleDetail: clean.vehicleDetail || '',
  } as Policy;
};

export const generateSampleData = (): AppData => {
  const todayStr = getTodayIso();

  const quotes: Quote[] = [
    {
      id: 'q-1',
      type: 'quote',
      insured: 'Ahmet Yılmaz',
      email: 'ahmet.yilmaz@gmail.com',
      plate: '34ABC99',
      vehicleBrand: 'Volkswagen',
      vehicleModel: 'Golf 1.5 eTSI Style',
      vehicleYear: 2022,
      vehicleDetail: '2022 Volkswagen Golf 1.5 eTSI',
      company: 'ALLIANZ SİGORTA',
      branch: 'Kasko',
      quoteNumber: 'TK-2026-081',
      quoteDate: addDays(-2),
      validUntil: addDays(5),
      premium: 22450,
      stage: 'Müşteriye Sunuldu',
      status: 'active',
      quoteStatus: 'beklemede',
      notes: 'Genişletilmiş kasko teklifi verildi. Allianz ve Axa karşılaştırıldı.',
      alternatives: [
        { company: 'AXA SİGORTA', premium: 23800, notes: 'Yetkili servis teminatlı' },
        { company: 'TÜRKİYE SİGORTA', premium: 20900, notes: 'Anlaşmalı özel servis' },
      ],
      createdAt: addDays(-2),
      updatedAt: addDays(-1),
      followDate: addDays(1),
    },
    {
      id: 'q-2',
      type: 'quote',
      insured: 'Selin Erdem',
      email: 'selin.erdem@outlook.com',
      plate: '06BJR44',
      vehicleBrand: 'Renault',
      vehicleModel: 'Clio 1.0 TCe Touch',
      vehicleYear: 2020,
      vehicleDetail: '2020 Renault Clio',
      company: 'TÜRKİYE SİGORTA',
      branch: 'Trafik',
      quoteNumber: 'TK-2026-094',
      quoteDate: addDays(-1),
      validUntil: addDays(12),
      premium: 9850,
      stage: 'Fiyat Değerlendirmede',
      status: 'active',
      quoteStatus: 'beklemede',
      notes: 'Trafik yenileme teklifi iletildi. Müşteri taksit seçeneklerini inceliyor.',
      createdAt: addDays(-1),
      updatedAt: addDays(-1),
    },
    {
      id: 'q-3',
      type: 'quote',
      insured: 'Mert Aksoy',
      email: 'mert.aksoy@sirket.com',
      company: 'ANADOLU SİGORTA',
      branch: 'Tamamlayıcı Sağlık (TSS)',
      quoteNumber: 'TK-2026-102',
      quoteDate: todayStr,
      validUntil: addDays(14),
      premium: 16500,
      stage: 'İndirim İstendi',
      status: 'active',
      quoteStatus: 'beklemede',
      notes: 'Aile TSS indirimi için genel müdürlükten onay bekleniyor.',
      createdAt: todayStr,
      updatedAt: todayStr,
      followDate: addDays(2),
    },
    // Concluded quotes (one converted, one rejected)
    {
      id: 'q-concluded-1',
      type: 'quote',
      insured: 'Kaya Mimarlık Ltd. Şti.',
      email: 'info@kayamimarlik.com',
      plate: '34KAY01',
      vehicleBrand: 'Mercedes-Benz',
      vehicleModel: 'C200 4MATIC AMG',
      vehicleYear: 2023,
      vehicleDetail: '2023 Mercedes C200',
      company: 'ALLIANZ SİGORTA',
      branch: 'Kasko',
      quoteNumber: 'TK-2026-050',
      quoteDate: addDays(-20),
      validUntil: addDays(-5),
      premium: 38500,
      stage: 'Müşteri Onayı Bekleniyor',
      status: 'concluded',
      quoteStatus: 'kabul_edildi',
      outcome: 'converted',
      convertedPolicyId: 'pol-conv-1',
      resultDate: addDays(-6),
      notes: 'Teklif onaylandı, poliçeye dönüştürüldü.',
      createdAt: addDays(-20),
      updatedAt: addDays(-6),
    },
    {
      id: 'q-concluded-2',
      type: 'quote',
      insured: 'Bora Demirtaş',
      email: 'bora.demirtas@gmail.com',
      plate: '35BOR88',
      vehicleBrand: 'Peugeot',
      vehicleModel: '3008 1.5 BlueHDi Allure',
      vehicleYear: 2019,
      vehicleDetail: '2019 Peugeot 3008',
      company: 'SOMPO SİGORTA',
      branch: 'Kasko',
      quoteNumber: 'TK-2026-062',
      quoteDate: addDays(-25),
      validUntil: addDays(-10),
      premium: 27500,
      stage: 'Müşteriye Sunuldu',
      status: 'concluded',
      quoteStatus: 'reddedildi',
      outcome: 'rejected',
      rejectionReason: 'Fiyat yüksek bulundu (Rakip daha ucuz)',
      rejectionNote: 'Başka kanaldan 24.000 TL teklif bulduğu için yaptırmadı.',
      resultDate: addDays(-11),
      notes: 'Fiyat yüksekliği nedeniyle iptal.',
      createdAt: addDays(-25),
      updatedAt: addDays(-11),
    },
  ];

  const policies: Policy[] = [
    {
      id: 'pol-conv-1',
      type: 'policy',
      insured: 'Kaya Mimarlık Ltd. Şti.',
      email: 'info@kayamimarlik.com',
      plate: '34KAY01',
      vehicleBrand: 'Mercedes-Benz',
      vehicleModel: 'C200 4MATIC AMG',
      vehicleYear: 2023,
      vehicleDetail: '2023 Mercedes C200',
      company: 'ALLIANZ SİGORTA',
      branch: 'Kasko',
      policyNumber: 'POL-348921-2026',
      startDate: addDays(-6),
      endDate: addDays(359),
      premium: 38500,
      status: 'Portföyde',
      stage: 'Yürürlükte',
      originQuoteId: 'q-concluded-1',
      doc: true,
      endorse: true,
      egm: true,
      notes: 'TK-2026-050 nolu tekliften otomatik dönüştürüldü.',
      createdAt: addDays(-6),
      updatedAt: addDays(-6),
    },
    {
      id: 'pol-1',
      type: 'policy',
      insured: 'Deniz Çetin',
      email: 'deniz.cetin@gmail.com',
      plate: '34DNZ92',
      vehicleBrand: 'Toyota',
      vehicleModel: 'Corolla 1.8 Hybrid Dream',
      vehicleYear: 2021,
      vehicleDetail: '2021 Toyota Corolla Hybrid',
      company: 'AXA SİGORTA',
      branch: 'Trafik',
      policyNumber: 'TRF-881920-2025',
      startDate: addDays(-360),
      endDate: addDays(5), // 5 days left -> CRITICAL
      premium: 10400,
      status: 'Portföyde',
      stage: 'Yenileme Bekliyor',
      doc: true,
      endorse: true,
      egm: true,
      notes: 'Yenileme zamanı geldi. Teklif hazırlanacak.',
      followDate: todayStr,
      createdAt: addDays(-360),
      updatedAt: todayStr,
    },
    {
      id: 'pol-2',
      type: 'policy',
      insured: 'Murat Arslan',
      plate: '16ARS77',
      vehicleBrand: 'Ford',
      vehicleModel: 'Focus 1.5 Ti-VCT Trend X',
      vehicleYear: 2018,
      vehicleDetail: '2018 Ford Focus',
      company: 'ANADOLU SİGORTA',
      branch: 'Kasko',
      policyNumber: 'KSK-401928-2025',
      startDate: addDays(-350),
      endDate: addDays(15), // 15 days left
      premium: 18900,
      status: 'Portföyde',
      stage: 'Yenileme Bekliyor',
      doc: true,
      endorse: false,
      egm: true,
      notes: 'Hasarsızlık kademesi 6. İndirimli teklif hazırlanacak.',
      createdAt: addDays(-350),
      updatedAt: addDays(-5),
    },
    {
      id: 'pol-3',
      type: 'policy',
      insured: 'Zeynep Işık',
      email: 'zeynep.isik@outlook.com',
      vehicleDetail: 'Kadıköy 3+1 Daire',
      company: 'DOĞA SİGORTA',
      branch: 'Konut',
      policyNumber: 'KNT-109283-2025',
      startDate: addDays(-340),
      endDate: addDays(25), // 25 days left
      premium: 5600,
      status: 'Portföyde',
      stage: 'Yürürlükte',
      notes: 'Kadıköy konut paketi + DASK birleşik yenileme.',
      createdAt: addDays(-340),
      updatedAt: addDays(-10),
    },
    {
      id: 'pol-4',
      type: 'policy',
      insured: 'Ömer Faruk Koç',
      plate: '07OFK40',
      vehicleBrand: 'Fiat',
      vehicleModel: 'Egea 1.4 Fire Urban',
      vehicleYear: 2021,
      company: 'TÜRKİYE SİGORTA',
      branch: 'Trafik',
      policyNumber: 'TRF-554433-2025',
      startDate: addDays(-370),
      endDate: addDays(-5), // 5 days overdue -> EXPIRED
      premium: 8900,
      status: 'Portföyde',
      stage: 'Süresi Doldu',
      doc: true,
      endorse: true,
      egm: true,
      notes: 'Bitiş tarihi geçti! Müşteriye bilgi verilecek.',
      createdAt: addDays(-370),
      updatedAt: todayStr,
    },
    // A concluded/completed policy
    {
      id: 'pol-concluded-1',
      type: 'policy',
      insured: 'Kemal Güler',
      email: 'kemal.guler@hotmail.com',
      plate: '34KML90',
      vehicleBrand: 'Renault',
      vehicleModel: 'Megane 1.3 TCe Joy',
      vehicleYear: 2019,
      company: 'RAY SİGORTA',
      branch: 'Kasko',
      policyNumber: 'KSK-990011-2024',
      startDate: addDays(-400),
      endDate: addDays(-35),
      premium: 17200,
      status: 'Sonuçlandı',
      stage: 'Süresi Doldu',
      outcome: 'completed',
      concludedReason: 'Poliçe süresi doldu ve başarıyla yenilendi.',
      resultDate: addDays(-30),
      doc: true,
      endorse: true,
      egm: true,
      notes: 'Portföyden süresi dolduğu için arşivlendi.',
      createdAt: addDays(-400),
      updatedAt: addDays(-30),
    },
  ];

  const rules: CustomRule[] = [
    {
      id: 'r-1',
      title: '10 Yaş Üzeri Kasko Yetkili Servis Kontrolü',
      branch: 'Kasko',
      minAge: 10,
      text: '10 yaş ve üzeri araçlarda bazı sigorta şirketleri yetkili servis teminatı vermez. Alternatif anlaşmalı servis maddesi kontrol edilmelidir.',
    },
    {
      id: 'r-2',
      title: 'Trafik Poliçesinde EGM ve Plaka Zeyli Zorunluluğu',
      branch: 'Trafik',
      text: 'Trafik tanzim edilmeden önce ruhsat, plaka zeyli ve EGM/TRAMER sorgusu eksiksiz yapılmalıdır.',
    },
    {
      id: 'r-3',
      title: 'Konut / DASK Birlikte Teklif Uyarısı',
      branch: 'Konut',
      text: 'Konut sigortası tanzim edilmeden önce güncel DASK poliçe numarasının sisteme işlendiğinden emin olunuz.',
    },
  ];

  return {
    quotes,
    policies,
    rules,
    settings: {
      reminderDays: [30, 15, 7, 3, 1],
    },
  };
};

export const loadAppData = (): AppData => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        quotes: Array.isArray(parsed.quotes) ? parsed.quotes.map(sanitizeQuoteData) : [],
        policies: Array.isArray(parsed.policies) ? parsed.policies.map(sanitizePolicyData) : [],
        rules: Array.isArray(parsed.rules) ? parsed.rules : [],
        settings: parsed.settings || { reminderDays: [30, 15, 7, 3, 1] },
      };
    }

    // Check legacy key if user had previous version
    const legacy = localStorage.getItem(LEGACY_KEY);
    if (legacy) {
      const legacyParsed = JSON.parse(legacy);
      const migratedPolicies: Policy[] = Array.isArray(legacyParsed.policies)
        ? legacyParsed.policies.map((p: any) =>
            sanitizePolicyData({
              id: p.id || generateId(),
              type: 'policy',
              insured: p.insured || '',
              email: p.email || '',
              plate: p.plate || '',
              company: p.company || 'ALLIANZ SİGORTA',
              branch: p.branch || 'Trafik',
              policyNumber: p.number || 'POL-' + Math.floor(100000 + Math.random() * 900000),
              startDate: p.startDate || getTodayIso(),
              endDate: p.endDate || addDays(365),
              premium: parseFloat(p.premium) || 0,
              status: p.status === 'Kapandı' ? 'Sonuçlandı' : 'Portföyde',
              stage: p.stage || 'Yürürlükte',
              outcome: p.status === 'Kapandı' ? 'completed' : undefined,
              resultDate: p.status === 'Kapandı' ? getTodayIso() : undefined,
              doc: !!p.doc,
              endorse: !!p.endorse,
              egm: !!p.egm,
              notes: p.notes || '',
              followDate: p.followDate || '',
              createdAt: p.createdAt || new Date().toISOString(),
              updatedAt: p.updatedAt || new Date().toISOString(),
            })
          )
        : [];

      const initialData: AppData = {
        quotes: [],
        policies: migratedPolicies,
        rules: Array.isArray(legacyParsed.rules) ? legacyParsed.rules : [],
        settings: legacyParsed.settings || { reminderDays: [30, 15, 7, 3, 1] },
      };
      saveAppData(initialData);
      return initialData;
    }
  } catch (e) {
    console.error('Failed to parse stored data:', e);
  }

  // First time initialization: start with an empty database.
  // Demo data is available only via the deliberate "Load Demo Data"
  // action in the Backup view — it is never auto-inserted.
  const emptyData: AppData = {
    quotes: [],
    policies: [],
    rules: [],
    settings: { reminderDays: [30, 15, 7, 3, 1] },
  };
  saveAppData(emptyData);
  return emptyData;
};

export const saveAppData = (data: AppData): void => {
  try {
    // Sanitize before saving to guarantee clean data and company normalization
    const sanitized: AppData = {
      quotes: data.quotes.map(sanitizeQuoteData),
      policies: data.policies.map(sanitizePolicyData),
      rules: data.rules,
      settings: data.settings,
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(sanitized));
  } catch (e) {
    console.error('Storage save error:', e);
  }
};

export const exportToJsonString = (data: AppData): string => {
  const cleanData: AppData = {
    quotes: data.quotes.map(sanitizeQuoteData),
    policies: data.policies.map(sanitizePolicyData),
    rules: data.rules,
    settings: data.settings,
  };
  return JSON.stringify(
    {
      ...cleanData,
      exportedAt: new Date().toISOString(),
      appVersion: '2.2.0',
      compliance: 'Authorized 13 Companies · Privacy Preserved (No TCKN / No Phone)',
    },
    null,
    2
  );
};

export const downloadFile = (filename: string, content: string, mimeType: string): void => {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
};

const escapeCsvCell = (val: any): string => {
  const s = String(val ?? '');
  return '"' + s.replace(/"/g, '""') + '"';
};

export const exportPoliciesToCsv = (policies: Policy[]): void => {
  const headers = [
    'Müşteri / Sigortalı',
    'E-posta',
    'Araç Plakası',
    'Araç Markası',
    'Modeli',
    'Model Yılı',
    'Detay / Adres',
    'Şirket',
    'Branş',
    'Poliçe Numarası',
    'Başlangıç Tarihi',
    'Bitiş Tarihi',
    'Kalan Gün',
    'Prim TL',
    'Yenileme Durumu',
    'İş Aşaması',
    'Ruhsat Kontrol',
    'Plaka Zeyli',
    'EGM/TRAMER',
    'İş Notları',
  ];

  const rows = policies.map((p) => [
    escapeCsvCell(p.insured),
    escapeCsvCell(p.email),
    escapeCsvCell(p.plate),
    escapeCsvCell(p.vehicleBrand),
    escapeCsvCell(p.vehicleModel),
    escapeCsvCell(p.vehicleYear),
    escapeCsvCell(p.vehicleDetail),
    escapeCsvCell(p.company),
    escapeCsvCell(p.branch),
    escapeCsvCell(p.policyNumber),
    escapeCsvCell(p.startDate),
    escapeCsvCell(p.endDate),
    escapeCsvCell(calculateDaysLeft(p.endDate)),
    escapeCsvCell(p.premium),
    escapeCsvCell(p.status),
    escapeCsvCell(p.stage),
    escapeCsvCell(p.doc ? 'Evet' : 'Hayır'),
    escapeCsvCell(p.endorse ? 'Evet' : 'Hayır'),
    escapeCsvCell(p.egm ? 'Evet' : 'Hayır'),
    escapeCsvCell(p.notes),
  ]);

  const csvContent = '\ufeff' + [headers.map(escapeCsvCell).join(';'), ...rows.map((r) => r.join(';'))].join('\r\n');
  downloadFile(`policeler-${getTodayIso()}.csv`, csvContent, 'text/csv;charset=utf-8');
};

export const exportQuotesToCsv = (quotes: Quote[]): void => {
  const headers = [
    'Müşteri / Sigortalı',
    'E-posta',
    'Araç Plakası',
    'Araç Markası',
    'Modeli',
    'Model Yılı',
    'Detay / Not',
    'Şirket',
    'Branş',
    'Teklif Numarası',
    'Teklif Tarihi',
    'Son Geçerlilik',
    'Prim TL',
    'Teklif Durumu',
    'İş Aşaması',
    'Sonuç',
    'Sonuçlanma Nedeni',
    'İş Notları',
  ];

  const rows = quotes.map((q) => [
    escapeCsvCell(q.insured),
    escapeCsvCell(q.email),
    escapeCsvCell(q.plate),
    escapeCsvCell(q.vehicleBrand),
    escapeCsvCell(q.vehicleModel),
    escapeCsvCell(q.vehicleYear),
    escapeCsvCell(q.vehicleDetail),
    escapeCsvCell(q.company),
    escapeCsvCell(q.branch),
    escapeCsvCell(q.quoteNumber),
    escapeCsvCell(q.quoteDate),
    escapeCsvCell(q.validUntil),
    escapeCsvCell(q.premium),
    escapeCsvCell(
      getEffectiveQuoteStatus(q) === 'kabul_edildi'
        ? 'Kabul Edildi'
        : getEffectiveQuoteStatus(q) === 'reddedildi'
        ? 'Reddedildi'
        : 'Beklemede'
    ),
    escapeCsvCell(q.stage),
    escapeCsvCell(
      q.outcome === 'converted' ? 'Olumlu (Poliçeleşti)' : q.outcome === 'rejected' ? 'Olumsuz (Yapılmadı)' : 'Beklemede'
    ),
    escapeCsvCell(q.rejectionReason || ''),
    escapeCsvCell(q.notes),
  ]);

  const csvContent = '\ufeff' + [headers.map(escapeCsvCell).join(';'), ...rows.map((r) => r.join(';'))].join('\r\n');
  downloadFile(`teklifler-${getTodayIso()}.csv`, csvContent, 'text/csv;charset=utf-8');
};


export { loadAppData, saveAppData, generateSampleData, getTodayIso, addDays, generateId, calculateDaysLeft }