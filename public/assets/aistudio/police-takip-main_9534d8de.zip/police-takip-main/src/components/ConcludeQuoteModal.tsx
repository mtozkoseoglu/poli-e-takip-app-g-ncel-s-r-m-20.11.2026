import React, { useState } from 'react';
import { Quote, REJECTION_REASONS } from '../types/insurance';
import { formatCurrency, getTodayIso } from '../services/storage';
import { X, Circle as XCircle, CircleAlert as AlertCircle } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  quote: Quote | null;
  onConfirm: (quoteId: string, reason: string, note: string) => void;
}

export const ConcludeQuoteModal: React.FC<Props> = ({ isOpen, onClose, quote, onConfirm }) => {
  const [reason, setReason] = useState(REJECTION_REASONS[0]);
  const [note, setNote] = useState('');

  if (!isOpen || !quote) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onConfirm(quote.id, reason, note.trim());
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-rose-600 text-white">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
              <XCircle className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-bold">Teklifi Sonuçlandır (Olumsuz)</h2>
              <p className="text-xs text-rose-100">
                Yapılmayan veya reddedilen teklif "Sonuçlananlar" sekmesine aktarılır.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Overview Box */}
        <div className="p-4 bg-rose-50/60 border-b border-rose-100 flex items-center justify-between">
          <div>
            <div className="text-xs text-rose-800 font-semibold">Müşteri / Sigortalı:</div>
            <div className="text-base font-bold text-slate-900">{quote.insured}</div>
            <div className="text-xs text-slate-500 mt-0.5">
              {quote.branch} · {quote.company} {quote.plate ? `· ${quote.plate}` : ''}
            </div>
          </div>
          <div className="text-right">
            <div className="text-xs text-slate-500">Teklif Tutarı</div>
            <div className="text-base font-bold text-slate-700">{formatCurrency(quote.premium)}</div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Sonuçlanma / Yapılmama Nedeni *
            </label>
            <select
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white font-medium focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 outline-none"
            >
              {REJECTION_REASONS.map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Açıklama / Müşteri Geri Bildirimi
            </label>
            <textarea
              rows={3}
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Örn: Başka bir şirketten 1.500 TL daha ucuza yaptırdığını söyledi. Gelecek yıl tekrar aranacak."
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 outline-none"
            />
          </div>

          <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-600 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
            <div>
              Bu teklif aktif teklifler listesinden kaldırılıp <strong>Sonuçlananlar</strong> sekmesindeki "Yapılmayan
              (Olumsuz) Teklifler" listesine kaydedilecektir. İstatistiklerde kaçan iş olarak takip edilebilir.
            </div>
          </div>

          {/* Footer */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors cursor-pointer"
            >
              Vazgeç
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-lg shadow-sm transition-colors cursor-pointer"
            >
              Olumsuz Olarak Arşivle
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
