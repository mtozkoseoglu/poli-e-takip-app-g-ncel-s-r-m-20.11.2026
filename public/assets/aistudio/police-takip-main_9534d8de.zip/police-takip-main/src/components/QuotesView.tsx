import React, { useState, useMemo } from 'react';
import { Quote, COMPANIES, BRANCHES, QUOTE_STAGES, QuoteStage, QuoteStatus } from '../types/insurance';
import {
  calculateDaysLeft,
  formatCurrency,
  formatDateTr,
  exportQuotesToCsv,
  getEffectiveQuoteStatus,
  getQuoteProgressPercent,
  getQuoteStatusMeta,
  generateId,
} from '../services/storage';
import { QuoteKanbanBoard } from './QuoteKanbanBoard';
import { Search, ListFilter as Filter, Plus, FileText, Download, CircleCheck as CheckCircle2, Circle as XCircle, MoveVertical as MoreVertical, Clock, Phone, Car, Shield, ArrowRight, TrendingUp, LayoutGrid, List, Sparkles, ChevronDown } from 'lucide-react';

interface Props {
  quotes: Quote[];
  onOpenNewQuote: () => void;
  onEditQuote: (quote: Quote) => void;
  onConvertToPolicy: (quote: Quote) => void;
  onConcludeNegative: (quote: Quote) => void;
  onOpenProgressModal: (quote: Quote) => void;
  onUpdateQuote: (quote: Quote) => void;
}

export const QuotesView: React.FC<Props> = ({
  quotes,
  onOpenNewQuote,
  onEditQuote,
  onConvertToPolicy,
  onConcludeNegative,
  onOpenProgressModal,
  onUpdateQuote,
}) => {
  const [viewMode, setViewMode] = useState<'table' | 'kanban'>('table');
  const [statusTab, setStatusTab] = useState<'all' | 'beklemede' | 'kabul_edildi' | 'reddedildi'>('beklemede');
  const [search, setSearch] = useState('');
  const [filterCompany, setFilterCompany] = useState('');
  const [filterBranch, setFilterBranch] = useState('');
  const [filterStage, setFilterStage] = useState('');

  // Counts for status tabs
  const countBeklemede = useMemo(() => {
    return quotes.filter((q) => getEffectiveQuoteStatus(q) === 'beklemede').length;
  }, [quotes]);

  const countKabul = useMemo(() => {
    return quotes.filter((q) => getEffectiveQuoteStatus(q) === 'kabul_edildi').length;
  }, [quotes]);

  const countRed = useMemo(() => {
    return quotes.filter((q) => getEffectiveQuoteStatus(q) === 'reddedildi').length;
  }, [quotes]);

  // Filtered quotes based on status tab, search and filters
  const filteredQuotes = useMemo(() => {
    const q = search.toLocaleLowerCase('tr-TR').trim();
    return quotes
      .filter((item) => {
        const itemStatus = getEffectiveQuoteStatus(item);

        // Status tab filtering
        if (statusTab !== 'all' && itemStatus !== statusTab) {
          return false;
        }

        const matchesSearch =
          !q ||
          item.insured.toLocaleLowerCase('tr-TR').includes(q) ||
          (item.plate && item.plate.toLocaleLowerCase('tr-TR').includes(q)) ||
          (item.vehicleBrand && item.vehicleBrand.toLocaleLowerCase('tr-TR').includes(q)) ||
          (item.vehicleModel && item.vehicleModel.toLocaleLowerCase('tr-TR').includes(q)) ||
          (item.phone && item.phone.includes(q)) ||
          (item.email && item.email.toLocaleLowerCase('tr-TR').includes(q)) ||
          (item.quoteNumber && item.quoteNumber.toLocaleLowerCase('tr-TR').includes(q)) ||
          item.company.toLocaleLowerCase('tr-TR').includes(q) ||
          item.branch.toLocaleLowerCase('tr-TR').includes(q);

        const matchesCompany = !filterCompany || item.company === filterCompany;
        const matchesBranch = !filterBranch || item.branch === filterBranch;
        const matchesStage = !filterStage || item.stage === filterStage;

        return matchesSearch && matchesCompany && matchesBranch && matchesStage;
      })
      .sort((a, b) => {
        // Sort by validity date (urgent first)
        const daysA = calculateDaysLeft(a.validUntil) ?? 9999;
        const daysB = calculateDaysLeft(b.validUntil) ?? 9999;
        return daysA - daysB;
      });
  }, [quotes, statusTab, search, filterCompany, filterBranch, filterStage]);

  // Summary Metrics
  const activeQuotes = useMemo(() => {
    return quotes.filter((q) => getEffectiveQuoteStatus(q) === 'beklemede');
  }, [quotes]);

  const totalPotentialPremium = activeQuotes.reduce((acc, curr) => acc + (curr.premium || 0), 0);
  const urgentCount = activeQuotes.filter((q) => {
    const d = calculateDaysLeft(q.validUntil);
    return d !== null && d <= 3 && d >= 0;
  }).length;
  const waitingApprovalCount = activeQuotes.filter(
    (q) => q.stage === 'Müşteri Onayı Bekleniyor' || q.stage === 'İndirim İstendi'
  ).length;

  const handleQuickChangeStage = (quote: Quote, newStage: QuoteStage) => {
    if (quote.stage === newStage) return;
    const nowStr = new Date().toISOString();
    const updated: Quote = {
      ...quote,
      stage: newStage,
      progressLogs: [
        {
          id: generateId(),
          stage: newStage,
          status: getEffectiveQuoteStatus(quote),
          timestamp: nowStr,
          note: `Aşama hızlı seçimle "${newStage}" olarak değiştirildi.`,
        },
        ...(quote.progressLogs || []),
      ],
      updatedAt: nowStr,
    };
    onUpdateQuote(updated);
  };

  const getValidityBadge = (days: number | null) => {
    if (days === null) return <span className="text-xs text-slate-400">Tarih yok</span>;
    if (days < 0) {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-rose-50 text-rose-700 border border-rose-200">
          Süresi Dolmuş ({Math.abs(days)} gün)
        </span>
      );
    }
    if (days <= 3) {
      return (
        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold bg-amber-50 text-amber-700 border border-amber-200">
          Son {days === 0 ? 'Bugün!' : `${days} gün`}
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-semibold bg-blue-50 text-blue-700 border border-blue-200">
        {days} gün kaldı
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Action */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <span>Teklif Yönetimi & İlerleme Takibi</span>
            <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-700">
              {countBeklemede} Beklemede
            </span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Tekliflerin durumunu (Beklemede, Kabul Edildi, Reddedildi), aşama ilerlemesini ve müşteri dönüşümlerini takip edin.
          </p>
        </div>

        <div className="flex items-center gap-2.5 w-full sm:w-auto">
          {/* View Mode Switcher */}
          <div className="flex items-center bg-white border border-slate-300 rounded-xl p-0.5 shadow-2xs">
            <button
              onClick={() => setViewMode('table')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                viewMode === 'table'
                  ? 'bg-blue-600 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              <span>Tablo</span>
            </button>
            <button
              onClick={() => setViewMode('kanban')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer ${
                viewMode === 'kanban'
                  ? 'bg-blue-600 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>İlerleme Panosu</span>
            </button>
          </div>

          <button
            onClick={() => exportQuotesToCsv(filteredQuotes)}
            className="px-3 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-xl shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>CSV İndir</span>
          </button>

          <button
            onClick={onOpenNewQuote}
            className="flex-1 sm:flex-none px-4 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>＋ Yeni Teklif Kaydı</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Beklemede / Süreçte</span>
            <span className="w-2 h-2 rounded-full bg-amber-500" />
          </div>
          <div className="text-2xl font-black text-amber-700 mt-2">{countBeklemede}</div>
          <div className="text-xs text-slate-500 mt-0.5">Karar ve takip sürecinde</div>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Kabul Edildi (Poliçeleşen)</span>
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
          </div>
          <div className="text-2xl font-black text-emerald-700 mt-2">{countKabul}</div>
          <div className="text-xs text-slate-500 mt-0.5">Başarıyla sonuçlanan teklifler</div>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Reddedildi / Yapılmadı</span>
            <span className="w-2 h-2 rounded-full bg-rose-500" />
          </div>
          <div className="text-2xl font-black text-rose-700 mt-2">{countRed}</div>
          <div className="text-xs text-slate-500 mt-0.5">Olumsuz veya iptal teklifler</div>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Potansiyel Prim</span>
            <TrendingUp className="w-3.5 h-3.5 text-blue-600" />
          </div>
          <div className="text-xl font-black text-slate-900 mt-2">{formatCurrency(totalPotentialPremium)}</div>
          <div className="text-xs text-slate-500 mt-0.5">Bekleyen teklif hacmi</div>
        </div>
      </div>

      {/* Status Filter Tabs & Search Bar */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs space-y-3">
        {/* Status Pill Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 border-b border-slate-100">
          <button
            onClick={() => setStatusTab('beklemede')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 ${
              statusTab === 'beklemede'
                ? 'bg-amber-500 text-white shadow-2xs'
                : 'text-amber-800 bg-amber-50 hover:bg-amber-100'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>⏳ Beklemede ({countBeklemede})</span>
          </button>

          <button
            onClick={() => setStatusTab('kabul_edildi')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 ${
              statusTab === 'kabul_edildi'
                ? 'bg-emerald-600 text-white shadow-2xs'
                : 'text-emerald-700 bg-emerald-50 hover:bg-emerald-100'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>✅ Kabul Edildi ({countKabul})</span>
          </button>

          <button
            onClick={() => setStatusTab('reddedildi')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 ${
              statusTab === 'reddedildi'
                ? 'bg-rose-600 text-white shadow-2xs'
                : 'text-rose-700 bg-rose-50 hover:bg-rose-100'
            }`}
          >
            <XCircle className="w-3.5 h-3.5" />
            <span>❌ Reddedildi ({countRed})</span>
          </button>

          <button
            onClick={() => setStatusTab('all')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer shrink-0 ${
              statusTab === 'all'
                ? 'bg-slate-900 text-white shadow-2xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Tüm Teklifler ({quotes.length})
          </button>
        </div>

        {/* Search & Select dropdowns */}
        <div className="flex flex-col md:flex-row gap-3 pt-1">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Sigortalı adı, plaka, TC/VKN, telefon veya teklif no ara..."
              className="w-full pl-9 pr-4 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              value={filterCompany}
              onChange={(e) => setFilterCompany(e.target.value)}
              className="px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white outline-none"
            >
              <option value="">Tüm Şirketler</option>
              {COMPANIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>

            <select
              value={filterBranch}
              onChange={(e) => setFilterBranch(e.target.value)}
              className="px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white outline-none"
            >
              <option value="">Tüm Branşlar</option>
              {BRANCHES.map((b) => (
                <option key={b} value={b}>
                  {b}
                </option>
              ))}
            </select>

            <select
              value={filterStage}
              onChange={(e) => setFilterStage(e.target.value)}
              className="px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white outline-none"
            >
              <option value="">Tüm Aşamalar</option>
              {QUOTE_STAGES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>

            {(search || filterCompany || filterBranch || filterStage || statusTab !== 'beklemede') && (
              <button
                onClick={() => {
                  setSearch('');
                  setFilterCompany('');
                  setFilterBranch('');
                  setFilterStage('');
                  setStatusTab('beklemede');
                }}
                className="px-3 py-2 text-xs font-semibold text-rose-600 hover:bg-rose-50 rounded-xl transition-colors cursor-pointer"
              >
                Sıfırla
              </button>
            )}
          </div>
        </div>
      </div>

      {/* View Switch: Table View or Kanban View */}
      {viewMode === 'kanban' ? (
        <QuoteKanbanBoard
          quotes={quotes}
          onOpenProgressModal={onOpenProgressModal}
          onEditQuote={onEditQuote}
          onConvertToPolicy={onConvertToPolicy}
          onConcludeNegative={onConcludeNegative}
          onUpdateQuote={onUpdateQuote}
        />
      ) : (
        /* Quotes Table View */
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs whitespace-nowrap">
              <thead>
                <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider">
                  <th className="py-3.5 px-4">Sigortalı / İletişim</th>
                  <th className="py-3.5 px-4">Plaka / Varlık</th>
                  <th className="py-3.5 px-4">Şirket & Branş</th>
                  <th className="py-3.5 px-4">Teklif No</th>
                  <th className="py-3.5 px-4 text-right">Teklif Tutarı</th>
                  <th className="py-3.5 px-4">Durum & İlerleme</th>
                  <th className="py-3.5 px-4">İş Aşaması</th>
                  <th className="py-3.5 px-4">Son Geçerlilik</th>
                  <th className="py-3.5 px-4 text-center">İşlem</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredQuotes.length > 0 ? (
                  filteredQuotes.map((quote) => {
                    const daysLeft = calculateDaysLeft(quote.validUntil);
                    const status = getEffectiveQuoteStatus(quote);
                    const statusMeta = getQuoteStatusMeta(status);
                    const progressPercent = getQuoteProgressPercent(quote);

                    return (
                      <tr key={quote.id} className="hover:bg-slate-50/80 transition-colors group">
                        {/* Sigortalı */}
                        <td className="py-3.5 px-4">
                          <div className="font-bold text-slate-900 text-sm">{quote.insured}</div>
                          <div className="text-slate-500 flex items-center gap-2 mt-0.5">
                            {quote.phone ? (
                              <span className="flex items-center gap-1 text-slate-600">
                                <Phone className="w-3 h-3 text-slate-400" />
                                {quote.phone}
                              </span>
                            ) : quote.email ? (
                              <span className="text-slate-400 text-xs truncate max-w-[150px]">{quote.email}</span>
                            ) : (
                              <span className="text-slate-400 text-xs">İletişim belirtilmedi</span>
                            )}
                          </div>
                        </td>

                        {/* Plaka & Varlık */}
                        <td className="py-3.5 px-4">
                          {quote.plate ? (
                            <div className="inline-block px-2 py-0.5 font-mono font-bold text-xs bg-slate-100 border border-slate-300 rounded text-slate-800">
                              {quote.plate}
                            </div>
                          ) : (
                            <span className="text-slate-400">—</span>
                          )}
                          {(quote.vehicleBrand || quote.vehicleModel) ? (
                            <div className="text-slate-700 font-semibold text-xs mt-0.5 max-w-[160px] truncate">
                              {quote.vehicleYear ? `${quote.vehicleYear} ` : ''}
                              {[quote.vehicleBrand, quote.vehicleModel].filter(Boolean).join(' ')}
                            </div>
                          ) : quote.vehicleDetail ? (
                            <div className="text-slate-500 text-xs mt-0.5 max-w-[150px] truncate" title={quote.vehicleDetail}>
                              {quote.vehicleDetail}
                            </div>
                          ) : null}
                        </td>

                        {/* Şirket & Branş */}
                        <td className="py-3.5 px-4">
                          <div className="font-semibold text-slate-800">{quote.company}</div>
                          <div className="text-slate-500 text-xs">{quote.branch}</div>
                          {quote.alternatives && quote.alternatives.length > 0 && (
                            <div className="text-blue-600 text-[11px] font-medium mt-0.5">
                              +{quote.alternatives.length} alternatif
                            </div>
                          )}
                        </td>

                        {/* Teklif No */}
                        <td className="py-3.5 px-4">
                          <span className="font-mono text-slate-700 bg-slate-50 px-2 py-1 rounded border border-slate-200">
                            {quote.quoteNumber || '—'}
                          </span>
                          <div className="text-slate-400 text-[11px] mt-1">{formatDateTr(quote.quoteDate)}</div>
                        </td>

                        {/* Prim */}
                        <td className="py-3.5 px-4 text-right">
                          <div className="font-black text-slate-900 text-sm">{formatCurrency(quote.premium)}</div>
                          {quote.followDate && (
                            <div className="text-purple-600 text-[11px] font-medium mt-0.5">
                              Takip: {formatDateTr(quote.followDate)}
                            </div>
                          )}
                        </td>

                        {/* Durum & İlerleme Çubuğu */}
                        <td className="py-3.5 px-4 min-w-[170px]">
                          <div className="flex items-center justify-between mb-1">
                            <span
                              className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold border ${statusMeta.badgeBg}`}
                            >
                              <span className={`w-1.5 h-1.5 rounded-full ${statusMeta.dot}`} />
                              <span>{statusMeta.label}</span>
                            </span>

                            <button
                              type="button"
                              onClick={() => onOpenProgressModal(quote)}
                              className="text-blue-600 hover:text-blue-800 font-bold text-[11px] flex items-center gap-0.5 cursor-pointer"
                            >
                              <Sparkles className="w-3 h-3" />
                              <span>%{progressPercent}</span>
                            </button>
                          </div>

                          {/* Mini Progress Track */}
                          <div
                            onClick={() => onOpenProgressModal(quote)}
                            title="İlerleme detayını görmek için tıklayın"
                            className="w-full bg-slate-100 rounded-full h-2 overflow-hidden cursor-pointer p-0.5 border border-slate-200"
                          >
                            <div
                              className={`h-full rounded-full transition-all duration-300 ${
                                status === 'kabul_edildi'
                                  ? 'bg-emerald-500'
                                  : status === 'reddedildi'
                                  ? 'bg-rose-500'
                                  : 'bg-gradient-to-r from-blue-500 to-indigo-600'
                              }`}
                              style={{ width: `${progressPercent}%` }}
                            />
                          </div>
                        </td>

                        {/* İş Aşaması (with quick change dropdown) */}
                        <td className="py-3.5 px-4">
                          {status === 'beklemede' ? (
                            <select
                              value={quote.stage}
                              onChange={(e) => handleQuickChangeStage(quote, e.target.value as QuoteStage)}
                              className="px-2.5 py-1 text-xs font-semibold text-slate-800 bg-white border border-slate-300 rounded-lg outline-none cursor-pointer focus:ring-2 focus:ring-blue-500/20"
                            >
                              {QUOTE_STAGES.map((s) => (
                                <option key={s} value={s}>
                                  {s}
                                </option>
                              ))}
                            </select>
                          ) : (
                            <span className="text-slate-500 text-xs font-medium">{quote.stage}</span>
                          )}
                        </td>

                        {/* Son Geçerlilik */}
                        <td className="py-3.5 px-4">
                          <div>{getValidityBadge(daysLeft)}</div>
                          <div className="text-slate-400 text-[11px] mt-1">{formatDateTr(quote.validUntil)}</div>
                        </td>

                        {/* İşlemler */}
                        <td className="py-3.5 px-4 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            {/* İlerlemeyi Gör */}
                            <button
                              type="button"
                              onClick={() => onOpenProgressModal(quote)}
                              title="Teklif İlerleme ve Durum Panelini Aç"
                              className="px-2 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded-lg text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
                            >
                              <Sparkles className="w-3 h-3 text-blue-600" />
                              <span>İlerleme</span>
                            </button>

                            {/* Poliçeleştir (Eğer beklemede ise) */}
                            {status === 'beklemede' && (
                              <button
                                type="button"
                                onClick={() => onConvertToPolicy(quote)}
                                title="Olumlu Sonuç: Teklifi Poliçeye Dönüştür"
                                className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-2xs flex items-center gap-1 transition-colors cursor-pointer"
                              >
                                <CheckCircle2 className="w-3 h-3" />
                                <span>Poliçeleştir</span>
                              </button>
                            )}

                            {/* Olumsuz Sonuçlandır */}
                            {status === 'beklemede' && (
                              <button
                                type="button"
                                onClick={() => onConcludeNegative(quote)}
                                title="Yapılmadı / Reddedildi olarak Sonuçlandır"
                                className="p-1 text-rose-600 hover:bg-rose-50 border border-rose-200 rounded-lg transition-colors cursor-pointer"
                              >
                                <XCircle className="w-4 h-4" />
                              </button>
                            )}

                            {/* Düzenle */}
                            <button
                              type="button"
                              onClick={() => onEditQuote(quote)}
                              title="Teklifi Düzenle / İncele"
                              className="px-2 py-1 text-slate-700 hover:bg-slate-100 border border-slate-200 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                            >
                              Düzenle
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={9} className="py-12 text-center">
                      <FileText className="w-10 h-10 text-slate-300 mx-auto mb-3" />
                      <div className="text-sm font-bold text-slate-700">Seçilen duruma uygun teklif bulunamadı</div>
                      <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                        Filtrenizi sıfırlayabilir veya yeni bir teklif oluşturabilirsiniz.
                      </p>
                      <button
                        onClick={onOpenNewQuote}
                        className="mt-4 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Yeni Teklif Oluştur</span>
                      </button>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
