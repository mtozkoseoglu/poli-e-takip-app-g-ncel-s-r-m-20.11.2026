import React, { useState, useMemo } from 'react';
import { Quote, Policy, COMPANIES, BRANCHES } from '../types/insurance';
import { formatCurrency, formatDateTr, exportPoliciesToCsv, exportQuotesToCsv, downloadFile, getTodayIso } from '../services/storage';
import { Search, ListFilter as Filter, CircleCheck as CheckCircle2, Circle as XCircle, Archive, Download, FileText, Shield, RotateCcw, ArrowRight, TrendingUp, TrendingDown, Info } from 'lucide-react';

interface Props {
  quotes: Quote[];
  policies: Policy[];
  onReopenQuote: (quoteId: string) => void;
  onReopenPolicy: (policyId: string) => void;
  onViewQuote: (quote: Quote) => void;
  onViewPolicy: (policy: Policy) => void;
  onNavigateToPolicy: (policyId: string) => void;
}

export type ConcludedItem =
  | {
      kind: 'quote_converted';
      id: string;
      data: Quote;
      insured: string;
      phone?: string;
      email?: string;
      plate?: string;
      company: string;
      branch: string;
      premium: number;
      resultDate?: string;
      label: 'Poliçeleşti (Olumlu)';
      badgeColor: 'emerald';
      detail: string;
      convertedPolicyId?: string;
    }
  | {
      kind: 'quote_rejected';
      id: string;
      data: Quote;
      insured: string;
      phone?: string;
      email?: string;
      plate?: string;
      company: string;
      branch: string;
      premium: number;
      resultDate?: string;
      label: 'Yapılmadı / Red (Olumsuz)';
      badgeColor: 'rose';
      detail: string;
      rejectionReason?: string;
    }
  | {
      kind: 'policy_concluded';
      id: string;
      data: Policy;
      insured: string;
      phone?: string;
      email?: string;
      plate?: string;
      company: string;
      branch: string;
      premium: number;
      resultDate?: string;
      label: 'Sonuçlanan Poliçe';
      badgeColor: 'slate';
      detail: string;
    };

export const ConcludedView: React.FC<Props> = ({
  quotes,
  policies,
  onReopenQuote,
  onReopenPolicy,
  onViewQuote,
  onViewPolicy,
  onNavigateToPolicy,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'converted' | 'rejected' | 'policies'>('all');
  const [search, setSearch] = useState('');
  const [filterCompany, setFilterCompany] = useState('');
  const [filterBranch, setFilterBranch] = useState('');

  // 1. Gather all concluded quotes
  const concludedQuotes = useMemo(() => {
    return quotes.filter((q) => q.status === 'concluded');
  }, [quotes]);

  // 2. Gather all concluded policies
  const concludedPolicies = useMemo(() => {
    return policies.filter((p) => p.status === 'Sonuçlandı' || p.status === 'İptal');
  }, [policies]);

  // Unified items
  const allItems: ConcludedItem[] = useMemo(() => {
    const list: ConcludedItem[] = [];

    // Quotes that were converted to policy (Olumlu)
    concludedQuotes
      .filter((q) => q.outcome === 'converted')
      .forEach((q) => {
        list.push({
          kind: 'quote_converted',
          id: q.id,
          data: q,
          insured: q.insured,
          phone: q.phone,
          email: q.email,
          plate: q.plate,
          company: q.company,
          branch: q.branch,
          premium: q.premium,
          resultDate: q.resultDate || q.updatedAt,
          label: 'Poliçeleşti (Olumlu)',
          badgeColor: 'emerald',
          detail: 'Teklif onaylandı ve aktif poliçeye dönüştürüldü.',
          convertedPolicyId: q.convertedPolicyId,
        });
      });

    // Quotes that were rejected/unmade (Olumsuz)
    concludedQuotes
      .filter((q) => q.outcome === 'rejected' || (!q.outcome && q.status === 'concluded'))
      .forEach((q) => {
        list.push({
          kind: 'quote_rejected',
          id: q.id,
          data: q,
          insured: q.insured,
          phone: q.phone,
          email: q.email,
          plate: q.plate,
          company: q.company,
          branch: q.branch,
          premium: q.premium,
          resultDate: q.resultDate || q.updatedAt,
          label: 'Yapılmadı / Red (Olumsuz)',
          badgeColor: 'rose',
          detail: q.rejectionReason || 'Teklif olumsuz sonuçlandı / yapılmadı.',
          rejectionReason: q.rejectionReason,
        });
      });

    // Policies that expired / were closed
    concludedPolicies.forEach((p) => {
      let outcomeText = 'Poliçe süresi doldu / tamamlandı.';
      if (p.outcome === 'renewed') outcomeText = 'Yenilenerek arşivlendi.';
      if (p.status === 'İptal' || p.outcome === 'cancelled') outcomeText = 'İptal edilerek arşivlendi.';
      if (p.concludedReason) outcomeText = p.concludedReason;

      list.push({
        kind: 'policy_concluded',
        id: p.id,
        data: p,
        insured: p.insured,
        phone: p.phone,
        email: p.email,
        plate: p.plate,
        company: p.company,
        branch: p.branch,
        premium: p.premium,
        resultDate: p.resultDate || p.endDate,
        label: 'Sonuçlanan Poliçe',
        badgeColor: 'slate',
        detail: outcomeText,
      });
    });

    // Sort by resultDate descending
    return list.sort((a, b) => {
      const dateA = a.resultDate ? new Date(a.resultDate).getTime() : 0;
      const dateB = b.resultDate ? new Date(b.resultDate).getTime() : 0;
      return dateB - dateA;
    });
  }, [concludedQuotes, concludedPolicies]);

  // Tab Filtering
  const tabFilteredItems = useMemo(() => {
    switch (activeTab) {
      case 'converted':
        return allItems.filter((x) => x.kind === 'quote_converted');
      case 'rejected':
        return allItems.filter((x) => x.kind === 'quote_rejected');
      case 'policies':
        return allItems.filter((x) => x.kind === 'policy_concluded');
      default:
        return allItems;
    }
  }, [allItems, activeTab]);

  // Search & Select Filtering
  const filteredItems = useMemo(() => {
    const q = search.toLocaleLowerCase('tr-TR').trim();
    return tabFilteredItems.filter((item) => {
      const matchesSearch =
        !q ||
        item.insured.toLocaleLowerCase('tr-TR').includes(q) ||
        (item.plate && item.plate.toLocaleLowerCase('tr-TR').includes(q)) ||
        (item.phone && item.phone.includes(q)) ||
        (item.email && item.email.toLocaleLowerCase('tr-TR').includes(q)) ||
        item.company.toLocaleLowerCase('tr-TR').includes(q) ||
        item.branch.toLocaleLowerCase('tr-TR').includes(q);

      const matchesCompany = !filterCompany || item.company === filterCompany;
      const matchesBranch = !filterBranch || item.branch === filterBranch;

      return matchesSearch && matchesCompany && matchesBranch;
    });
  }, [tabFilteredItems, search, filterCompany, filterBranch]);

  // Metrics calculation
  const convertedCount = allItems.filter((x) => x.kind === 'quote_converted').length;
  const rejectedCount = allItems.filter((x) => x.kind === 'quote_rejected').length;
  const closedPoliciesCount = allItems.filter((x) => x.kind === 'policy_concluded').length;

  const totalQuotesConcluded = convertedCount + rejectedCount;
  const conversionRate = totalQuotesConcluded > 0 ? Math.round((convertedCount / totalQuotesConcluded) * 100) : 0;

  const wonPremium = allItems
    .filter((x) => x.kind === 'quote_converted')
    .reduce((acc, curr) => acc + (curr.premium || 0), 0);

  const lostPremium = allItems
    .filter((x) => x.kind === 'quote_rejected')
    .reduce((acc, curr) => acc + (curr.premium || 0), 0);

  const handleExportCsv = () => {
    const headers = ['Tür', 'Sonuç Durumu', 'Sigortalı', 'Telefon', 'E-posta', 'Plaka', 'Şirket', 'Branş', 'Prim TL', 'Sonuç Tarihi', 'Açıklama'];
    const rows = filteredItems.map((item) => [
      `"${item.kind.startsWith('quote') ? 'Teklif' : 'Poliçe'}"`,
      `"${item.label}"`,
      `"${item.insured}"`,
      `"${item.phone || ''}"`,
      `"${item.email || ''}"`,
      `"${item.plate || ''}"`,
      `"${item.company}"`,
      `"${item.branch}"`,
      `"${item.premium || 0}"`,
      `"${item.resultDate || ''}"`,
      `"${(item.detail || '').replace(/"/g, '""')}"`,
    ]);

    const csvContent = '\ufeff' + [headers.join(';'), ...rows.map((r) => r.join(';'))].join('\r\n');
    downloadFile(`sonuclananlar-${getTodayIso()}.csv`, csvContent, 'text/csv;charset=utf-8');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <span>Sonuçlananlar</span>
            <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-slate-800 text-white">
              {allItems.length} Kayıt
            </span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Poliçeleştirilen olumlu teklifler, yapılmayan/reddedilen teklifler ve süresi dolan veya kapanan poliçelerin
            tarihçesi.
          </p>
        </div>
        <div className="flex items-center gap-2.5">
          <button
            onClick={handleExportCsv}
            className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-xl shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>CSV Olarak İndir</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Teklif Başarı Oranı</span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black text-emerald-700 mt-2">%{conversionRate}</div>
          <div className="text-xs text-slate-500 mt-0.5">
            {convertedCount} / {totalQuotesConcluded} teklif poliçeleşti
          </div>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Kazanılan Prim (Olumlu)</span>
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
          </div>
          <div className="text-xl font-black text-emerald-700 mt-2">{formatCurrency(wonPremium)}</div>
          <div className="text-xs text-slate-500 mt-0.5">Poliçeleşen teklif hacmi</div>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Kaçan Prim (Yapılmayan)</span>
            <span className="w-2 h-2 rounded-full bg-rose-500" />
          </div>
          <div className="text-xl font-black text-rose-700 mt-2">{formatCurrency(lostPremium)}</div>
          <div className="text-xs text-slate-500 mt-0.5">{rejectedCount} olumsuz teklif</div>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Kapanan Poliçeler</span>
            <Archive className="w-4 h-4 text-slate-400" />
          </div>
          <div className="text-2xl font-black text-slate-900 mt-2">{closedPoliciesCount}</div>
          <div className="text-xs text-slate-500 mt-0.5">Süresi dolan / arşivlenen</div>
        </div>
      </div>

      {/* Tabs & Filters */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs space-y-3">
        {/* Category Pill Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 border-b border-slate-100">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer shrink-0 ${
              activeTab === 'all'
                ? 'bg-slate-900 text-white shadow-2xs'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Tümü ({allItems.length})
          </button>
          <button
            onClick={() => setActiveTab('converted')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 ${
              activeTab === 'converted'
                ? 'bg-emerald-600 text-white shadow-2xs'
                : 'text-emerald-700 bg-emerald-50 hover:bg-emerald-100'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Poliçeleşen Teklifler ({convertedCount})</span>
          </button>
          <button
            onClick={() => setActiveTab('rejected')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 ${
              activeTab === 'rejected'
                ? 'bg-rose-600 text-white shadow-2xs'
                : 'text-rose-700 bg-rose-50 hover:bg-rose-100'
            }`}
          >
            <XCircle className="w-3.5 h-3.5" />
            <span>Yapılmayan Teklifler ({rejectedCount})</span>
          </button>
          <button
            onClick={() => setActiveTab('policies')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 ${
              activeTab === 'policies'
                ? 'bg-slate-700 text-white shadow-2xs'
                : 'text-slate-700 bg-slate-100 hover:bg-slate-200'
            }`}
          >
            <Archive className="w-3.5 h-3.5" />
            <span>Sonuçlanan Poliçeler ({closedPoliciesCount})</span>
          </button>
        </div>

        {/* Search & Filter dropdowns */}
        <div className="flex flex-col md:flex-row gap-3 pt-1">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Sigortalı adı, plaka, telefon veya şirket ara..."
              className="w-full pl-9 pr-4 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-slate-500/20 focus:border-slate-500 outline-none"
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              value={filterCompany}
              onChange={(e) => setFilterCompany(e.target.value)}
              className="px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white outline-none"
            >
              <option value="">Tüm Şirketler</option>
              {COMPANIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>

            <select
              value={filterBranch}
              onChange={(e) => setFilterBranch(e.target.value)}
              className="px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white outline-none"
            >
              <option value="">Tüm Branşlar</option>
              {BRANCHES.map((b) => (
                <option key={b} value={b}>
                  {b}
                </option>
              ))}
            </select>

            {(search || filterCompany || filterBranch) && (
              <button
                onClick={() => {
                  setSearch('');
                  setFilterCompany('');
                  setFilterBranch('');
                }}
                className="px-3 py-2 text-xs font-semibold text-rose-600 hover:bg-rose-50 rounded-xl transition-colors cursor-pointer"
              >
                Sıfırla
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Main Concluded Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs whitespace-nowrap">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider">
                <th className="py-3.5 px-4">Tür & Sonuç Durumu</th>
                <th className="py-3.5 px-4">Sigortalı / İletişim</th>
                <th className="py-3.5 px-4">Plaka / Varlık</th>
                <th className="py-3.5 px-4">Şirket & Branş</th>
                <th className="py-3.5 px-4 text-right">Prim Tutarı</th>
                <th className="py-3.5 px-4">Sonuçlanma Tarihi</th>
                <th className="py-3.5 px-4">Sonuç Açıklaması / Neden</th>
                <th className="py-3.5 px-4 text-center">İşlem</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredItems.length > 0 ? (
                filteredItems.map((item) => {
                  return (
                    <tr key={`${item.kind}-${item.id}`} className="hover:bg-slate-50/80 transition-colors">
                      {/* Tür & Sonuç Rozeti */}
                      <td className="py-3.5 px-4">
                        {item.kind === 'quote_converted' && (
                          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Poliçeleşti (Olumlu)</span>
                          </div>
                        )}
                        {item.kind === 'quote_rejected' && (
                          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-50 text-rose-700 border border-rose-200">
                            <XCircle className="w-3.5 h-3.5 text-rose-600" />
                            <span>Yapılmadı (Olumsuz)</span>
                          </div>
                        )}
                        {item.kind === 'policy_concluded' && (
                          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-slate-100 text-slate-700 border border-slate-200">
                            <Archive className="w-3.5 h-3.5 text-slate-500" />
                            <span>Sonuçlanan Poliçe</span>
                          </div>
                        )}
                        <div className="text-[11px] text-slate-400 mt-1">
                          {item.kind.startsWith('quote') ? 'Teklif Süreci' : 'Portföy Kaydı'}
                        </div>
                      </td>

                      {/* Sigortalı */}
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-900 text-sm">{item.insured}</div>
                        {item.phone ? (
                          <div className="text-slate-500 text-xs">{item.phone}</div>
                        ) : item.email ? (
                          <div className="text-slate-400 text-xs">{item.email}</div>
                        ) : null}
                      </td>

                      {/* Plaka */}
                      <td className="py-3.5 px-4">
                        {item.plate ? (
                          <div className="inline-block px-2 py-0.5 font-mono font-bold text-xs bg-slate-100 border border-slate-300 rounded text-slate-800">
                            {item.plate}
                          </div>
                        ) : (
                          <span className="text-slate-400">—</span>
                        )}
                      </td>

                      {/* Şirket & Branş */}
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-slate-800">{item.company}</div>
                        <div className="text-slate-500 text-xs">{item.branch}</div>
                      </td>

                      {/* Prim */}
                      <td className="py-3.5 px-4 text-right">
                        <div
                          className={`font-black text-sm ${
                            item.kind === 'quote_converted'
                              ? 'text-emerald-700'
                              : item.kind === 'quote_rejected'
                              ? 'text-rose-700 line-through'
                              : 'text-slate-800'
                          }`}
                        >
                          {formatCurrency(item.premium)}
                        </div>
                      </td>

                      {/* Sonuçlanma Tarihi */}
                      <td className="py-3.5 px-4 text-slate-600">
                        {formatDateTr(item.resultDate)}
                      </td>

                      {/* Açıklama */}
                      <td className="py-3.5 px-4 max-w-xs">
                        <div className="text-slate-700 font-medium text-xs truncate" title={item.detail}>
                          {item.detail}
                        </div>
                        {item.kind === 'quote_rejected' && item.rejectionReason && (
                          <div className="text-rose-600 text-[11px] font-semibold mt-0.5">
                            Neden: {item.rejectionReason}
                          </div>
                        )}
                      </td>

                      {/* İşlem */}
                      <td className="py-3.5 px-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          {/* Detayı Aç */}
                          <button
                            type="button"
                            onClick={() => {
                              if (item.kind.startsWith('quote')) {
                                onViewQuote(item.data as Quote);
                              } else {
                                onViewPolicy(item.data as Policy);
                              }
                            }}
                            className="px-2 py-1 text-slate-700 hover:bg-slate-100 border border-slate-200 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                          >
                            İncele
                          </button>

                          {/* Teklif poliçeleştiyse ilgili poliçeye git */}
                          {item.kind === 'quote_converted' && item.convertedPolicyId && (
                            <button
                              type="button"
                              onClick={() => onNavigateToPolicy(item.convertedPolicyId!)}
                              title="Oluşturulan Poliçeyi Gör"
                              className="px-2 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                            >
                              <Shield className="w-3 h-3" />
                              <span>Poliçeye Git</span>
                            </button>
                          )}

                          {/* Tekrar Aktife Al (Reopen) */}
                          <button
                            type="button"
                            onClick={() => {
                              if (confirm('Bu kaydı tekrar aktif listeye almak istiyor musunuz?')) {
                                if (item.kind.startsWith('quote')) {
                                  onReopenQuote(item.id);
                                } else {
                                  onReopenPolicy(item.id);
                                }
                              }
                            }}
                            title="Sonuçlanan kaydı geri alıp aktife taşı"
                            className="p-1 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={8} className="py-12 text-center">
                    <CheckCircle2 className="w-10 h-10 text-slate-300 mx-auto mb-3" />
                    <div className="text-sm font-bold text-slate-700">Sonuçlanan kayıt bulunamadı</div>
                    <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                      Teklifleriniz olumlu sonuçlanıp poliçeye dönüştüğünde veya yapılmadığında buraya kaydedilir.
                    </p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
