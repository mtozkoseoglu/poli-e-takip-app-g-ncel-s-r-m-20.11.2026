import React, { useMemo } from 'react';
import { Quote, Policy } from '../types/insurance';
import { calculateDaysLeft, formatCurrency, formatDateTr } from '../services/storage';
import { Bell, TriangleAlert as AlertTriangle, Clock, Calendar, CircleCheck as CheckCircle2, Phone, Shield, FileText } from 'lucide-react';

interface Props {
  quotes: Quote[];
  policies: Policy[];
  reminderDays: number[];
  onViewQuote: (quote: Quote) => void;
  onViewPolicy: (policy: Policy) => void;
  onConvertToPolicy: (quote: Quote) => void;
}

export const RemindersView: React.FC<Props> = ({
  quotes,
  policies,
  reminderDays,
  onViewQuote,
  onViewPolicy,
  onConvertToPolicy,
}) => {
  const activePolicies = policies.filter((p) => p.status !== 'Sonuçlandı' && p.status !== 'İptal');
  const activeQuotes = quotes.filter((q) => q.status === 'active');

  // Reminders for policies:
  // - Overdue (days < 0)
  // - Ending within 14 days OR matching reminderDays
  const policyReminders = useMemo(() => {
    return activePolicies
      .filter((p) => {
        const days = calculateDaysLeft(p.endDate);
        if (days === null) return false;
        return days < 0 || days <= 14 || reminderDays.includes(days);
      })
      .sort((a, b) => (calculateDaysLeft(a.endDate) ?? 9999) - (calculateDaysLeft(b.endDate) ?? 9999));
  }, [activePolicies, reminderDays]);

  // Reminders for quotes:
  // - Expiring within 5 days OR has followDate matching today/past
  const quoteReminders = useMemo(() => {
    return activeQuotes
      .filter((q) => {
        const days = calculateDaysLeft(q.validUntil);
        const followDays = calculateDaysLeft(q.followDate);
        return (days !== null && days <= 5) || (followDays !== null && followDays <= 1);
      })
      .sort((a, b) => (calculateDaysLeft(a.validUntil) ?? 9999) - (calculateDaysLeft(b.validUntil) ?? 9999));
  }, [activeQuotes]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Bell className="w-6 h-6 text-amber-600" />
            <span>Hatırlatmalar ve Takip Listesi</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Gecikmiş, bugün biten, yaklaşan poliçe yenilemeleri ve teklif takip aramaları.
          </p>
        </div>
        <div className="text-xs text-slate-500 bg-amber-50 border border-amber-200 px-3 py-1.5 rounded-xl font-medium">
          Takip Kuralı: Bitişe {reminderDays.join(', ')} gün kala
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Section 1: Poliçe Yenileme Hatırlatmaları */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-5 flex flex-col">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Shield className="w-4 h-4 text-indigo-600" />
              <span>Yenileme Bekleyen Poliçeler ({policyReminders.length})</span>
            </h2>
            <span className="text-xs text-slate-400">Bitiş Tarihine Göre</span>
          </div>

          <div className="divide-y divide-slate-100 flex-1 space-y-1">
            {policyReminders.length > 0 ? (
              policyReminders.map((p) => {
                const days = calculateDaysLeft(p.endDate);
                const isOverdue = days !== null && days < 0;
                const isUrgent = days !== null && days >= 0 && days <= 7;

                return (
                  <div key={p.id} className="py-3 flex items-center justify-between gap-3 text-xs">
                    <div>
                      <div className="font-bold text-slate-900 flex items-center gap-2">
                        <span>{p.insured}</span>
                        {p.plate && (
                          <span className="px-1.5 py-0.5 rounded bg-slate-100 font-mono text-[11px] font-semibold text-slate-700">
                            {p.plate}
                          </span>
                        )}
                      </div>
                      <div className="text-slate-500 mt-0.5">
                        {p.company} · {p.branch} · Prim: {formatCurrency(p.premium)}
                      </div>
                      {p.phone && (
                        <div className="text-slate-400 text-[11px] flex items-center gap-1 mt-0.5">
                          <Phone className="w-3 h-3" />
                          <span>{p.phone}</span>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <div className="text-right">
                        <span
                          className={`inline-block px-2 py-0.5 rounded-full text-xs font-bold ${
                            isOverdue
                              ? 'bg-rose-50 text-rose-700 border border-rose-200'
                              : isUrgent
                              ? 'bg-amber-50 text-amber-700 border border-amber-200'
                              : 'bg-blue-50 text-blue-700 border border-blue-200'
                          }`}
                        >
                          {days !== null && days < 0
                            ? `${Math.abs(days)} gün gecikti`
                            : days === 0
                            ? 'Bugün!'
                            : `${days} gün kaldı`}
                        </span>
                        <div className="text-[11px] text-slate-400 mt-1">{formatDateTr(p.endDate)}</div>
                      </div>
                      <button
                        onClick={() => onViewPolicy(p)}
                        className="px-2.5 py-1 text-slate-700 hover:bg-slate-100 border border-slate-200 rounded-lg font-semibold cursor-pointer"
                      >
                        Aç
                      </button>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="py-12 text-center text-xs text-slate-400">Şu anda yaklaşan poliçe hatırlatması yok.</div>
            )}
          </div>
        </div>

        {/* Section 2: Teklif Takip & Geçerlilik Hatırlatmaları */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-5 flex flex-col">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <FileText className="w-4 h-4 text-blue-600" />
              <span>Teklif Takip ve Arama Listesi ({quoteReminders.length})</span>
            </h2>
            <span className="text-xs text-slate-400">Karar Bekleyenler</span>
          </div>

          <div className="divide-y divide-slate-100 flex-1 space-y-1">
            {quoteReminders.length > 0 ? (
              quoteReminders.map((q) => {
                const days = calculateDaysLeft(q.validUntil);
                const isOverdue = days !== null && days < 0;

                return (
                  <div key={q.id} className="py-3 flex items-center justify-between gap-3 text-xs">
                    <div>
                      <div className="font-bold text-slate-900 flex items-center gap-2">
                        <span>{q.insured}</span>
                        {q.plate && (
                          <span className="px-1.5 py-0.5 rounded bg-slate-100 font-mono text-[11px] font-semibold text-slate-700">
                            {q.plate}
                          </span>
                        )}
                      </div>
                      <div className="text-slate-500 mt-0.5">
                        {q.company} · {q.branch} · Prim: {formatCurrency(q.premium)}
                      </div>
                      <div className="text-blue-600 font-medium text-[11px] mt-0.5">Aşama: {q.stage}</div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <div className="text-right">
                        <span
                          className={`inline-block px-2 py-0.5 rounded-full text-xs font-bold ${
                            isOverdue
                              ? 'bg-rose-50 text-rose-700 border border-rose-200'
                              : 'bg-amber-50 text-amber-700 border border-amber-200'
                          }`}
                        >
                          {days !== null && days < 0
                            ? 'Süre doldu'
                            : days === 0
                            ? 'Son gün!'
                            : `${days} gün kaldı`}
                        </span>
                        <div className="text-[11px] text-slate-400 mt-1">{formatDateTr(q.validUntil)}</div>
                      </div>
                      <button
                        onClick={() => onConvertToPolicy(q)}
                        className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold shadow-2xs cursor-pointer"
                      >
                        Poliçeleştir
                      </button>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="py-12 text-center text-xs text-slate-400">Şu anda süresi yaklaşan teklif yok.</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
