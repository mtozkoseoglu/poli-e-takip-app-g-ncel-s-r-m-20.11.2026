import React, { useState } from 'react';
import { CustomRule, COMPANIES, BRANCHES } from '../types/insurance';
import { generateId } from '../services/storage';
import { FileSliders as Sliders, Plus, Trash2, CreditCard as Edit3, CircleAlert as AlertCircle, Save, Check } from 'lucide-react';

interface Props {
  rules: CustomRule[];
  reminderDays: number[];
  onSaveReminderDays: (days: number[]) => void;
  onSaveRule: (rule: CustomRule) => void;
  onDeleteRule: (id: string) => void;
}

export const RulesView: React.FC<Props> = ({
  rules,
  reminderDays,
  onSaveReminderDays,
  onSaveRule,
  onDeleteRule,
}) => {
  const [daysInput, setDaysInput] = useState(reminderDays.join(', '));
  const [daysSaved, setDaysSaved] = useState(false);

  // New Rule form state
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [ruleTitle, setRuleTitle] = useState('');
  const [ruleCompany, setRuleCompany] = useState('');
  const [ruleBranch, setRuleBranch] = useState('');
  const [ruleMinAge, setRuleMinAge] = useState<number | ''>('');
  const [ruleText, setRuleText] = useState('');

  const handleSaveDays = (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = daysInput
      .split(',')
      .map((s) => parseInt(s.trim(), 10))
      .filter((n) => !isNaN(n) && n >= 0 && n <= 365);
    const sorted = [...new Set(parsed)].sort((a, b) => b - a);
    onSaveReminderDays(sorted);
    setDaysSaved(true);
    setTimeout(() => setDaysSaved(false), 2500);
  };

  const handleOpenAdd = () => {
    setEditingId(null);
    setRuleTitle('');
    setRuleCompany('');
    setRuleBranch('');
    setRuleMinAge('');
    setRuleText('');
    setIsAdding(true);
  };

  const handleOpenEdit = (r: CustomRule) => {
    setEditingId(r.id);
    setRuleTitle(r.title);
    setRuleCompany(r.company || '');
    setRuleBranch(r.branch || '');
    setRuleMinAge(r.minAge !== undefined && r.minAge !== '' ? Number(r.minAge) : '');
    setRuleText(r.text);
    setIsAdding(true);
  };

  const handleSubmitRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ruleTitle.trim() || !ruleText.trim()) return;

    const newRule: CustomRule = {
      id: editingId || generateId(),
      title: ruleTitle.trim(),
      company: ruleCompany || undefined,
      branch: ruleBranch || undefined,
      minAge: ruleMinAge !== '' ? Number(ruleMinAge) : undefined,
      text: ruleText.trim(),
    };

    onSaveRule(newRule);
    setIsAdding(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Sliders className="w-6 h-6 text-slate-700" />
            <span>İşlem & Uyarı Kuralları</span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Yenileme hatırlatma günlerini ve branş/şirket bazlı kontrol uyarılarını yönetin.
          </p>
        </div>
        <button
          onClick={handleOpenAdd}
          className="px-4 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>＋ Yeni Kontrol Kuralı</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Reminder Days Config */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-5">
          <h2 className="text-sm font-bold text-slate-900 mb-1">Yenileme Takip Günleri</h2>
          <p className="text-xs text-slate-500 mb-4">
            Poliçe bitiş tarihinden kaç gün önce hatırlatma yapılsın?
          </p>

          <form onSubmit={handleSaveDays} className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Günleri virgülle ayırın (Örn: 30, 15, 7, 3, 1)
              </label>
              <input
                type="text"
                value={daysInput}
                onChange={(e) => setDaysInput(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none font-semibold text-slate-800"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1.5"
            >
              {daysSaved ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>Kaydedildi</span>
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  <span>Günleri Kaydet</span>
                </>
              )}
            </button>
          </form>

          <div className="mt-4 p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-600 space-y-1">
            <div className="font-semibold text-slate-800">Aktif Tetikleyiciler:</div>
            <div className="flex flex-wrap gap-1 mt-1">
              {reminderDays.map((d) => (
                <span
                  key={d}
                  className="px-2 py-0.5 rounded-md bg-white border border-slate-300 text-slate-700 text-[11px] font-bold"
                >
                  {d} gün önce
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Custom Rules List */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 shadow-2xs p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-slate-900">İşlem Kontrol Kuralları ({rules.length})</h2>
              <p className="text-xs text-slate-500">
                Poliçe düzenleme ve teklif oluştururken otomatik gösterilen uyarılar
              </p>
            </div>
          </div>

          {/* Form for adding/editing rule */}
          {isAdding && (
            <form onSubmit={handleSubmitRule} className="mb-6 p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <div className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                {editingId ? 'Kuralı Güncelle' : 'Yeni Kural Ekle'}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Kural Başlığı *</label>
                  <input
                    type="text"
                    required
                    value={ruleTitle}
                    onChange={(e) => setRuleTitle(e.target.value)}
                    placeholder="Örn: 10 Yaş Üzeri Kasko Yetkili Servis Kontrolü"
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg outline-none bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Sigorta Şirketi (Opsiyonel)</label>
                  <select
                    value={ruleCompany}
                    onChange={(e) => setRuleCompany(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg outline-none bg-white"
                  >
                    <option value="">Tüm Şirketler</option>
                    {COMPANIES.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Branş (Opsiyonel)</label>
                  <select
                    value={ruleBranch}
                    onChange={(e) => setRuleBranch(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg outline-none bg-white"
                  >
                    <option value="">Tüm Branşlar</option>
                    {BRANCHES.map((b) => (
                      <option key={b} value={b}>
                        {b}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Min. Araç Yaşı</label>
                  <input
                    type="number"
                    value={ruleMinAge}
                    onChange={(e) => setRuleMinAge(e.target.value ? Number(e.target.value) : '')}
                    placeholder="Örn: 10"
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg outline-none bg-white"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Uyarı & Talimat Metni *</label>
                  <textarea
                    rows={2}
                    required
                    value={ruleText}
                    onChange={(e) => setRuleText(e.target.value)}
                    placeholder="Bu işlem esnasında dikkat edilmesi gereken teknik hususlar..."
                    className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg outline-none bg-white"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-200 rounded-lg cursor-pointer"
                >
                  İptal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg shadow-2xs cursor-pointer"
                >
                  {editingId ? 'Güncelle' : 'Kuralı Kaydet'}
                </button>
              </div>
            </form>
          )}

          {/* Rules List */}
          <div className="space-y-3">
            {rules.length > 0 ? (
              rules.map((rule) => (
                <div
                  key={rule.id}
                  className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl flex items-start justify-between gap-3 text-xs"
                >
                  <div className="space-y-1">
                    <div className="font-bold text-slate-900">{rule.title}</div>
                    <div className="flex items-center gap-2 text-slate-500 text-[11px]">
                      {rule.company && <span>Şirket: {rule.company} ·</span>}
                      {rule.branch && <span>Branş: {rule.branch} ·</span>}
                      {rule.minAge !== undefined && <span>Min Yaş: {rule.minAge}</span>}
                      {!rule.company && !rule.branch && <span>Genel Kural</span>}
                    </div>
                    <p className="text-slate-700 mt-1">{rule.text}</p>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => handleOpenEdit(rule)}
                      className="p-1.5 text-slate-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => {
                        if (confirm('Bu kuralı silmek istediğinize emin misiniz?')) {
                          onDeleteRule(rule.id);
                        }
                      }}
                      className="p-1.5 text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            ) : (
              <div className="py-8 text-center text-xs text-slate-400">Henüz tanımlı kural yok.</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
