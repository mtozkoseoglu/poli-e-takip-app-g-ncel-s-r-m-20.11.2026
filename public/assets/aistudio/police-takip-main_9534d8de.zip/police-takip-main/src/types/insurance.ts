export type QuoteStage =
  | 'Teklif Hazırlanıyor'
  | 'Müşteriye Sunuldu'
  | 'Fiyat Değerlendirmede'
  | 'İndirim İstendi'
  | 'İndirim Alındı'
  | 'Müşteri Onayı Bekleniyor';

export type QuoteStatus = 'beklemede' | 'kabul_edildi' | 'reddedildi';

export interface QuoteProgressLog {
  id: string;
  stage: string;
  status: QuoteStatus;
  timestamp: string;
  note?: string;
}

export type PolicyStage =
  | 'Yenileme Bekliyor'
  | 'Poliçe Düzenlendi'
  | 'Zeyil Aşamasında'
  | 'Yürürlükte'
  | 'Süresi Doldu';

export type QuoteOutcome = 'converted' | 'rejected'; // converted = Olumlu (Poliçeleşti), rejected = Olumsuz (Yapılmadı)
export type PolicyOutcome = 'completed' | 'cancelled' | 'renewed';

export interface AlternativeQuote {
  company: string;
  premium: number;
  notes?: string;
}

export interface Quote {
  id: string;
  type: 'quote';
  insured: string; // Müşteri adı soyadı veya şirket unvanı
  phone?: string; // İsteğe bağlı telefon
  email?: string; // İsteğe bağlı e-posta
  plate?: string; // Araç plakası
  vehicleBrand?: string; // Araç markası
  vehicleModel?: string; // Araç modeli
  vehicleYear?: number | string; // Model yılı
  vehicleDetail?: string; // Araç / Varlık detay özeti
  company: string; // Sigorta şirketi
  branch: string; // Poliçe branşı
  quoteNumber?: string; // Teklif No
  quoteDate: string; // Teklif tarihi
  validUntil: string; // Bitiş / Son geçerlilik tarihi
  premium: number; // Prim TL
  stage: QuoteStage;
  status: 'active' | 'concluded';
  quoteStatus?: QuoteStatus; // 'beklemede' | 'kabul_edildi' | 'reddedildi'
  outcome?: QuoteOutcome;
  convertedPolicyId?: string; // Oluşan poliçe ID'si
  resultDate?: string; // Sonuçlanma tarihi
  rejectionReason?: string; // Sonuçlanma nedeni
  rejectionNote?: string;
  progressLogs?: QuoteProgressLog[]; // İlerleme ve aşama geçmişi
  alternatives?: AlternativeQuote[];
  notes?: string; // İş notları
  followDate?: string; // Takip / Arama tarihi
  createdAt: string;
  updatedAt: string;
}

export interface Policy {
  id: string;
  type: 'policy';
  insured: string; // Müşteri adı soyadı veya şirket unvanı
  phone?: string; // İsteğe bağlı telefon
  email?: string; // İsteğe bağlı e-posta
  plate?: string; // Araç plakası
  vehicleBrand?: string; // Araç markası
  vehicleModel?: string; // Araç modeli
  vehicleYear?: number | string; // Model yılı
  vehicleDetail?: string; // Araç / Varlık detay özeti
  company: string; // Sigorta şirketi
  branch: string; // Poliçe branşı
  policyNumber: string; // Poliçe numarası
  startDate: string; // Poliçe başlangıç tarihi
  endDate: string; // Poliçe bitiş / yenileme tarihi
  premium: number; // Prim TL
  status: 'Portföyde' | 'Yenileme Takibinde' | 'Sonuçlandı' | 'İptal'; // Yenileme durumu
  stage: PolicyStage;
  outcome?: PolicyOutcome;
  resultDate?: string; // Sonuçlanma tarihi
  originQuoteId?: string; // Eğer bir tekliften türetildiyse
  concludedReason?: string;
  // Kontrol listesi
  doc?: boolean; // Ruhsat kontrolü yapıldı
  endorse?: boolean; // Plaka zeyli yapıldı
  egm?: boolean; // EGM / TRAMER kontrol edildi
  notes?: string; // İş notları
  followDate?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CustomRule {
  id: string;
  title: string;
  company?: string;
  branch?: string;
  minAge?: number | string;
  stage?: string;
  text: string;
}

export interface AppSettings {
  reminderDays: number[];
}

export interface AppData {
  quotes: Quote[];
  policies: Policy[];
  rules: CustomRule[];
  settings: AppSettings;
}

export const COMPANIES = [
  'AK SİGORTA',
  'ALLIANZ SİGORTA',
  'ANADOLU SİGORTA',
  'AXA SİGORTA',
  'DOĞA SİGORTA',
  'EUREKO SİGORTA',
  'HDI SİGORTA',
  'HEPIYI SİGORTA',
  'MAPFRE SİGORTA',
  'NEOVA SİGORTA',
  'RAY SİGORTA',
  'SOMPO SİGORTA',
  'TÜRKİYE SİGORTA',
] as const;

export type AuthorizedCompany = (typeof COMPANIES)[number];

export const BRANCHES = [
  'Kasko',
  'Trafik',
  'Konut',
  'DASK',
  'İşyeri',
  'Sağlık (ÖSS)',
  'Tamamlayıcı Sağlık (TSS)',
  'Ferdi Kaza',
  'Nakliyat',
  'Sorumluluk',
  'Seyahat Sağlık',
  'Diğer',
];

export const QUOTE_STAGES: QuoteStage[] = [
  'Teklif Hazırlanıyor',
  'Müşteriye Sunuldu',
  'Fiyat Değerlendirmede',
  'İndirim İstendi',
  'İndirim Alındı',
  'Müşteri Onayı Bekleniyor',
];

export const POLICY_STAGES: PolicyStage[] = [
  'Yürürlükte',
  'Yenileme Bekliyor',
  'Poliçe Düzenlendi',
  'Zeyil Aşamasında',
  'Süresi Doldu',
];

export const REJECTION_REASONS = [
  'Fiyat yüksek bulundu (Rakip daha ucuz)',
  'Başka acente / şirket tercih edildi',
  'Araç veya gayrimenkul satıldı',
  'Müşteri sigortadan vazgeçti / erteledi',
  'Kredi kartı / ödeme sorunu',
  'Ulaşılamadı / Zaman aşımı',
  'Diğer',
];
