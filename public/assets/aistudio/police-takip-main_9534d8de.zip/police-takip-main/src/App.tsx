import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { AppData, Quote, Policy, CustomRule } from './types/insurance';
import {
  loadAppData,
  saveAppData,
  generateSampleData,
  getTodayIso,
  addDays,
  generateId,
  calculateDaysLeft,
} from './services/storage';
import { Sidebar, TabType } from './components/Sidebar';
import { Header } from './components/Header';
import { DashboardView } from './components/DashboardView';
import { QuotesView } from './components/QuotesView';
import { PoliciesView } from './components/PoliciesView';
import { ConcludedView } from './components/ConcludedView';
import { CalendarView } from './components/CalendarView';
import { RemindersView } from './components/RemindersView';
import { RulesView } from './components/RulesView';
import { BackupView } from './components/BackupView';
import { QuoteModal } from './components/QuoteModal';
import { PolicyModal } from './components/PolicyModal';
import { ConvertToPolicyModal } from './components/ConvertToPolicyModal';
import { ConcludeQuoteModal } from './components/ConcludeQuoteModal';
import { ConcludePolicyModal } from './components/ConcludePolicyModal';
import { QuoteProgressModal } from './components/QuoteProgressModal';
import { Toast } from './components/Toast';

export default function App() {
  const [appData, setAppData] = useState<AppData>(() => loadAppData());
  const [currentTab, setCurrentTab] = useState<TabType>('dashboard');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Modals state
  const [isQuoteModalOpen, setIsQuoteModalOpen] = useState(false);
  const [editingQuote, setEditingQuote] = useState<Quote | null>(null);

  const [isPolicyModalOpen, setIsPolicyModalOpen] = useState(false);
  const [editingPolicy, setEditingPolicy] = useState<Policy | null>(null);

  const [isConvertModalOpen, setIsConvertModalOpen] = useState(false);
  const [convertingQuote, setConvertingQuote] = useState<Quote | null>(null);

  const [isConcludeQuoteModalOpen, setIsConcludeQuoteModalOpen] = useState(false);
  const [concludingQuote, setConcludingQuote] = useState<Quote | null>(null);

  const [isConcludePolicyModalOpen, setIsConcludePolicyModalOpen] = useState(false);
  const [concludingPolicy, setConcludingPolicy] = useState<Policy | null>(null);

  const [isProgressModalOpen, setIsProgressModalOpen] = useState(false);
  const [progressModalQuote, setProgressModalQuote] = useState<Quote | null>(null);

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Auto-dismiss toast
  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3500);
  }, []);

  // Update storage whenever appData changes
  const updateData = useCallback((newData: AppData | ((prev: AppData) => AppData)) => {
    setAppData((prev) => {
      const next = typeof newData === 'function' ? newData(prev) : newData;
      saveAppData(next);
      return next;
    });
  }, []);

  // Handlers for Quotes
  const handleOpenNewQuote = () => {
    setEditingQuote(null);
    setIsQuoteModalOpen(true);
  };

  const handleEditQuote = (quote: Quote) => {
    setEditingQuote(quote);
    setIsQuoteModalOpen(true);
  };

  const handleSaveQuote = (quote: Quote) => {
    updateData((prev) => {
      const index = prev.quotes.findIndex((q) => q.id === quote.id);
      let updatedQuotes: Quote[];
      if (index >= 0) {
        updatedQuotes = [...prev.quotes];
        updatedQuotes[index] = quote;
      } else {
        updatedQuotes = [quote, ...prev.quotes];
      }
      return { ...prev, quotes: updatedQuotes };
    });
    showToast('Teklif başarıyla kaydedildi.');
  };

  const handleDeleteQuote = (id: string) => {
    updateData((prev) => ({
      ...prev,
      quotes: prev.quotes.filter((q) => q.id !== id),
    }));
    showToast('Teklif kaydı silindi.');
  };

  const handleOpenProgressModal = (quote: Quote) => {
    setProgressModalQuote(quote);
    setIsProgressModalOpen(true);
  };

  const handleUpdateQuote = (quote: Quote) => {
    handleSaveQuote(quote);
    setProgressModalQuote(quote);
  };

  // Handlers for Policies
  const handleOpenNewPolicy = () => {
    setEditingPolicy(null);
    setIsPolicyModalOpen(true);
  };

  const handleEditPolicy = (policy: Policy) => {
    setEditingPolicy(policy);
    setIsPolicyModalOpen(true);
  };

  const handleSavePolicy = (policy: Policy) => {
    updateData((prev) => {
      const index = prev.policies.findIndex((p) => p.id === policy.id);
      let updatedPolicies: Policy[];
      if (index >= 0) {
        updatedPolicies = [...prev.policies];
        updatedPolicies[index] = policy;
      } else {
        updatedPolicies = [policy, ...prev.policies];
      }
      return { ...prev, policies: updatedPolicies };
    });
    showToast('Poliçe başarıyla kaydedildi.');
  };

  const handleDeletePolicy = (id: string) => {
    updateData((prev) => ({
      ...prev,
      policies: prev.policies.filter((p) => p.id !== id),
    }));
    showToast('Poliçe kaydı silindi.');
  };

  // Convert Quote to Policy (Olumlu Sonuç)
  const handleStartConvertToPolicy = (quote: Quote) => {
    setConvertingQuote(quote);
    setIsConvertModalOpen(true);
  };

  const handleConfirmConvertToPolicy = (quoteId: string, createdPolicy: Policy) => {
    const todayStr = getTodayIso();
    updateData((prev) => {
      // 1. Mark quote as converted and concluded
      const updatedQuotes = prev.quotes.map((q) => {
        if (q.id === quoteId) {
          return {
            ...q,
            status: 'concluded' as const,
            outcome: 'converted' as const,
            convertedPolicyId: createdPolicy.id,
            resultDate: todayStr,
            updatedAt: new Date().toISOString(),
          };
        }
        return q;
      });

      // 2. Add newly created policy
      const updatedPolicies = [createdPolicy, ...prev.policies];

      return {
        ...prev,
        quotes: updatedQuotes,
        policies: updatedPolicies,
      };
    });

    showToast('🎉 Teklif poliçeye dönüştürüldü! "Sonuçlananlar" sekmesine aktarıldı.');
  };

  // Conclude Quote Negatively (Yapılmadı / Reddedildi)
  const handleStartConcludeNegative = (quote: Quote) => {
    setConcludingQuote(quote);
    setIsConcludeQuoteModalOpen(true);
  };

  const handleConfirmConcludeNegative = (quoteId: string, reason: string, note: string) => {
    const todayStr = getTodayIso();
    updateData((prev) => {
      const updatedQuotes = prev.quotes.map((q) => {
        if (q.id === quoteId) {
          return {
            ...q,
            status: 'concluded' as const,
            outcome: 'rejected' as const,
            rejectionReason: reason,
            rejectionNote: note,
            resultDate: todayStr,
            updatedAt: new Date().toISOString(),
          };
        }
        return q;
      });
      return { ...prev, quotes: updatedQuotes };
    });

    showToast('Teklif "Sonuçlananlar" sekmesine "Yapılmadı" olarak aktarıldı.');
  };

  // Conclude Active Policy (Süresi Doldu / Arşivlendi)
  const handleStartConcludePolicy = (policy: Policy) => {
    setConcludingPolicy(policy);
    setIsConcludePolicyModalOpen(true);
  };

  const handleConfirmConcludePolicy = (
    policyId: string,
    outcome: 'completed' | 'cancelled' | 'renewed',
    reason: string
  ) => {
    const todayStr = getTodayIso();
    updateData((prev) => {
      const updatedPolicies = prev.policies.map((p) => {
        if (p.id === policyId) {
          return {
            ...p,
            status: 'Sonuçlandı' as const,
            outcome,
            concludedReason: reason,
            resultDate: todayStr,
            updatedAt: new Date().toISOString(),
          };
        }
        return p;
      });
      return { ...prev, policies: updatedPolicies };
    });

    showToast('Poliçe sonuçlandırıldı ve "Sonuçlananlar" sekmesine aktarıldı.');
  };

  // Re-open concluded items
  const handleReopenQuote = (quoteId: string) => {
    updateData((prev) => {
      const updatedQuotes = prev.quotes.map((q) => {
        if (q.id === quoteId) {
          return {
            ...q,
            status: 'active' as const,
            outcome: undefined,
            resultDate: undefined,
            rejectionReason: undefined,
            rejectionNote: undefined,
            updatedAt: new Date().toISOString(),
          };
        }
        return q;
      });
      return { ...prev, quotes: updatedQuotes };
    });
    showToast('Teklif tekrar aktif listeye alındı.');
  };

  const handleReopenPolicy = (policyId: string) => {
    updateData((prev) => {
      const updatedPolicies = prev.policies.map((p) => {
        if (p.id === policyId) {
          return {
            ...p,
            status: 'Portföyde' as const,
            outcome: undefined,
            resultDate: undefined,
            concludedReason: undefined,
            updatedAt: new Date().toISOString(),
          };
        }
        return p;
      });
      return { ...prev, policies: updatedPolicies };
    });
    showToast('Poliçe tekrar aktif portföye alındı.');
  };

  // Create renewal quote from existing policy
  const handleCreateRenewalQuote = (policy: Policy) => {
    const newQuote: Quote = {
      id: generateId(),
      type: 'quote',
      insured: policy.insured,
      phone: policy.phone || '',
      email: policy.email || '',
      plate: policy.plate || '',
      vehicleBrand: policy.vehicleBrand || '',
      vehicleModel: policy.vehicleModel || '',
      vehicleYear: policy.vehicleYear,
      vehicleDetail: policy.vehicleDetail || '',
      company: policy.company,
      branch: policy.branch,
      quoteNumber: 'TK-' + new Date().getFullYear() + '-' + Math.floor(100 + Math.random() * 900),
      quoteDate: getTodayIso(),
      validUntil: addDays(15),
      premium: policy.premium || 0,
      stage: 'Teklif Hazırlanıyor',
      status: 'active',
      notes: `${policy.policyNumber} nolu poliçenin yenileme teklifidir.`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setEditingQuote(newQuote);
    setIsQuoteModalOpen(true);
  };

  const handleNavigateToPolicy = (policyId: string) => {
    const pol = appData.policies.find((p) => p.id === policyId);
    if (pol) {
      setCurrentTab('policies');
      handleEditPolicy(pol);
    }
  };

  // Rules & Settings Handlers
  const handleSaveReminderDays = (days: number[]) => {
    updateData((prev) => ({
      ...prev,
      settings: { ...prev.settings, reminderDays: days },
    }));
    showToast('Hatırlatma günleri güncellendi.');
  };

  const handleSaveRule = (rule: CustomRule) => {
    updateData((prev) => {
      const idx = prev.rules.findIndex((r) => r.id === rule.id);
      let updated: CustomRule[];
      if (idx >= 0) {
        updated = [...prev.rules];
        updated[idx] = rule;
      } else {
        updated = [rule, ...prev.rules];
      }
      return { ...prev, rules: updated };
    });
    showToast('Kontrol kuralı kaydedildi.');
  };

  const handleDeleteRule = (id: string) => {
    updateData((prev) => ({
      ...prev,
      rules: prev.rules.filter((r) => r.id !== id),
    }));
    showToast('Kural silindi.');
  };

  // Backup & Reset Handlers
  const handleRestoreData = (restored: AppData) => {
    updateData(restored);
  };

  const handleResetToSample = () => {
    const sample = generateSampleData();
    updateData(sample);
  };

  // Live badge counts
  const activeQuotesCount = useMemo(() => {
    return appData.quotes.filter((q) => q.status === 'active').length;
  }, [appData.quotes]);

  const activePoliciesCount = useMemo(() => {
    return appData.policies.filter((p) => p.status !== 'Sonuçlandı' && p.status !== 'İptal').length;
  }, [appData.policies]);

  const concludedCount = useMemo(() => {
    const quotesConcluded = appData.quotes.filter((q) => q.status === 'concluded').length;
    const policiesConcluded = appData.policies.filter((p) => p.status === 'Sonuçlandı' || p.status === 'İptal').length;
    return quotesConcluded + policiesConcluded;
  }, [appData.quotes, appData.policies]);

  const urgentRemindersCount = useMemo(() => {
    return appData.policies.filter((p) => {
      if (p.status === 'Sonuçlandı') return false;
      const days = calculateDaysLeft(p.endDate);
      return days !== null && days <= 7;
    }).length;
  }, [appData.policies]);

  return (
    <div className="flex h-screen bg-slate-100 font-sans text-slate-800 antialiased overflow-hidden">
      {/* Sidebar for Desktop */}
      <div className="hidden md:flex shrink-0">
        <Sidebar
          currentTab={currentTab}
          onSelectTab={setCurrentTab}
          activeQuotesCount={activeQuotesCount}
          activePoliciesCount={activePoliciesCount}
          concludedCount={concludedCount}
          urgentRemindersCount={urgentRemindersCount}
        />
      </div>

      {/* Mobile Sidebar overlay */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 flex md:hidden">
          <div className="fixed inset-0 bg-slate-900/60" onClick={() => setMobileMenuOpen(false)} />
          <div className="relative z-50 flex">
            <Sidebar
              currentTab={currentTab}
              onSelectTab={(tab) => {
                setCurrentTab(tab);
                setMobileMenuOpen(false);
              }}
              activeQuotesCount={activeQuotesCount}
              activePoliciesCount={activePoliciesCount}
              concludedCount={concludedCount}
              urgentRemindersCount={urgentRemindersCount}
            />
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Header
          currentTab={currentTab}
          onOpenNewQuote={handleOpenNewQuote}
          onOpenNewPolicy={handleOpenNewPolicy}
          onToggleMobileMenu={() => setMobileMenuOpen(true)}
        />

        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <div className="max-w-7xl mx-auto">
            {currentTab === 'dashboard' && (
              <DashboardView
                quotes={appData.quotes}
                policies={appData.policies}
                onOpenNewQuote={handleOpenNewQuote}
                onOpenNewPolicy={handleOpenNewPolicy}
                onViewQuote={handleEditQuote}
                onViewPolicy={handleEditPolicy}
                onConvertToPolicy={handleStartConvertToPolicy}
                onNavigateTab={setCurrentTab}
              />
            )}

            {currentTab === 'quotes' && (
              <QuotesView
                quotes={appData.quotes}
                onOpenNewQuote={handleOpenNewQuote}
                onEditQuote={handleEditQuote}
                onConvertToPolicy={handleStartConvertToPolicy}
                onConcludeNegative={handleStartConcludeNegative}
                onOpenProgressModal={handleOpenProgressModal}
                onUpdateQuote={handleUpdateQuote}
              />
            )}

            {currentTab === 'policies' && (
              <PoliciesView
                policies={appData.policies}
                onOpenNewPolicy={handleOpenNewPolicy}
                onEditPolicy={handleEditPolicy}
                onConcludePolicy={handleStartConcludePolicy}
                onCreateRenewalQuote={handleCreateRenewalQuote}
              />
            )}

            {currentTab === 'concluded' && (
              <ConcludedView
                quotes={appData.quotes}
                policies={appData.policies}
                onReopenQuote={handleReopenQuote}
                onReopenPolicy={handleReopenPolicy}
                onViewQuote={handleEditQuote}
                onViewPolicy={handleEditPolicy}
                onNavigateToPolicy={handleNavigateToPolicy}
              />
            )}

            {currentTab === 'calendar' && (
              <CalendarView
                quotes={appData.quotes}
                policies={appData.policies}
                onViewQuote={handleEditQuote}
                onViewPolicy={handleEditPolicy}
              />
            )}

            {currentTab === 'reminders' && (
              <RemindersView
                quotes={appData.quotes}
                policies={appData.policies}
                reminderDays={appData.settings.reminderDays}
                onViewQuote={handleEditQuote}
                onViewPolicy={handleEditPolicy}
                onConvertToPolicy={handleStartConvertToPolicy}
              />
            )}

            {currentTab === 'rules' && (
              <RulesView
                rules={appData.rules}
                reminderDays={appData.settings.reminderDays}
                onSaveReminderDays={handleSaveReminderDays}
                onSaveRule={handleSaveRule}
                onDeleteRule={handleDeleteRule}
              />
            )}

            {currentTab === 'backup' && (
              <BackupView
                appData={appData}
                onRestoreData={handleRestoreData}
                onResetToSample={handleResetToSample}
                showToast={showToast}
              />
            )}
          </div>
        </main>
      </div>

      {/* Quote Modal */}
      <QuoteModal
        isOpen={isQuoteModalOpen}
        onClose={() => setIsQuoteModalOpen(false)}
        onSave={handleSaveQuote}
        onDelete={handleDeleteQuote}
        onConvertToPolicy={handleStartConvertToPolicy}
        onConcludeNegative={handleStartConcludeNegative}
        initialQuote={editingQuote}
      />

      {/* Policy Modal */}
      <PolicyModal
        isOpen={isPolicyModalOpen}
        onClose={() => setIsPolicyModalOpen(false)}
        onSave={handleSavePolicy}
        onDelete={handleDeletePolicy}
        onConclude={handleStartConcludePolicy}
        onCreateRenewalQuote={handleCreateRenewalQuote}
        initialPolicy={editingPolicy}
        rules={appData.rules}
      />

      {/* Convert Quote to Policy Modal */}
      <ConvertToPolicyModal
        isOpen={isConvertModalOpen}
        onClose={() => setIsConvertModalOpen(false)}
        quote={convertingQuote}
        onConfirm={handleConfirmConvertToPolicy}
      />

      {/* Conclude Quote Negative Modal */}
      <ConcludeQuoteModal
        isOpen={isConcludeQuoteModalOpen}
        onClose={() => setIsConcludeQuoteModalOpen(false)}
        quote={concludingQuote}
        onConfirm={handleConfirmConcludeNegative}
      />

      {/* Conclude Active Policy Modal */}
      <ConcludePolicyModal
        isOpen={isConcludePolicyModalOpen}
        onClose={() => setIsConcludePolicyModalOpen(false)}
        policy={concludingPolicy}
        onConfirm={handleConfirmConcludePolicy}
      />

      {/* Quote Progress Tracking Modal */}
      <QuoteProgressModal
        isOpen={isProgressModalOpen}
        onClose={() => setIsProgressModalOpen(false)}
        quote={progressModalQuote}
        onUpdateQuote={handleUpdateQuote}
        onConvertToPolicy={handleStartConvertToPolicy}
        onConcludeNegative={handleStartConcludeNegative}
      />

      {/* Toast Notification */}
      <Toast message={toastMessage} />
    </div>
  );
}
