export type QuoteStage =
  | 'MÜŞTERİYE SUNULACAK'
  | 'İNDİRİM İSTENDİ'
  | 'İNDİRİMLİ PRİME REVİZE YAPILDI'
  | 'MÜŞTERİDEN YANIT BEKLENİYOR';

export const NON_CONVERSION_REASONS = [
  'MÜŞTERİ BAŞKA YERDEN YAPTIRDI',
  'MÜŞTERİ YAPTIRMADI',
  'MÜŞTERİYE ULAŞILAMADI',
  'ARAÇ SATILDI',
] as const;

export type NonConversionReason = (typeof NON_CONVERSION_REASONS)[number];

export type QuoteStatus = 'beklemede' | 'kabul_edildi' | 'reddedildi';

export interface QuoteProgressLog {
  id: string;
  stage: string;
  status: QuoteStatus;
  timestamp: string;
  note?: string;
}

export type PolicyStage =
  | 'Yenileme Bekliyor'
  | 'Poliçe Düzenlendi'
  | 'Zeyil Aşamasında'
  | 'Yürürlükte'
  | 'Süresi Doldu';

export type QuoteOutcome = 'converted' | 'rejected'; // converted = Olumlu (Poliçeleşti), rejected = Olumsuz (Yapılmadı)
export type PolicyOutcome = 'completed' | 'cancelled' | 'renewed';

export interface AlternativeQuote {
  company: string;
  premium: number;
  notes?: string;
}

export type BusinessType = 'Yenileme' | 'Yeni İş' | 'Takip';

export const BUSINESS_TYPES: BusinessType[] = ['Yenileme', 'Yeni İş', 'Takip'];

export const USAGE_STYLES = [
  'ÇEKİCİ',
  'İŞ MAKİNESİ',
  'KAMYON',
  'KAMYONET',
  'MİNİBÜS',
  'MOTOSİKLET',
  'OTOBÜS',
  'OTOMOBİL',
  'RÖMORK',
  'TAKSİ',
  'TRAKTÖR',
] as const;

export type UsageStyle = (typeof USAGE_STYLES)[number];

export const FUEL_TYPES = [
  'BENZİN',
  'DİZEL',
  'LPG',
  'HİBRİT',
  'ELEKTRİK',
  'BENZİN + LPG',
  'DİĞER',
] as const;

export type FuelType = (typeof FUEL_TYPES)[number];

export type CompanyOfferStatus = 'teklif_alindi' | 'teklif_alinamadi' | 'bekleniyor';

export interface CompanyOffer {
  company: string; // 13 onaylı şirketten biri
  premium?: number;
  quoteNumber?: string;
  notes?: string;
  status?: CompanyOfferStatus;
  noOffer?: boolean; // Teklif alınamadı bayrağı
}

export interface Quote {
  id: string;
  type: 'quote';
  insured: string; // Müşteri adı soyadı veya şirket unvanı
  businessType?: BusinessType; // Yenileme, Yeni İş, Takip
  phone?: string; // İsteğe bağlı telefon
  email?: string; // İsteğe bağlı e-posta
  plate?: string; // Araç plakası
  licenseSerialNo?: string; // Ruhsat Belge Seri No
  chassisNo?: string; // Şasi No
  engineNo?: string; // Motor No
  usageStyle?: string; // Araç Kullanım Tarzı
  vehicleYear?: number | string; // Model yılı
  vehicleBrand?: string; // Araç markası
  vehicleModel?: string; // Araç modeli
  vehicleCode?: string; // Araç Kodu
  fuelType?: string; // Yakıt Türü (Benzin, Dizel, Hibrit vb.)
  vehicleValue?: number; // Araç Bedeli TL
  vehicleDetail?: string; // Araç / Varlık detay özeti
  company: string; // Sigorta şirketi
  branch: string; // Poliçe branşı
  quoteNumber?: string; // Teklif No
  quoteDate: string; // Teklif tarihi
  validUntil: string; // Bitiş / Son geçerlilik tarihi
  premium: number; // Prim TL
  stage: QuoteStage;
  status: 'active' | 'concluded';
  quoteStatus?: QuoteStatus; // 'beklemede' | 'kabul_edildi' | 'reddedildi'
  outcome?: QuoteOutcome;
  convertedPolicyId?: string; // Oluşan poliçe ID'si
  resultDate?: string; // Sonuçlanma tarihi
  rejectionReason?: string; // Sonuçlanma / poliçeleştirmeme nedeni
  nonConversionReason?: NonConversionReason | string; // Teklif Sonucu / Poliçeleştirmeme Nedeni
  rejectionNote?: string;
  progressLogs?: QuoteProgressLog[]; // İlerleme ve aşama geçmişi
  companyOffers?: CompanyOffer[]; // 6 sigorta şirketi teklif satırı
  alternatives?: AlternativeQuote[];
  notes?: string; // İş notları
  followDate?: string; // Takip / Arama tarihi
  createdAt: string;
  updatedAt: string;
}

export interface Policy {
  id: string;
  type: 'policy';
  insured: string; // Müşteri adı soyadı veya şirket unvanı
  phone?: string; // İsteğe bağlı telefon
  email?: string; // İsteğe bağlı e-posta
  plate?: string; // Araç plakası
  licenseSerialNo?: string; // Ruhsat Belge Seri No
  chassisNo?: string; // Şasi No
  engineNo?: string; // Motor No
  usageStyle?: string; // Araç Kullanım Tarzı
  vehicleBrand?: string; // Araç markası
  vehicleModel?: string; // Araç modeli
  vehicleCode?: string; // Araç Kodu
  fuelType?: string; // Yakıt Türü
  vehicleYear?: number | string; // Model yılı
  vehicleValue?: number; // Araç Bedeli TL
  multiplier?: number; // Çarpan = Prim / Araç Bedeli
  vehicleDetail?: string; // Araç / Varlık detay özeti
  businessType?: BusinessType; // Yenileme, Yeni İş, Takip
  company: string; // Sigorta şirketi
  branch: string; // Poliçe branşı
  policyNumber: string; // Poliçe numarası
  startDate: string; // Poliçe başlangıç tarihi
  endDate: string; // Poliçe bitiş / yenileme tarihi
  premium: number; // Prim TL
  status: 'Portföyde' | 'Yenileme Takibinde' | 'Sonuçlandı' | 'İptal'; // Yenileme durumu
  stage: PolicyStage;
  outcome?: PolicyOutcome;
  resultDate?: string; // Sonuçlanma tarihi
  originQuoteId?: string; // Eğer bir tekliften türetildiyse
  concludedReason?: string;
  // Kasko - Trafik Çapraz Satış Portföy Durumu
  trafficStatus?: 'TRAFİK BİZDE' | 'TRAFİK BİZDE DEĞİL';
  trafficEndDate?: string;
  trafficCompany?: string;
  trafficFollowUpQuoteId?: string; // İlişkili takip teklif ID'si
  // Kontrol listesi
  doc?: boolean; // Ruhsat kontrolü yapıldı
  endorse?: boolean; // Plaka zeyli yapıldı
  egm?: boolean; // EGM / TRAMER kontrol edildi
  notes?: string; // İş notları
  followDate?: string;
  createdAt: string;
  updatedAt: string;
}

export type NumericOperator =
  | 'equals' // Eşittir (=)
  | 'not_equals' // Eşit değildir (≠)
  | 'greater_than' // Büyüktür (>)
  | 'greater_than_or_equal' // Büyüktür veya eşittir (≥)
  | 'less_than' // Küçüktür (<)
  | 'less_than_or_equal' // Küçüktür veya eşittir (≤)
  | 'between'; // Arasındadır

export type TextOperator =
  | 'equals' // Eşittir (=)
  | 'not_equals'; // Eşit değildir (≠)

export type RuleField =
  | 'company'
  | 'branch'
  | 'insured'
  | 'vehicleYear'
  | 'usageStyle'
  | 'fuelType'
  | 'vehicleValue';

export interface RuleCondition {
  field: RuleField;
  operator: NumericOperator | TextOperator;
  value: string | number;
  value2?: string | number; // Arasındadır için ikinci değer (max)
}

export interface CustomRule {
  id: string;
  title: string;
  text: string;
  conditions?: RuleCondition[];
  // Eski kayıtların korunması için geriye dönük uyumluluk alanları:
  company?: string;
  branch?: string;
  minAge?: number | string;
  stage?: string;
  disabled?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface AppSettings {
  reminderDays: number[];
}

export interface AppData {
  quotes: Quote[];
  policies: Policy[];
  rules: CustomRule[];
  settings: AppSettings;
}

export const COMPANIES = [
  'AK SİGORTA',
  'ALLIANZ SİGORTA',
  'ANADOLU SİGORTA',
  'AXA SİGORTA',
  'DOĞA SİGORTA',
  'EUREKO SİGORTA',
  'HDI SİGORTA',
  'HEPIYI SİGORTA',
  'MAPFRE SİGORTA',
  'NEOVA SİGORTA',
  'RAY SİGORTA',
  'SOMPO SİGORTA',
  'TÜRKİYE SİGORTA',
] as const;

export type AuthorizedCompany = (typeof COMPANIES)[number];

export const BRANCHES = [
  'Kasko',
  'Trafik',
  'Konut',
  'DASK',
  'İşyeri',
  'Sağlık (ÖSS)',
  'Tamamlayıcı Sağlık (TSS)',
  'Ferdi Kaza',
  'Nakliyat',
  'Sorumluluk',
  'Seyahat Sağlık',
  'Diğer',
];

export const QUOTE_STAGES: QuoteStage[] = [
  'MÜŞTERİYE SUNULACAK',
  'İNDİRİM İSTENDİ',
  'İNDİRİMLİ PRİME REVİZE YAPILDI',
  'MÜŞTERİDEN YANIT BEKLENİYOR',
];

export const POLICY_STAGES: PolicyStage[] = [
  'Yürürlükte',
  'Yenileme Bekliyor',
  'Poliçe Düzenlendi',
  'Zeyil Aşamasında',
  'Süresi Doldu',
];

export const REJECTION_REASONS = [
  'MÜŞTERİ BAŞKA YERDEN YAPTIRDI',
  'MÜŞTERİ YAPTIRMADI',
  'MÜŞTERİYE ULAŞILAMADI',
  'ARAÇ SATILDI',
];
