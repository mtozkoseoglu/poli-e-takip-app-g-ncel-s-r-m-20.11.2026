import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { AppData, Quote, Policy, CustomRule } from './types/insurance';
import {
  loadAppData,
  saveAppData,
  generateSampleData,
  getTodayIso,
  addDays,
  generateId,
  calculateDaysLeft,
} from './services/storage';
import { Sidebar, TabType } from './components/Sidebar';
import { Header } from './components/Header';
import { DashboardView } from './components/DashboardView';
import { QuotesView } from './components/QuotesView';
import { ConcludedView } from './components/ConcludedView';
import { CalendarView } from './components/CalendarView';
import { RemindersView } from './components/RemindersView';
import { RulesView } from './components/RulesView';
import { BackupView } from './components/BackupView';
import { QuoteModal } from './components/QuoteModal';
import { PolicyModal } from './components/PolicyModal';
import { ConvertToPolicyModal } from './components/ConvertToPolicyModal';
import { ConcludeQuoteModal } from './components/ConcludeQuoteModal';
import { ConcludePolicyModal } from './components/ConcludePolicyModal';
import { QuoteProgressModal } from './components/QuoteProgressModal';
import { Toast } from './components/Toast';

export default function App() {
  const [appData, setAppData] = useState<AppData>(() => loadAppData());
  const [currentTab, setCurrentTab] = useState<TabType>('dashboard');
  const [concludedInitialFilter, setConcludedInitialFilter] = useState<'all' | 'converted' | 'rejected'>('all');
  const [remindersInitialFilter, setRemindersInitialFilter] = useState<'all' | 'urgent'>('all');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const handleNavigateTab = useCallback((tab: TabType, filterOption?: string) => {
    if (tab === 'concluded' || tab === 'policies') {
      setConcludedInitialFilter(filterOption === 'converted' ? 'converted' : 'all');
    }
    if (tab === 'reminders') {
      setRemindersInitialFilter(filterOption === 'urgent' ? 'urgent' : 'all');
    }
    setCurrentTab(tab);
  }, []);

  const handleSelectMenuTab = useCallback((tab: TabType) => {
    setConcludedInitialFilter('all');
    setRemindersInitialFilter('all');
    setCurrentTab(tab);
  }, []);

  // Modals state
  const [isQuoteModalOpen, setIsQuoteModalOpen] = useState(false);
  const [editingQuote, setEditingQuote] = useState<Quote | null>(null);

  const [isPolicyModalOpen, setIsPolicyModalOpen] = useState(false);
  const [editingPolicy, setEditingPolicy] = useState<Policy | null>(null);

  const [isConvertModalOpen, setIsConvertModalOpen] = useState(false);
  const [convertingQuote, setConvertingQuote] = useState<Quote | null>(null);

  const [isConcludeQuoteModalOpen, setIsConcludeQuoteModalOpen] = useState(false);
  const [concludingQuote, setConcludingQuote] = useState<Quote | null>(null);

  const [isConcludePolicyModalOpen, setIsConcludePolicyModalOpen] = useState(false);
  const [concludingPolicy, setConcludingPolicy] = useState<Policy | null>(null);

  const [isProgressModalOpen, setIsProgressModalOpen] = useState(false);
  const [progressModalQuote, setProgressModalQuote] = useState<Quote | null>(null);

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Auto-dismiss toast
  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3500);
  }, []);

  // Update storage whenever appData changes
  const updateData = useCallback((newData: AppData | ((prev: AppData) => AppData)) => {
    setAppData((prev) => {
      const next = typeof newData === 'function' ? newData(prev) : newData;
      saveAppData(next);
      return next;
    });
  }, []);

  // Handlers for Quotes
  const handleOpenNewQuote = () => {
    setEditingQuote(null);
    setIsQuoteModalOpen(true);
  };

  const handleEditQuote = (quote: Quote) => {
    setEditingQuote(quote);
    setIsQuoteModalOpen(true);
  };

  const handleSaveQuote = (quote: Quote) => {
    updateData((prev) => {
      const index = prev.quotes.findIndex((q) => q.id === quote.id);
      let updatedQuotes: Quote[];
      if (index >= 0) {
        updatedQuotes = [...prev.quotes];
        updatedQuotes[index] = quote;
      } else {
        updatedQuotes = [quote, ...prev.quotes];
      }
      return { ...prev, quotes: updatedQuotes };
    });
    showToast('Teklif başarıyla kaydedildi.');
  };

  const handleDeleteQuote = (id: string) => {
    updateData((prev) => ({
      ...prev,
      quotes: prev.quotes.filter((q) => q.id !== id),
    }));
    showToast('Teklif kaydı silindi.');
  };

  const handleOpenProgressModal = (quote: Quote) => {
    setProgressModalQuote(quote);
    setIsProgressModalOpen(true);
  };

  const handleUpdateQuote = (quote: Quote) => {
    handleSaveQuote(quote);
    setProgressModalQuote(quote);
  };

  // Handlers for Policies
  const handleOpenNewPolicy = () => {
    setEditingPolicy(null);
    setIsPolicyModalOpen(true);
  };

  const handleEditPolicy = (policy: Policy) => {
    setEditingPolicy(policy);
    setIsPolicyModalOpen(true);
  };

  // Sync follow-up quote for Kasko cross-sell when Trafik is not with us
  const syncKaskoCrossSellQuote = (
    policy: Policy,
    currentQuotes: Quote[]
  ): { updatedPolicy: Policy; updatedQuotes: Quote[] } => {
    if (policy.branch !== 'Kasko' || policy.trafficStatus !== 'TRAFİK BİZDE DEĞİL') {
      return { updatedPolicy: policy, updatedQuotes: currentQuotes };
    }

    const cleanPlate = (pl?: string) => (pl ? pl.replace(/\s+/g, '').toLocaleUpperCase('tr-TR') : '');
    const polPlate = cleanPlate(policy.plate);
    const polInsured = policy.insured.trim().toLocaleLowerCase('tr-TR');

    let existingIndex = -1;
    if (policy.trafficFollowUpQuoteId) {
      existingIndex = currentQuotes.findIndex((q) => q.id === policy.trafficFollowUpQuoteId);
    }
    if (existingIndex === -1) {
      existingIndex = currentQuotes.findIndex((q) => {
        const qPlate = cleanPlate(q.plate);
        const qInsured = q.insured.trim().toLocaleLowerCase('tr-TR');
        const isMatch = polPlate && qPlate ? polPlate === qPlate : polInsured === qInsured;
        return isMatch && q.branch === 'Trafik' && q.businessType === 'Takip' && q.status !== 'concluded';
      });
    }

    const nowIso = new Date().toISOString();
    let updatedPolicy = { ...policy };
    let updatedQuotes = [...currentQuotes];

    if (existingIndex >= 0) {
      const existing = currentQuotes[existingIndex];
      const updatedQuote: Quote = {
        ...existing,
        insured: policy.insured,
        phone: policy.phone || existing.phone,
        email: policy.email || existing.email,
        plate: policy.plate || existing.plate,
        chassisNo: policy.chassisNo || existing.chassisNo,
        engineNo: policy.engineNo || existing.engineNo,
        vehicleBrand: policy.vehicleBrand || existing.vehicleBrand,
        vehicleModel: policy.vehicleModel || existing.vehicleModel,
        vehicleYear: policy.vehicleYear || existing.vehicleYear,
        vehicleCode: policy.vehicleCode || existing.vehicleCode,
        fuelType: policy.fuelType || existing.fuelType,
        company: policy.trafficCompany || existing.company,
        validUntil: policy.trafficEndDate || existing.validUntil,
        followDate: policy.trafficEndDate || existing.followDate,
        updatedAt: nowIso,
      };
      updatedQuotes[existingIndex] = updatedQuote;
      updatedPolicy.trafficFollowUpQuoteId = updatedQuote.id;
    } else {
      const newQuoteId = generateId();
      const newQuote: Quote = {
        id: newQuoteId,
        type: 'quote',
        quoteNumber: 'TKP-' + Math.floor(100000 + Math.random() * 900000),
        insured: policy.insured,
        phone: policy.phone || '',
        email: policy.email || '',
        plate: policy.plate || '',
        chassisNo: policy.chassisNo || '',
        engineNo: policy.engineNo || '',
        vehicleBrand: policy.vehicleBrand || '',
        vehicleModel: policy.vehicleModel || '',
        vehicleYear: policy.vehicleYear,
        vehicleCode: policy.vehicleCode || '',
        fuelType: policy.fuelType || '',
        businessType: 'Takip',
        branch: 'Trafik',
        company: policy.trafficCompany || 'TÜRKİYE SİGORTA',
        quoteDate: getTodayIso(),
        validUntil: policy.trafficEndDate || policy.endDate,
        followDate: policy.trafficEndDate || policy.endDate,
        premium: 0,
        stage: 'MÜŞTERİYE SUNULACAK',
        status: 'active',
        quoteStatus: 'beklemede',
        notes: `Kasko poliçesi (${policy.policyNumber}) kaydından oluşturulan Trafik çapraz satış takibi.`,
        createdAt: nowIso,
        updatedAt: nowIso,
      };
      updatedQuotes = [newQuote, ...updatedQuotes];
      updatedPolicy.trafficFollowUpQuoteId = newQuoteId;
    }

    return { updatedPolicy, updatedQuotes };
  };

  const handleSavePolicy = (policy: Policy) => {
    updateData((prev) => {
      const { updatedPolicy, updatedQuotes } = syncKaskoCrossSellQuote(policy, prev.quotes);
      const index = prev.policies.findIndex((p) => p.id === updatedPolicy.id);
      let updatedPolicies: Policy[];
      if (index >= 0) {
        updatedPolicies = [...prev.policies];
        updatedPolicies[index] = updatedPolicy;
      } else {
        updatedPolicies = [updatedPolicy, ...prev.policies];
      }
      return { ...prev, policies: updatedPolicies, quotes: updatedQuotes };
    });
    showToast(
      policy.branch === 'Kasko' && policy.trafficStatus === 'TRAFİK BİZDE DEĞİL'
        ? 'Poliçe kaydedildi ve Takipteki İşler için Trafik teklifi oluşturuldu/güncellendi.'
        : 'Poliçe başarıyla kaydedildi.'
    );
  };

  const handleDeletePolicy = (id: string) => {
    updateData((prev) => ({
      ...prev,
      policies: prev.policies.filter((p) => p.id !== id),
    }));
    showToast('Poliçe kaydı silindi.');
  };

  // Convert Quote to Policy (Olumlu Sonuç)
  const handleStartConvertToPolicy = (quote: Quote) => {
    setConvertingQuote(quote);
    setIsConvertModalOpen(true);
  };

  const handleConfirmConvertToPolicy = (quoteId: string, createdPolicy: Policy) => {
    const todayStr = getTodayIso();
    updateData((prev) => {
      // 1. Mark quote as converted and concluded
      const updatedQuotes = prev.quotes.map((q) => {
        if (q.id === quoteId) {
          return {
            ...q,
            status: 'concluded' as const,
            quoteStatus: 'kabul_edildi' as const,
            outcome: 'converted' as const,
            convertedPolicyId: createdPolicy.id,
            rejectionReason: undefined,
            nonConversionReason: undefined,
            resultDate: todayStr,
            updatedAt: new Date().toISOString(),
          };
        }
        return q;
      });

      // 2. Mark previous policy for this vehicle/insured & branch as renewed/concluded
      const cleanPlate = (pl?: string) => (pl ? pl.replace(/\s+/g, '').toLocaleUpperCase('tr-TR') : '');
      const newPlate = cleanPlate(createdPolicy.plate);
      const newInsured = createdPolicy.insured.trim().toLocaleLowerCase('tr-TR');
      const newBranch = createdPolicy.branch.trim().toLocaleLowerCase('tr-TR');

      const updatedPoliciesList = prev.policies.map((p) => {
        const oldPlate = cleanPlate(p.plate);
        const oldInsured = p.insured.trim().toLocaleLowerCase('tr-TR');
        const oldBranch = p.branch.trim().toLocaleLowerCase('tr-TR');

        const isSameTarget = newPlate && oldPlate
          ? newPlate === oldPlate
          : newInsured === oldInsured && newBranch === oldBranch;

        if (isSameTarget && p.id !== createdPolicy.id && p.status !== 'Sonuçlandı') {
          return {
            ...p,
            status: 'Sonuçlandı' as const,
            outcome: 'renewed' as const,
            concludedReason: `Yenilendi - Yeni Poliçe No: ${createdPolicy.policyNumber}`,
            resultDate: todayStr,
            updatedAt: new Date().toISOString(),
          };
        }
        return p;
      });

      // 3. Sync Kasko cross-sell follow-up quote if applicable
      const { updatedPolicy: finalCreatedPolicy, updatedQuotes: syncedQuotes } = syncKaskoCrossSellQuote(
        createdPolicy,
        updatedQuotes
      );

      // 4. Add newly created policy
      const updatedPolicies = [finalCreatedPolicy, ...updatedPoliciesList];

      return {
        ...prev,
        quotes: syncedQuotes,
        policies: updatedPolicies,
      };
    });

    showToast('🎉 Teklif poliçeye dönüştürüldü! "Sonuçlananlar" sekmesine aktarıldı.');
  };

  // Conclude Quote Negatively (Yapılmadı / Reddedildi)
  const handleStartConcludeNegative = (quote: Quote) => {
    setConcludingQuote(quote);
    setIsConcludeQuoteModalOpen(true);
  };

  const handleConfirmConcludeNegative = (quoteId: string, reason: string, note: string) => {
    const todayStr = getTodayIso();
    updateData((prev) => {
      const updatedQuotes = prev.quotes.map((q) => {
        if (q.id === quoteId) {
          return {
            ...q,
            status: 'concluded' as const,
            quoteStatus: 'reddedildi' as const,
            outcome: 'rejected' as const,
            rejectionReason: reason,
            nonConversionReason: reason,
            rejectionNote: note,
            resultDate: todayStr,
            updatedAt: new Date().toISOString(),
          };
        }
        return q;
      });
      return { ...prev, quotes: updatedQuotes };
    });

    showToast('Teklif "Sonuçlananlar" sekmesine "Yapılmadı" olarak aktarıldı.');
  };

  // Conclude Active Policy (Süresi Doldu / Arşivlendi)
  const handleStartConcludePolicy = (policy: Policy) => {
    setConcludingPolicy(policy);
    setIsConcludePolicyModalOpen(true);
  };

  const handleConfirmConcludePolicy = (
    policyId: string,
    outcome: 'completed' | 'cancelled' | 'renewed',
    reason: string
  ) => {
    const todayStr = getTodayIso();
    updateData((prev) => {
      const updatedPolicies = prev.policies.map((p) => {
        if (p.id === policyId) {
          return {
            ...p,
            status: 'Sonuçlandı' as const,
            outcome,
            concludedReason: reason,
            resultDate: todayStr,
            updatedAt: new Date().toISOString(),
          };
        }
        return p;
      });
      return { ...prev, policies: updatedPolicies };
    });

    showToast('Poliçe sonuçlandırıldı ve "Sonuçlananlar" sekmesine aktarıldı.');
  };

  // Re-open concluded items
  const handleReopenQuote = (quoteId: string) => {
    updateData((prev) => {
      const updatedQuotes = prev.quotes.map((q) => {
        if (q.id === quoteId) {
          return {
            ...q,
            status: 'active' as const,
            outcome: undefined,
            resultDate: undefined,
            rejectionReason: undefined,
            rejectionNote: undefined,
            updatedAt: new Date().toISOString(),
          };
        }
        return q;
      });
      return { ...prev, quotes: updatedQuotes };
    });
    showToast('Teklif tekrar aktif listeye alındı.');
  };

  const handleReopenPolicy = (policyId: string) => {
    updateData((prev) => {
      const updatedPolicies = prev.policies.map((p) => {
        if (p.id === policyId) {
          return {
            ...p,
            status: 'Portföyde' as const,
            outcome: undefined,
            resultDate: undefined,
            concludedReason: undefined,
            updatedAt: new Date().toISOString(),
          };
        }
        return p;
      });
      return { ...prev, policies: updatedPolicies };
    });
    showToast('Poliçe tekrar aktif portföye alındı.');
  };

  // Create renewal quote from existing policy
  const handleCreateRenewalQuote = (policy: Policy) => {
    const newQuote: Quote = {
      id: generateId(),
      type: 'quote',
      insured: policy.insured,
      phone: policy.phone || '',
      email: policy.email || '',
      plate: policy.plate || '',
      vehicleBrand: policy.vehicleBrand || '',
      vehicleModel: policy.vehicleModel || '',
      vehicleYear: policy.vehicleYear,
      vehicleDetail: policy.vehicleDetail || '',
      company: policy.company,
      branch: policy.branch,
      quoteNumber: 'TK-' + new Date().getFullYear() + '-' + Math.floor(100 + Math.random() * 900),
      quoteDate: getTodayIso(),
      validUntil: addDays(15),
      premium: policy.premium || 0,
      stage: 'MÜŞTERİYE SUNULACAK',
      status: 'active',
      notes: `${policy.policyNumber} nolu poliçenin yenileme teklifidir.`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setEditingQuote(newQuote);
    setIsQuoteModalOpen(true);
  };

  const handleNavigateToPolicy = (policyId: string) => {
    const pol = appData.policies.find((p) => p.id === policyId);
    if (pol) {
      handleNavigateTab('concluded', 'converted');
      handleEditPolicy(pol);
    }
  };

  // Rules & Settings Handlers
  const handleSaveReminderDays = (days: number[]) => {
    updateData((prev) => ({
      ...prev,
      settings: { ...prev.settings, reminderDays: days },
    }));
    showToast('Hatırlatma günleri güncellendi.');
  };

  const handleSaveRule = (rule: CustomRule) => {
    updateData((prev) => {
      const idx = prev.rules.findIndex((r) => r.id === rule.id);
      let updated: CustomRule[];
      if (idx >= 0) {
        updated = [...prev.rules];
        updated[idx] = rule;
      } else {
        updated = [rule, ...prev.rules];
      }
      return { ...prev, rules: updated };
    });
    showToast('Kontrol kuralı kaydedildi.');
  };

  const handleDeleteRule = (id: string) => {
    updateData((prev) => ({
      ...prev,
      rules: prev.rules.filter((r) => r.id !== id),
    }));
    showToast('Kural silindi.');
  };

  // Backup & Reset Handlers
  const handleRestoreData = (restored: AppData) => {
    updateData(restored);
  };

  const handleResetToSample = () => {
    const sample = generateSampleData();
    updateData(sample);
  };

  // Live badge counts
  const activeQuotesCount = useMemo(() => {
    return appData.quotes.filter((q) => q.status === 'active').length;
  }, [appData.quotes]);

  const activePoliciesCount = useMemo(() => {
    return appData.policies.length;
  }, [appData.policies]);

  const rejectedQuotesCount = useMemo(() => {
    return appData.quotes.filter((q) => q.status === 'concluded' && q.outcome !== 'converted').length;
  }, [appData.quotes]);

  const concludedCount = useMemo(() => {
    // Total distinct concluded records: all policies (Poliçeleşenler) + rejected quotes (Poliçeleşmeyenler)
    // Converted quotes are represented by their policy record and therefore never counted twice!
    return activePoliciesCount + rejectedQuotesCount;
  }, [activePoliciesCount, rejectedQuotesCount]);

  const urgentRemindersCount = useMemo(() => {
    return appData.policies.filter((p) => {
      if (p.status === 'Sonuçlandı') return false;
      const days = calculateDaysLeft(p.endDate);
      return days !== null && days <= 7;
    }).length;
  }, [appData.policies]);

  return (
    <div className="flex h-screen bg-slate-100 font-sans text-slate-800 antialiased overflow-hidden">
      {/* Sidebar for Desktop */}
      <div className="hidden md:flex shrink-0">
        <Sidebar
          currentTab={currentTab}
          onSelectTab={handleSelectMenuTab}
          activeQuotesCount={activeQuotesCount}
          activePoliciesCount={activePoliciesCount}
          concludedCount={concludedCount}
          urgentRemindersCount={urgentRemindersCount}
        />
      </div>

      {/* Mobile Sidebar overlay */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 flex md:hidden">
          <div className="fixed inset-0 bg-slate-900/60" onClick={() => setMobileMenuOpen(false)} />
          <div className="relative z-50 flex">
            <Sidebar
              currentTab={currentTab}
              onSelectTab={(tab) => {
                handleSelectMenuTab(tab);
                setMobileMenuOpen(false);
              }}
              activeQuotesCount={activeQuotesCount}
              activePoliciesCount={activePoliciesCount}
              concludedCount={concludedCount}
              urgentRemindersCount={urgentRemindersCount}
            />
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Header
          currentTab={currentTab}
          onOpenNewQuote={handleOpenNewQuote}
          onOpenNewPolicy={handleOpenNewPolicy}
          onToggleMobileMenu={() => setMobileMenuOpen(true)}
        />

        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <div className="max-w-7xl mx-auto">
            {currentTab === 'dashboard' && (
              <DashboardView
                quotes={appData.quotes}
                policies={appData.policies}
                onOpenNewQuote={handleOpenNewQuote}
                onOpenNewPolicy={handleOpenNewPolicy}
                onViewQuote={handleEditQuote}
                onViewPolicy={handleEditPolicy}
                onConvertToPolicy={handleStartConvertToPolicy}
                onNavigateTab={handleNavigateTab}
              />
            )}

            {currentTab === 'quotes' && (
              <QuotesView
                quotes={appData.quotes}
                onOpenNewQuote={handleOpenNewQuote}
                onEditQuote={handleEditQuote}
                onOpenConcludeModal={(quote) => {
                  setConcludingQuote(quote);
                  setIsConcludeQuoteModalOpen(true);
                }}
                onConvertToPolicy={handleStartConvertToPolicy}
                onConcludeNegative={handleStartConcludeNegative}
                onOpenProgressModal={handleOpenProgressModal}
                onUpdateQuote={handleUpdateQuote}
                showToast={showToast}
              />
            )}

            {(currentTab === 'concluded' || currentTab === 'policies') && (
              <ConcludedView
                quotes={appData.quotes}
                policies={appData.policies}
                onOpenNewPolicy={handleOpenNewPolicy}
                onEditPolicy={handleEditPolicy}
                onDeletePolicy={handleDeletePolicy}
                onViewQuote={handleEditQuote}
                onDeleteQuote={handleDeleteQuote}
                onReopenQuote={handleReopenQuote}
                onCreateRenewalQuote={handleCreateRenewalQuote}
                initialStatusFilter={concludedInitialFilter}
              />
            )}

            {currentTab === 'calendar' && (
              <CalendarView
                quotes={appData.quotes}
                policies={appData.policies}
                onViewQuote={handleEditQuote}
                onViewPolicy={handleEditPolicy}
              />
            )}

            {currentTab === 'reminders' && (
              <RemindersView
                quotes={appData.quotes}
                policies={appData.policies}
                reminderDays={appData.settings.reminderDays}
                onViewQuote={handleEditQuote}
                onViewPolicy={handleEditPolicy}
                onConvertToPolicy={handleStartConvertToPolicy}
                initialFilter={remindersInitialFilter}
              />
            )}

            {currentTab === 'rules' && (
              <RulesView
                rules={appData.rules}
                reminderDays={appData.settings.reminderDays}
                onSaveReminderDays={handleSaveReminderDays}
                onSaveRule={handleSaveRule}
                onDeleteRule={handleDeleteRule}
              />
            )}

            {currentTab === 'backup' && (
              <BackupView
                appData={appData}
                onRestoreData={handleRestoreData}
                onResetToSample={handleResetToSample}
                showToast={showToast}
              />
            )}
          </div>
        </main>
      </div>

      {/* Quote Modal */}
      <QuoteModal
        isOpen={isQuoteModalOpen}
        onClose={() => setIsQuoteModalOpen(false)}
        onSave={handleSaveQuote}
        onDelete={handleDeleteQuote}
        onConvertToPolicy={handleStartConvertToPolicy}
        onConcludeNegative={handleStartConcludeNegative}
        initialQuote={editingQuote}
      />

      {/* Policy Modal */}
      <PolicyModal
        isOpen={isPolicyModalOpen}
        onClose={() => setIsPolicyModalOpen(false)}
        onSave={handleSavePolicy}
        onDelete={handleDeletePolicy}
        onConclude={handleStartConcludePolicy}
        onCreateRenewalQuote={handleCreateRenewalQuote}
        initialPolicy={editingPolicy}
        rules={appData.rules}
      />

      {/* Convert Quote to Policy Modal */}
      <ConvertToPolicyModal
        isOpen={isConvertModalOpen}
        onClose={() => setIsConvertModalOpen(false)}
        quote={convertingQuote}
        onConfirm={handleConfirmConvertToPolicy}
      />

      {/* Unified Conclude Quote Modal (Positive with Company Offers & Negative with Reason) */}
      <ConcludeQuoteModal
        isOpen={isConcludeQuoteModalOpen}
        onClose={() => setIsConcludeQuoteModalOpen(false)}
        quote={concludingQuote}
        onConfirmPositive={handleConfirmConvertToPolicy}
        onConfirmNegative={handleConfirmConcludeNegative}
      />

      {/* Conclude Active Policy Modal */}
      <ConcludePolicyModal
        isOpen={isConcludePolicyModalOpen}
        onClose={() => setIsConcludePolicyModalOpen(false)}
        policy={concludingPolicy}
        onConfirm={handleConfirmConcludePolicy}
      />

      {/* Quote Progress Tracking Modal */}
      <QuoteProgressModal
        isOpen={isProgressModalOpen}
        onClose={() => setIsProgressModalOpen(false)}
        quote={progressModalQuote}
        onUpdateQuote={handleUpdateQuote}
        onConvertToPolicy={handleStartConvertToPolicy}
        onConcludeNegative={handleStartConcludeNegative}
      />

      {/* Toast Notification */}
      <Toast message={toastMessage} />
    </div>
  );
}
