import React, { useRef } from 'react';
import { AppData, Quote, Policy } from '../types/insurance';
import {
  exportToJsonString,
  downloadFile,
  getTodayIso,
  exportPoliciesToCsv,
  exportQuotesToCsv,
  generateSampleData,
  sanitizeQuoteData,
  sanitizePolicyData,
} from '../services/storage';
import { Database, Download, Upload, RefreshCw, FileSpreadsheet, AlertTriangle, CheckCircle2 } from 'lucide-react';

interface Props {
  appData: AppData;
  onRestoreData: (data: AppData) => void;
  onResetToSample: () => void;
  showToast: (msg: string) => void;
}

export const BackupView: React.FC<Props> = ({ appData, onRestoreData, onResetToSample, showToast }) => {
  const jsonInputRef = useRef<HTMLInputElement>(null);

  const handleExportJson = () => {
    const jsonStr = exportToJsonString(appData);
    downloadFile(`sigorta-takip-yedek-${getTodayIso()}.json`, jsonStr, 'application/json;charset=utf-8');
    showToast('JSON tam yedeği indirildi.');
  };

  const handleImportJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(reader.result as string);
        if (!parsed.policies && !parsed.quotes) {
          throw new Error('Geçersiz format');
        }

        const restoredData: AppData = {
          quotes: Array.isArray(parsed.quotes) ? parsed.quotes.map(sanitizeQuoteData) : [],
          policies: Array.isArray(parsed.policies) ? parsed.policies.map(sanitizePolicyData) : [],
          rules: Array.isArray(parsed.rules) ? parsed.rules : [],
          settings: parsed.settings || { reminderDays: [30, 15, 7, 3, 1] },
        };

        const ok = window.confirm(
          `Yedek dosyasından ${restoredData.quotes.length} teklif ve ${restoredData.policies.length} poliçe yüklenecek. Mevcut kayıtlarınızın üzerine yazılacaktır. Devam etmek istiyor musunuz?`
        );
        if (ok) {
          onRestoreData(restoredData);
          showToast('Yedek başarıyla geri yüklendi.');
        }
      } catch (err) {
        alert('Yedek dosyası okunamadı. Lütfen geçerli bir JSON yedek dosyası seçiniz.');
      } finally {
        if (jsonInputRef.current) jsonInputRef.current.value = '';
      }
    };
    reader.readAsText(file);
  };

  const activePoliciesCount = appData.policies.filter((p) => p.status !== 'Sonuçlandı').length;
  const activeQuotesCount = appData.quotes.filter((q) => q.status === 'active').length;
  const concludedQuotesCount = appData.quotes.filter((q) => q.status === 'concluded').length;
  const concludedPoliciesCount = appData.policies.filter((p) => p.status === 'Sonuçlandı').length;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
          <Database className="w-6 h-6 text-slate-700" />
          <span>Excel & Yedekleme Yönetimi</span>
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Verilerinizi Excel uyumlu CSV olarak indirin, tam JSON yedeği alın veya yedekten geri yükleyin.
        </p>
      </div>

      <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl flex items-start gap-3 text-xs text-amber-900">
        <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <div>
          <strong>Yerel Veri Saklama:</strong> Tüm verileriniz tarayıcınızın güvenli yerel depolama alanında
          saklanmaktadır. Veri kaybını önlemek amacıyla düzenli olarak <strong>JSON Yedeği</strong> almanız önerilir.
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Card 1: JSON Backup */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-sm font-bold text-slate-900 mb-1">
              <Database className="w-4 h-4 text-blue-600" />
              <span>Tam JSON Yedekleme</span>
            </div>
            <p className="text-xs text-slate-500 mb-4">
              Tüm teklifler, poliçeler, sonuçlanan kayıtlar ve ayarlar tek bir dosyada güvenle yedeklenir.
            </p>

            <div className="space-y-2 mb-6 text-xs text-slate-600">
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span>Aktif Teklifler</span>
                <strong className="text-slate-800">{activeQuotesCount}</strong>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span>Aktif Poliçeler</span>
                <strong className="text-slate-800">{activePoliciesCount}</strong>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span>Sonuçlanan Kayıtlar</span>
                <strong className="text-slate-800">{concludedQuotesCount + concludedPoliciesCount}</strong>
              </div>
            </div>
          </div>

          <div className="space-y-2.5">
            <button
              onClick={handleExportJson}
              className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-2"
            >
              <Download className="w-4 h-4" />
              <span>JSON Yedeği İndir</span>
            </button>

            <button
              onClick={() => jsonInputRef.current?.click()}
              className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-colors cursor-pointer flex items-center justify-center gap-2"
            >
              <Upload className="w-4 h-4 text-slate-500" />
              <span>JSON Yedeğini Geri Yükle</span>
            </button>
            <input
              ref={jsonInputRef}
              type="file"
              accept=".json,application/json"
              onChange={handleImportJson}
              className="hidden"
            />
          </div>
        </div>

        {/* Card 2: Excel / CSV Export */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-sm font-bold text-slate-900 mb-1">
              <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
              <span>Excel (CSV) Aktarımı</span>
            </div>
            <p className="text-xs text-slate-500 mb-4">
              Microsoft Excel ve Google E-Tablolar ile tam uyumlu UTF-8 Türkçe karakter destekli CSV dosyaları.
            </p>

            <div className="space-y-2 mb-6">
              <button
                onClick={() => {
                  exportQuotesToCsv(appData.quotes);
                  showToast('Teklifler CSV olarak indirildi.');
                }}
                className="w-full py-2 px-3 text-xs font-semibold text-slate-800 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl flex items-center justify-between cursor-pointer"
              >
                <span>Teklif Listesini Excel Olarak İndir</span>
                <Download className="w-4 h-4 text-slate-500" />
              </button>

              <button
                onClick={() => {
                  exportPoliciesToCsv(appData.policies);
                  showToast('Poliçeler CSV olarak indirildi.');
                }}
                className="w-full py-2 px-3 text-xs font-semibold text-slate-800 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl flex items-center justify-between cursor-pointer"
              >
                <span>Poliçe Portföyünü Excel Olarak İndir</span>
                <Download className="w-4 h-4 text-slate-500" />
              </button>
            </div>
          </div>

          <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
            <div className="flex items-center justify-between">
              <div className="text-xs text-slate-600">
                <span className="font-semibold block text-slate-800">Örnek Veri Setini Yükle</span>
                <span>Test için zengin Türkçe sigorta kayıtları</span>
              </div>
              <button
                onClick={() => {
                  if (confirm('UYARI: Bu işlem mevcut tüm kayıtlarınızı örnek (demo) verilerle değiştirecektir ve geri alınamaz. Gerçek verileriniz silinmeden önce lütfen JSON yedeği aldığınızdan emin olun. Devam etmek istiyor musunuz?')) {
                    onResetToSample();
                    showToast('Örnek veriler başarıyla yüklendi.');
                  }
                }}
                className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-lg text-xs font-semibold flex items-center gap-1 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Yükle</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
