import React, { useState, useMemo } from 'react';
import { Policy, COMPANIES, BRANCHES, POLICY_STAGES } from '../types/insurance';
import {
  calculateDaysLeft,
  formatCurrency,
  formatDateTr,
  exportPoliciesToCsv,
  calculateMultiplier,
  formatMultiplier,
} from '../services/storage';
import {
  Search,
  Filter,
  Plus,
  Shield,
  Download,
  AlertTriangle,
  Clock,
  CheckCircle,
  FileCheck,
  RefreshCw,
  Archive,
  Phone,
} from 'lucide-react';

interface Props {
  policies: Policy[];
  onOpenNewPolicy: () => void;
  onEditPolicy: (policy: Policy) => void;
  onConcludePolicy: (policy: Policy) => void;
  onCreateRenewalQuote: (policy: Policy) => void;
}

export const PoliciesView: React.FC<Props> = ({
  policies,
  onOpenNewPolicy,
  onEditPolicy,
  onConcludePolicy,
  onCreateRenewalQuote,
}) => {
  const [search, setSearch] = useState('');
  const [filterCompany, setFilterCompany] = useState('');
  const [filterBranch, setFilterBranch] = useState('');
  const [filterTimeframe, setFilterTimeframe] = useState('');

  // Active policies only (completed/concluded policies belong in "Sonuçlananlar")
  const activePolicies = useMemo(() => {
    return policies.filter((p) => p.status !== 'Sonuçlandı' && p.status !== 'İptal');
  }, [policies]);

  const filteredPolicies = useMemo(() => {
    const q = search.toLocaleLowerCase('tr-TR').trim();
    return activePolicies
      .filter((item) => {
        const matchesSearch =
          !q ||
          item.insured.toLocaleLowerCase('tr-TR').includes(q) ||
          (item.plate && item.plate.toLocaleLowerCase('tr-TR').includes(q)) ||
          (item.vehicleBrand && item.vehicleBrand.toLocaleLowerCase('tr-TR').includes(q)) ||
          (item.vehicleModel && item.vehicleModel.toLocaleLowerCase('tr-TR').includes(q)) ||
          (item.phone && item.phone.includes(q)) ||
          (item.email && item.email.toLocaleLowerCase('tr-TR').includes(q)) ||
          (item.policyNumber && item.policyNumber.toLocaleLowerCase('tr-TR').includes(q)) ||
          item.company.toLocaleLowerCase('tr-TR').includes(q) ||
          item.branch.toLocaleLowerCase('tr-TR').includes(q);

        const matchesCompany = !filterCompany || item.company === filterCompany;
        const matchesBranch = !filterBranch || item.branch === filterBranch;

        let matchesTime = true;
        const days = calculateDaysLeft(item.endDate);
        if (filterTimeframe === 'overdue') {
          matchesTime = days !== null && days < 0;
        } else if (filterTimeframe === '7days') {
          matchesTime = days !== null && days >= 0 && days <= 7;
        } else if (filterTimeframe === '14days') {
          matchesTime = days !== null && days >= 0 && days <= 14;
        } else if (filterTimeframe === '30days') {
          matchesTime = days !== null && days >= 0 && days <= 30;
        }

        return matchesSearch && matchesCompany && matchesBranch && matchesTime;
      })
      .sort((a, b) => {
        const daysA = calculateDaysLeft(a.endDate) ?? 9999;
        const daysB = calculateDaysLeft(b.endDate) ?? 9999;
        return daysA - daysB;
      });
  }, [activePolicies, search, filterCompany, filterBranch, filterTimeframe]);

  // Metrics
  const totalPortfolioPremium = activePolicies.reduce((acc, curr) => acc + (curr.premium || 0), 0);
  const overdueCount = activePolicies.filter((p) => {
    const d = calculateDaysLeft(p.endDate);
    return d !== null && d < 0;
  }).length;
  const criticalCount = activePolicies.filter((p) => {
    const d = calculateDaysLeft(p.endDate);
    return d !== null && d >= 0 && d <= 7;
  }).length;
  const next30DaysCount = activePolicies.filter((p) => {
    const d = calculateDaysLeft(p.endDate);
    return d !== null && d >= 0 && d <= 30;
  }).length;

  const getDaysLeftBadge = (days: number | null) => {
    if (days === null) return <span className="text-xs text-slate-400">Tarih yok</span>;
    if (days < 0) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-50 text-rose-700 border border-rose-200">
          <AlertTriangle className="w-3 h-3 text-rose-500" />
          {Math.abs(days)} gün gecikti
        </span>
      );
    }
    if (days <= 7) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-50 text-rose-700 border border-rose-200">
          Kritik ({days === 0 ? 'Bugün!' : `${days} gün`})
        </span>
      );
    }
    if (days <= 14) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-50 text-amber-700 border border-amber-200">
          {days} gün kaldı
        </span>
      );
    }
    if (days <= 30) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200">
          {days} gün kaldı
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
        {days} gün var
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Action */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <span>Poliçeler</span>
            <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-700">
              {activePolicies.length} Aktif Portföy
            </span>
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Mevcut portföyünüzdeki yürürlükte olan poliçeler, bitiş tarihleri ve yenileme kontrolleri.
          </p>
        </div>
        <div className="flex items-center gap-2.5 w-full sm:w-auto">
          <button
            onClick={() => exportPoliciesToCsv(activePolicies)}
            className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-xl shadow-2xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4 text-slate-500" />
            <span>CSV İndir</span>
          </button>
          <button
            onClick={onOpenNewPolicy}
            className="flex-1 sm:flex-none px-4 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>＋ Yeni Poliçe Kaydı</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Aktif Portföy</span>
            <Shield className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl font-black text-slate-900 mt-2">{activePolicies.length}</div>
          <div className="text-xs text-slate-500 mt-0.5">Yürürlükteki poliçeler</div>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Toplam Portföy Primi</span>
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
          </div>
          <div className="text-xl font-black text-emerald-700 mt-2">{formatCurrency(totalPortfolioPremium)}</div>
          <div className="text-xs text-slate-500 mt-0.5">Aktif toplam prim hacmi</div>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Gecikmiş Yenilemeler</span>
            <span className="w-2 h-2 rounded-full bg-rose-500" />
          </div>
          <div className="text-2xl font-black text-rose-700 mt-2">{overdueCount}</div>
          <div className="text-xs text-slate-500 mt-0.5">Bitiş tarihi geçmiş poliçe</div>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>30 Gün İçinde Biten</span>
            <Clock className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-black text-amber-700 mt-2">{next30DaysCount}</div>
          <div className="text-xs text-slate-500 mt-0.5">Öncelikli yenileme takibi</div>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs space-y-3">
        <div className="flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Sigortalı adı, plaka, poliçe no veya telefon ara..."
              className="w-full pl-9 pr-4 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none"
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              value={filterTimeframe}
              onChange={(e) => setFilterTimeframe(e.target.value)}
              className="px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white outline-none font-semibold text-slate-800"
            >
              <option value="">Tüm Zamanlar</option>
              <option value="overdue">🚨 Sadece Gecikmişler</option>
              <option value="7days">⚠️ 7 Gün İçinde Bitenler</option>
              <option value="14days">📅 14 Gün İçinde Bitenler</option>
              <option value="30days">🗓️ 30 Gün İçinde Bitenler</option>
            </select>

            <select
              value={filterCompany}
              onChange={(e) => setFilterCompany(e.target.value)}
              className="px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white outline-none"
            >
              <option value="">Tüm Şirketler</option>
              {COMPANIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>

            <select
              value={filterBranch}
              onChange={(e) => setFilterBranch(e.target.value)}
              className="px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white outline-none"
            >
              <option value="">Tüm Branşlar</option>
              {BRANCHES.map((b) => (
                <option key={b} value={b}>
                  {b}
                </option>
              ))}
            </select>

            {(search || filterCompany || filterBranch || filterTimeframe) && (
              <button
                onClick={() => {
                  setSearch('');
                  setFilterCompany('');
                  setFilterBranch('');
                  setFilterTimeframe('');
                }}
                className="px-3 py-2 text-xs font-semibold text-rose-600 hover:bg-rose-50 rounded-xl transition-colors cursor-pointer"
              >
                Sıfırla
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Policies Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs whitespace-nowrap">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider">
                <th className="py-3.5 px-4">Sigortalı / İletişim</th>
                <th className="py-3.5 px-4">Plaka / Varlık</th>
                <th className="py-3.5 px-4">Şirket & Branş</th>
                <th className="py-3.5 px-4">Poliçe No</th>
                <th className="py-3.5 px-4">Bitiş Tarihi</th>
                <th className="py-3.5 px-4">Kalan Gün</th>
                <th className="py-3.5 px-4 text-right">Araç Bedeli</th>
                <th className="py-3.5 px-4 text-right">Prim (TL)</th>
                <th className="py-3.5 px-4 text-center">Çarpan (Prim/Bedel)</th>
                <th className="py-3.5 px-4 text-center">Kontrol</th>
                <th className="py-3.5 px-4 text-center">İşlem</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredPolicies.length > 0 ? (
                filteredPolicies.map((policy) => {
                  const daysLeft = calculateDaysLeft(policy.endDate);
                  const multiplier = calculateMultiplier(policy.premium, policy.vehicleValue);
                  return (
                    <tr key={policy.id} className="hover:bg-slate-50/80 transition-colors group">
                      {/* Sigortalı */}
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-900 text-sm">{policy.insured}</div>
                        <div className="text-slate-500 flex items-center gap-2 mt-0.5">
                          {policy.phone ? (
                            <span className="flex items-center gap-1 text-slate-600">
                              <Phone className="w-3 h-3 text-slate-400" />
                              {policy.phone}
                            </span>
                          ) : policy.email ? (
                            <span className="text-slate-400 text-xs truncate max-w-[150px]">{policy.email}</span>
                          ) : (
                            <span className="text-slate-400 text-xs">İletişim belirtilmedi</span>
                          )}
                        </div>
                      </td>

                      {/* Plaka & Araç */}
                      <td className="py-3.5 px-4">
                        {policy.plate ? (
                          <div className="inline-block px-2 py-0.5 font-mono font-bold text-xs bg-slate-100 border border-slate-300 rounded text-slate-800">
                            {policy.plate}
                          </div>
                        ) : (
                          <span className="text-slate-400">—</span>
                        )}
                        {(policy.vehicleBrand || policy.vehicleModel) ? (
                          <div className="text-slate-700 font-semibold text-xs mt-0.5 max-w-[160px] truncate">
                            {policy.vehicleYear ? `${policy.vehicleYear} ` : ''}
                            {[policy.vehicleBrand, policy.vehicleModel].filter(Boolean).join(' ')}
                          </div>
                        ) : policy.vehicleDetail ? (
                          <div className="text-slate-500 text-xs mt-0.5 max-w-[160px] truncate" title={policy.vehicleDetail}>
                            {policy.vehicleDetail}
                          </div>
                        ) : null}
                      </td>

                      {/* Şirket & Branş */}
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-slate-800">{policy.company}</div>
                        <div className="text-slate-500 text-xs">{policy.branch}</div>
                        {policy.originQuoteId && (
                          <span className="text-[10px] font-semibold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200 mt-0.5 inline-block">
                            Tekliften Oluştu
                          </span>
                        )}
                      </td>

                      {/* Poliçe No */}
                      <td className="py-3.5 px-4">
                        <span className="font-mono text-slate-800 bg-slate-50 px-2 py-1 rounded border border-slate-200 font-semibold">
                          {policy.policyNumber}
                        </span>
                        <div className="text-slate-400 text-[11px] mt-1">
                          Başlangıç: {formatDateTr(policy.startDate)}
                        </div>
                      </td>

                      {/* Bitiş Tarihi */}
                      <td className="py-3.5 px-4">
                        <div className="font-bold text-slate-900">{formatDateTr(policy.endDate)}</div>
                        <div className="text-slate-400 text-[11px]">{policy.stage}</div>
                      </td>

                      {/* Kalan Gün */}
                      <td className="py-3.5 px-4">{getDaysLeftBadge(daysLeft)}</td>

                      {/* Araç Bedeli */}
                      <td className="py-3.5 px-4 text-right">
                        {policy.vehicleValue && policy.vehicleValue > 0 ? (
                          <div className="font-bold text-slate-800 text-xs">
                            {formatCurrency(policy.vehicleValue)}
                          </div>
                        ) : (
                          <span className="text-slate-400">—</span>
                        )}
                      </td>

                      {/* Prim */}
                      <td className="py-3.5 px-4 text-right">
                        <div className="font-black text-slate-900 text-sm">{formatCurrency(policy.premium)}</div>
                      </td>

                      {/* Çarpan */}
                      <td className="py-3.5 px-4 text-center">
                        {multiplier !== null ? (
                          <span
                            className="font-mono font-bold text-xs bg-indigo-50 text-indigo-700 px-2.5 py-1 rounded-md border border-indigo-200 inline-block shadow-2xs"
                            title={`Çarpan = Prim / Araç Bedeli (${formatCurrency(policy.premium)} / ${formatCurrency(policy.vehicleValue || 0)})`}
                          >
                            {formatMultiplier(multiplier)}
                          </span>
                        ) : (
                          <span className="text-slate-400 font-mono text-xs">—</span>
                        )}
                      </td>

                      {/* Kontroller */}
                      <td className="py-3.5 px-4 text-center">
                        <div className="inline-flex items-center gap-1" title="Ruhsat, Plaka Zeyli, EGM Sorgusu">
                          <span
                            className={`w-2 h-2 rounded-full ${policy.doc ? 'bg-emerald-500' : 'bg-slate-300'}`}
                            title="Ruhsat Kontrolü"
                          />
                          <span
                            className={`w-2 h-2 rounded-full ${policy.endorse ? 'bg-emerald-500' : 'bg-slate-300'}`}
                            title="Plaka Zeyli"
                          />
                          <span
                            className={`w-2 h-2 rounded-full ${policy.egm ? 'bg-emerald-500' : 'bg-slate-300'}`}
                            title="EGM / TRAMER"
                          />
                        </div>
                      </td>

                      {/* İşlemler */}
                      <td className="py-3.5 px-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          {/* 1. Yenileme Teklifi Aç */}
                          <button
                            type="button"
                            onClick={() => onCreateRenewalQuote(policy)}
                            title="Bu poliçe için Yenileme Teklifi oluştur"
                            className="px-2.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold shadow-xs flex items-center gap-1 transition-colors cursor-pointer"
                          >
                            <RefreshCw className="w-3.5 h-3.5" />
                            <span>Yenileme Teklifi</span>
                          </button>

                          {/* 2. Sonuçlandır / Kapat */}
                          <button
                            type="button"
                            onClick={() => onConcludePolicy(policy)}
                            title="Poliçeyi Sonuçlandır ve 'Sonuçlananlar' sekmesine aktar"
                            className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors cursor-pointer"
                          >
                            <Archive className="w-4 h-4" />
                          </button>

                          {/* 3. Düzenle */}
                          <button
                            type="button"
                            onClick={() => onEditPolicy(policy)}
                            title="Poliçeyi Düzenle"
                            className="px-2.5 py-1.5 text-slate-700 hover:bg-slate-100 border border-slate-200 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                          >
                            Düzenle
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={9} className="py-12 text-center">
                    <Shield className="w-10 h-10 text-slate-300 mx-auto mb-3" />
                    <div className="text-sm font-bold text-slate-700">Filtreye uygun aktif poliçe bulunamadı</div>
                    <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                      Arama filtrenizi temizleyebilir veya portföyünüze yeni bir poliçe ekleyebilirsiniz.
                    </p>
                    <button
                      onClick={onOpenNewPolicy}
                      className="mt-4 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Yeni Poliçe Kaydet</span>
                    </button>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
