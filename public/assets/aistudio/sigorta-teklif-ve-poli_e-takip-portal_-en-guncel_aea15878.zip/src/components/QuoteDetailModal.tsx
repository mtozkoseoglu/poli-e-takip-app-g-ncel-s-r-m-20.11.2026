import React, { useState, useEffect, useMemo } from 'react';
import {
  Quote,
  COMPANIES,
  BRANCHES,
  BUSINESS_TYPES,
  BusinessType,
  CompanyOffer,
  AuthorizedCompany,
  USAGE_STYLES,
  FUEL_TYPES,
  CompanyOfferStatus,
  QuoteStage,
  QUOTE_STAGES,
  NON_CONVERSION_REASONS,
} from '../types/insurance';
import { formatCurrency, isStandardCompany, normalizeQuoteStage } from '../services/storage';
import {
  X,
  FileText,
  Car,
  Shield,
  CheckCircle2,
  Copy,
  Check,
  TrendingDown,
  Save,
  AlertCircle,
  Building2,
  Hash,
  Sparkles,
  XCircle,
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  quote: Quote | null;
  onSave: (quote: Quote) => void;
  onConvertToPolicy?: (quote: Quote) => void;
  showToast: (msg: string) => void;
}

export const QuoteDetailModal: React.FC<Props> = ({
  isOpen,
  onClose,
  quote,
  onSave,
  onConvertToPolicy,
  showToast,
}) => {
  // Common vehicle and customer fields (14 standard fields)
  const [insured, setInsured] = useState('');
  const [businessType, setBusinessType] = useState<BusinessType>('Yenileme');
  const [branch, setBranch] = useState('Kasko');
  const [plate, setPlate] = useState('');
  const [licenseSerialNo, setLicenseSerialNo] = useState('');
  const [chassisNo, setChassisNo] = useState('');
  const [engineNo, setEngineNo] = useState('');
  const [usageStyle, setUsageStyle] = useState('OTOMOBİL');
  const [vehicleYear, setVehicleYear] = useState<number | string>('');
  const [vehicleBrand, setVehicleBrand] = useState('');
  const [vehicleModel, setVehicleModel] = useState('');
  const [vehicleCode, setVehicleCode] = useState('');
  const [fuelType, setFuelType] = useState('');
  const [vehicleValue, setVehicleValue] = useState<number | ''>('');
  const [stage, setStage] = useState<QuoteStage>('MÜŞTERİYE SUNULACAK');
  const [nonConversionReason, setNonConversionReason] = useState<string>('');
  const [notes, setNotes] = useState('');

  // 6 Company Offer slots with independent 'Teklif Alınamadı' status
  const [offers, setOffers] = useState<
    Array<{
      company: string;
      premium: number | '';
      quoteNumber: string;
      notes?: string;
      status: CompanyOfferStatus;
      noOffer: boolean;
    }>
  >([]);

  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  // Initialize form state when quote changes
  useEffect(() => {
    if (!quote) return;

    setInsured(quote.insured || '');
    setBusinessType(quote.businessType || 'Yenileme');
    setBranch(quote.branch || 'Kasko');
    setPlate(quote.plate || '');
    setLicenseSerialNo(quote.licenseSerialNo || '');
    setChassisNo(quote.chassisNo || '');
    setEngineNo(quote.engineNo || '');
    setUsageStyle(quote.usageStyle || 'OTOMOBİL');
    setVehicleYear(quote.vehicleYear || '');
    setVehicleBrand(quote.vehicleBrand || '');
    setVehicleModel(quote.vehicleModel || '');
    setVehicleCode(quote.vehicleCode || '');
    setFuelType(quote.fuelType || '');
    setVehicleValue(quote.vehicleValue !== undefined && quote.vehicleValue !== null ? quote.vehicleValue : '');
    setStage(normalizeQuoteStage(quote.stage));
    setNonConversionReason(quote.nonConversionReason || quote.rejectionReason || '');
    setNotes(quote.notes || '');

    // Setup 6 company offer slots
    const currentOffers: Array<{
      company: string;
      premium: number | '';
      quoteNumber: string;
      notes?: string;
      status: CompanyOfferStatus;
      noOffer: boolean;
    }> = [];

    // 1. Existing offers from quote.companyOffers
    if (Array.isArray(quote.companyOffers) && quote.companyOffers.length > 0) {
      quote.companyOffers.forEach((o) => {
        if (currentOffers.length < 6) {
          const isNoOffer = o.noOffer === true || o.status === 'teklif_alinamadi';
          const hasPrem = !isNoOffer && typeof o.premium === 'number' && o.premium > 0;
          currentOffers.push({
            company: o.company || COMPANIES[0],
            premium: !isNoOffer && o.premium !== undefined && o.premium !== null ? o.premium : '',
            quoteNumber: o.quoteNumber || '',
            notes: o.notes || '',
            status: isNoOffer ? 'teklif_alinamadi' : (hasPrem ? 'teklif_alindi' : (o.status || 'bekleniyor')),
            noOffer: isNoOffer,
          });
        }
      });
    }

    // 2. If slots are still empty, populate from main quote & alternatives if not already included
    if (currentOffers.length === 0) {
      const mainHasPrem = typeof quote.premium === 'number' && quote.premium > 0;
      currentOffers.push({
        company: quote.company || COMPANIES[0],
        premium: quote.premium !== undefined && quote.premium !== null ? quote.premium : '',
        quoteNumber: quote.quoteNumber || '',
        notes: '',
        status: mainHasPrem ? 'teklif_alindi' : 'bekleniyor',
        noOffer: false,
      });
      if (Array.isArray(quote.alternatives)) {
        quote.alternatives.forEach((alt) => {
          if (currentOffers.length < 6) {
            const altHasPrem = typeof alt.premium === 'number' && alt.premium > 0;
            currentOffers.push({
              company: alt.company || COMPANIES[currentOffers.length % COMPANIES.length],
              premium: alt.premium !== undefined && alt.premium !== null ? alt.premium : '',
              quoteNumber: '',
              notes: alt.notes || '',
              status: altHasPrem ? 'teklif_alindi' : 'bekleniyor',
              noOffer: false,
            });
          }
        });
      }
    }

    // 3. Fill remaining slots up to 6 with distinct default companies from COMPANIES
    while (currentOffers.length < 6) {
      const usedCompanies = new Set(currentOffers.map((o) => o.company));
      const nextCompany = COMPANIES.find((c) => !usedCompanies.has(c)) || COMPANIES[currentOffers.length % COMPANIES.length];
      currentOffers.push({
        company: nextCompany,
        premium: '',
        quoteNumber: '',
        notes: '',
        status: 'bekleniyor',
        noOffer: false,
      });
    }

    setOffers(currentOffers.slice(0, 6));
  }, [quote, isOpen]);

  // Find lowest valid premium to highlight (Teklif Alınamadı olanlar hesaba katılmaz)
  const minValidPremium = useMemo(() => {
    const validPremiums = offers
      .filter((o) => !o.noOffer && o.status !== 'teklif_alinamadi')
      .map((o) => (typeof o.premium === 'number' && !isNaN(o.premium) && o.premium > 0 ? o.premium : null))
      .filter((p): p is number => p !== null);
    if (validPremiums.length === 0) return null;
    return Math.min(...validPremiums);
  }, [offers]);

  if (!isOpen || !quote) return null;

  const handleCopy = (text: string, fieldName: string) => {
    if (!text) return;
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    setTimeout(() => {
      setCopiedField((prev) => (prev === fieldName ? null : prev));
    }, 2000);
  };

  const handleOfferChange = (
    index: number,
    field: 'company' | 'premium' | 'quoteNumber' | 'notes' | 'status' | 'noOffer',
    value: any
  ) => {
    setOffers((prev) => {
      const next = [...prev];
      const cur = { ...next[index] };
      if (field === 'status') {
        const s = value as CompanyOfferStatus;
        cur.status = s;
        cur.noOffer = s === 'teklif_alinamadi';
        if (s === 'teklif_alinamadi') {
          cur.premium = '';
        }
      } else if (field === 'noOffer') {
        const isNo = Boolean(value);
        cur.noOffer = isNo;
        cur.status = isNo ? 'teklif_alinamadi' : (typeof cur.premium === 'number' && cur.premium > 0 ? 'teklif_alindi' : 'bekleniyor');
        if (isNo) cur.premium = '';
      } else if (field === 'premium') {
        cur.premium = value;
        if (typeof value === 'number' && value > 0) {
          cur.noOffer = false;
          cur.status = 'teklif_alindi';
        } else if (value === '' && cur.status === 'teklif_alindi') {
          cur.status = 'bekleniyor';
        }
      } else {
        (cur as any)[field] = value;
      }
      next[index] = cur;
      return next;
    });
  };

  const handleSave = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!insured.trim()) {
      showToast('Hata: Sigortalı adı boş bırakılamaz.');
      return;
    }

    setIsSaving(true);
    try {
      // Find the primary company & premium:
      // Prefer the first slot or the lowest priced filled offer that is not 'teklif_alinamadi'
      const filledOffers = offers.filter(
        (o) => !o.noOffer && o.status !== 'teklif_alinamadi' && typeof o.premium === 'number' && o.premium > 0
      );

      // Determine main quote company & premium
      let primaryCompany = quote.company;
      let primaryPremium = quote.premium;
      let primaryQuoteNumber = quote.quoteNumber;

      if (filledOffers.length > 0) {
        const firstFilled = filledOffers[0];
        primaryCompany = firstFilled.company;
        primaryPremium = Number(firstFilled.premium);
        primaryQuoteNumber = firstFilled.quoteNumber || quote.quoteNumber;
      }

      const isConverted = quote.outcome === 'converted' || Boolean(quote.convertedPolicyId);
      const cleanReason = isConverted ? undefined : (nonConversionReason.trim() || undefined);
      const isNegative = !isConverted && Boolean(cleanReason);

      const updatedQuote: Quote = {
        ...quote,
        insured: insured.trim(),
        businessType: businessType,
        branch: branch,
        plate: plate.trim().toLocaleUpperCase('tr-TR').replace(/[ .-]/g, ''),
        licenseSerialNo: licenseSerialNo.trim().toLocaleUpperCase('tr-TR'),
        chassisNo: chassisNo.trim().toLocaleUpperCase('tr-TR'),
        engineNo: engineNo.trim().toLocaleUpperCase('tr-TR'),
        usageStyle: usageStyle.trim() || '',
        vehicleYear: vehicleYear ? Number(vehicleYear) : undefined,
        vehicleBrand: vehicleBrand.trim(),
        vehicleModel: vehicleModel.trim(),
        vehicleCode: vehicleCode.trim(),
        fuelType: fuelType.trim(),
        vehicleValue: vehicleValue !== '' && !isNaN(Number(vehicleValue)) ? Number(vehicleValue) : undefined,
        stage: stage,
        outcome: isConverted ? 'converted' : (isNegative ? 'rejected' : undefined),
        status: (isConverted || isNegative) ? 'concluded' : 'active',
        quoteStatus: isConverted ? 'kabul_edildi' : (isNegative ? 'reddedildi' : 'beklemede'),
        rejectionReason: cleanReason,
        nonConversionReason: cleanReason,
        resultDate: (isConverted || isNegative) ? (quote.resultDate || new Date().toISOString().split('T')[0]) : undefined,
        notes: notes.trim(),
        company: primaryCompany,
        premium: primaryPremium,
        quoteNumber: primaryQuoteNumber,
        companyOffers: offers.map((o) => {
          const isNo = o.noOffer || o.status === 'teklif_alinamadi';
          return {
            company: o.company,
            premium: !isNo && typeof o.premium === 'number' && !isNaN(o.premium) && o.premium > 0 ? o.premium : undefined,
            quoteNumber: o.quoteNumber.trim() || undefined,
            notes: o.notes?.trim() || undefined,
            status: isNo ? 'teklif_alinamadi' : (typeof o.premium === 'number' && o.premium > 0 ? 'teklif_alindi' : 'bekleniyor'),
            noOffer: isNo,
          };
        }),
        updatedAt: new Date().toISOString(),
      };

      onSave(updatedQuote);
      showToast('Teklif detayları ve şirket teklifleri başarıyla kaydedildi.');
      onClose();
    } catch (err) {
      console.error('Kaydetme hatası:', err);
    } finally {
      setIsSaving(false);
    }
  };

  const handleSelectOfferToConvert = (offer: { company: string; premium: number | ''; quoteNumber: string }) => {
    if (!onConvertToPolicy) return;

    const updatedQuote: Quote = {
      ...quote,
      insured: insured.trim(),
      businessType: businessType,
      branch: branch,
      plate: plate.trim().toLocaleUpperCase('tr-TR').replace(/[ .-]/g, ''),
      licenseSerialNo: licenseSerialNo.trim().toLocaleUpperCase('tr-TR'),
      chassisNo: chassisNo.trim().toLocaleUpperCase('tr-TR'),
      engineNo: engineNo.trim().toLocaleUpperCase('tr-TR'),
      usageStyle: usageStyle.trim(),
      vehicleYear: vehicleYear ? Number(vehicleYear) : undefined,
      vehicleBrand: vehicleBrand.trim(),
      vehicleModel: vehicleModel.trim(),
      vehicleCode: vehicleCode.trim(),
      fuelType: fuelType.trim(),
      vehicleValue: vehicleValue !== '' && !isNaN(Number(vehicleValue)) ? Number(vehicleValue) : undefined,
      stage: stage,
      company: offer.company,
      premium: typeof offer.premium === 'number' ? offer.premium : quote.premium,
      quoteNumber: offer.quoteNumber || quote.quoteNumber,
    };

    onSave(updatedQuote);
    onClose();
    onConvertToPolicy(updatedQuote);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-3 md:p-6 overflow-y-auto">
      <div className="relative w-full max-w-5xl max-h-[94vh] flex flex-col bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-white border-b border-slate-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-slate-900">
                  {insured || 'Teklif Detayı'}
                </h2>
                {plate && (
                  <span className="px-2.5 py-0.5 rounded-md font-mono text-xs font-bold bg-slate-100 border border-slate-300 text-slate-800">
                    {plate}
                  </span>
                )}
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200">
                  {businessType}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Araç bilgileri ve 6 sigorta şirketi teklif karşılaştırma tablosu
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* TEKLİF AŞAMASI & SONUÇ BİLGİSİ BAR */}
          <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-2xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
            {/* Teklif Aşaması */}
            <div className="flex-1">
              <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                Teklif Aşaması *
              </label>
              <select
                value={stage}
                onChange={(e) => setStage(e.target.value as QuoteStage)}
                className="w-full px-3 py-2 text-xs font-bold border border-slate-300 rounded-xl bg-slate-50 text-slate-800 focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none cursor-pointer"
              >
                {QUOTE_STAGES.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>

            {/* Teklif Sonucu / Poliçeleştirmeme Durumu */}
            <div className="flex-1">
              {quote.outcome === 'converted' || quote.convertedPolicyId ? (
                <div>
                  <div className="text-[11px] font-bold uppercase tracking-wider text-emerald-700 mb-1">
                    Teklif Nihai Sonucu
                  </div>
                  <div className="flex items-center gap-2 px-3 py-2 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-bold text-emerald-800">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>POLİÇELEŞTİRİLDİ (OLUMLU)</span>
                  </div>
                </div>
              ) : (
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-1">
                    Teklif Sonucu / Poliçeleştirmeme Nedeni
                  </label>
                  <select
                    value={nonConversionReason}
                    onChange={(e) => setNonConversionReason(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-semibold border border-slate-300 rounded-xl bg-slate-50 text-slate-800 focus:bg-white focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 outline-none cursor-pointer"
                  >
                    <option value="">⏳ Henüz Sonuçlanmadı (Süreçte / Beklemede)</option>
                    {NON_CONVERSION_REASONS.map((r) => (
                      <option key={r} value={r}>
                        ❌ {r}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>
          </div>

          {/* SECTION 1: ORTAK SİGORTALI & ARAÇ BİLGİLERİ */}
          <div className="bg-slate-50/70 rounded-2xl p-5 border border-slate-200">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Car className="w-4 h-4 text-blue-600" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                  Ortak Araç ve Sigortalı Bilgileri
                </h3>
              </div>
              <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                ✓ KVKK Güvenli (TCKN Tutulmaz)
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3.5">
              {/* 1. Sigortalı */}
              <div className="sm:col-span-2">
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  1. Sigortalı (Müşteri Adı Soyadı / Şirket) *
                </label>
                <input
                  type="text"
                  required
                  value={insured}
                  onChange={(e) => setInsured(e.target.value)}
                  placeholder="Müşteri Adı Soyadı veya Ünvan"
                  className="w-full px-3 py-1.5 text-xs font-semibold border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                />
              </div>

              {/* 2. İş Türü */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  2. İş Türü *
                </label>
                <select
                  value={businessType}
                  onChange={(e) => setBusinessType(e.target.value as BusinessType)}
                  className="w-full px-3 py-1.5 text-xs font-semibold border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none cursor-pointer"
                >
                  {BUSINESS_TYPES.map((bt) => (
                    <option key={bt} value={bt}>
                      {bt}
                    </option>
                  ))}
                </select>
              </div>

              {/* 3. Branş */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  3. Branş *
                </label>
                <select
                  value={branch}
                  onChange={(e) => setBranch(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs font-bold text-indigo-900 border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none cursor-pointer"
                >
                  {BRANCHES.map((b) => (
                    <option key={b} value={b}>
                      {b}
                    </option>
                  ))}
                </select>
              </div>

              {/* 4. Plaka */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  4. Plaka
                </label>
                <input
                  type="text"
                  value={plate}
                  onChange={(e) => setPlate(e.target.value.toLocaleUpperCase('tr-TR').replace(/[ .-]/g, ''))}
                  placeholder="34ABC123"
                  className="w-full px-3 py-1.5 text-xs font-bold font-mono uppercase tracking-wider border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                />
              </div>

              {/* 5. Ruhsat Seri No */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  5. Ruhsat Seri No
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={licenseSerialNo}
                    onChange={(e) => setLicenseSerialNo(e.target.value.toLocaleUpperCase('tr-TR'))}
                    placeholder="Örn: AS123456"
                    className="w-full px-3 py-1.5 pr-7 text-xs font-semibold uppercase border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                  />
                  {licenseSerialNo && (
                    <button
                      type="button"
                      onClick={() => handleCopy(licenseSerialNo, 'ruhsat')}
                      title="Kopyala"
                      className="absolute right-1.5 top-1.5 text-slate-400 hover:text-slate-700"
                    >
                      {copiedField === 'ruhsat' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  )}
                </div>
              </div>

              {/* 6. Şasi No */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  6. Şasi No (17 Hane)
                </label>
                <div className="relative">
                  <input
                    type="text"
                    maxLength={25}
                    value={chassisNo}
                    onChange={(e) => setChassisNo(e.target.value.toLocaleUpperCase('tr-TR'))}
                    placeholder="WVWZZZ..."
                    className="w-full px-3 py-1.5 pr-7 text-xs font-mono font-semibold uppercase border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                  />
                  {chassisNo && (
                    <button
                      type="button"
                      onClick={() => handleCopy(chassisNo, 'sasi')}
                      title="Şasi Numarasını Kopyala"
                      className="absolute right-1.5 top-1.5 text-slate-400 hover:text-slate-700 cursor-pointer"
                    >
                      {copiedField === 'sasi' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  )}
                </div>
              </div>

              {/* 7. Motor No */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  7. Motor No
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={engineNo}
                    onChange={(e) => setEngineNo(e.target.value.toLocaleUpperCase('tr-TR'))}
                    placeholder="CAY123..."
                    className="w-full px-3 py-1.5 pr-7 text-xs font-mono font-semibold uppercase border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                  />
                  {engineNo && (
                    <button
                      type="button"
                      onClick={() => handleCopy(engineNo, 'motor')}
                      title="Motor Numarasını Kopyala"
                      className="absolute right-1.5 top-1.5 text-slate-400 hover:text-slate-700 cursor-pointer"
                    >
                      {copiedField === 'motor' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  )}
                </div>
              </div>

              {/* 8. Kullanım Tarzı (Açılır Liste - Alfabetik Büyük Harf) */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  8. Kullanım Tarzı
                </label>
                <select
                  value={usageStyle}
                  onChange={(e) => setUsageStyle(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs font-semibold border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none cursor-pointer"
                >
                  <option value="">Seçiniz</option>
                  {usageStyle && !USAGE_STYLES.includes(usageStyle as any) && (
                    <option value={usageStyle}>{usageStyle}</option>
                  )}
                  {USAGE_STYLES.map((style) => (
                    <option key={style} value={style}>
                      {style}
                    </option>
                  ))}
                </select>
              </div>

              {/* 9. Model Yılı */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  9. Model Yılı
                </label>
                <input
                  type="number"
                  min="1980"
                  max="2035"
                  value={vehicleYear}
                  onChange={(e) => setVehicleYear(e.target.value ? Number(e.target.value) : '')}
                  placeholder="Örn: 2022"
                  className="w-full px-3 py-1.5 text-xs font-semibold border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                />
              </div>

              {/* 10. Araç Marka */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  10. Araç Marka
                </label>
                <input
                  type="text"
                  value={vehicleBrand}
                  onChange={(e) => setVehicleBrand(e.target.value)}
                  placeholder="Örn: Volkswagen"
                  className="w-full px-3 py-1.5 text-xs font-semibold border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                />
              </div>

              {/* 11. Araç Model */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  11. Araç Model
                </label>
                <input
                  type="text"
                  value={vehicleModel}
                  onChange={(e) => setVehicleModel(e.target.value)}
                  placeholder="Örn: Golf 1.5 eTSI Style"
                  className="w-full px-3 py-1.5 text-xs font-semibold border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                />
              </div>

              {/* 12. Araç Kodu */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  12. Araç Kodu (TSB)
                </label>
                <input
                  type="text"
                  value={vehicleCode}
                  onChange={(e) => setVehicleCode(e.target.value)}
                  placeholder="Örn: 100234"
                  className="w-full px-3 py-1.5 text-xs font-semibold font-mono border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                />
              </div>

              {/* 13. Yakıt Türü */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  13. Yakıt Türü
                </label>
                <select
                  value={fuelType}
                  onChange={(e) => setFuelType(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs font-semibold border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none cursor-pointer"
                >
                  <option value="">Seçiniz</option>
                  {fuelType && !FUEL_TYPES.includes(fuelType as any) && (
                    <option value={fuelType}>{fuelType}</option>
                  )}
                  {FUEL_TYPES.map((ft) => (
                    <option key={ft} value={ft}>
                      {ft}
                    </option>
                  ))}
                </select>
              </div>

              {/* 14. Araç Bedeli */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  14. Araç Kasko Bedeli (TL)
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="0"
                    step="1000"
                    value={vehicleValue}
                    onChange={(e) => setVehicleValue(e.target.value ? Number(e.target.value) : '')}
                    placeholder="1.250.000"
                    className="w-full px-3 py-1.5 pr-8 text-xs font-bold text-slate-900 border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                  />
                  <span className="absolute right-2.5 top-1.5 text-xs font-bold text-slate-400">₺</span>
                </div>
                {vehicleValue !== '' && !isNaN(Number(vehicleValue)) && Number(vehicleValue) > 0 && (
                  <div className="text-[10px] text-slate-500 font-semibold mt-0.5">
                    Görünen: {formatCurrency(Number(vehicleValue))}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* SECTION 2: 6 SİGORTA ŞİRKETİ KARŞILAŞTIRMA TABLOSU */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-indigo-600" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                  Sigorta Şirketi Teklif Karşılaştırması (6 Şirket)
                </h3>
              </div>
              <div className="text-xs text-slate-500 flex items-center gap-2">
                <span className="inline-flex items-center gap-1 text-emerald-700 font-bold bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200 text-[11px]">
                  <Sparkles className="w-3 h-3 text-emerald-600" /> En düşük prim otomatik vurgulanır
                </span>
                <span className="text-[11px] text-slate-400">13 Onaylı Şirket</span>
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-2xs">
              <table className="w-full text-left text-xs whitespace-nowrap">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider text-[11px]">
                    <th className="py-3 px-4 w-12 text-center">#</th>
                    <th className="py-3 px-4 min-w-[190px]">Sigorta Şirketi (13 Onaylı Şirket)</th>
                    <th className="py-3 px-4 min-w-[160px]">Teklif Durumu</th>
                    <th className="py-3 px-4 min-w-[160px]">Prim (TL)</th>
                    <th className="py-3 px-4 min-w-[170px]">Teklif Numarası</th>
                    <th className="py-3 px-4 min-w-[150px]">Durum / Vurgu</th>
                    <th className="py-3 px-4 text-right">İşlem</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {offers.map((offer, idx) => {
                    const isNoOffer = offer.noOffer === true || offer.status === 'teklif_alinamadi';
                    const hasPremium =
                      !isNoOffer &&
                      typeof offer.premium === 'number' &&
                      !isNaN(offer.premium) &&
                      offer.premium > 0;
                    const isLowest = hasPremium && offer.premium === minValidPremium;

                    return (
                      <tr
                        key={idx}
                        className={`transition-colors ${
                          isNoOffer
                            ? 'bg-rose-50/20 hover:bg-rose-50/30'
                            : isLowest
                            ? 'bg-emerald-50/50 hover:bg-emerald-50'
                            : 'hover:bg-slate-50/70'
                        }`}
                      >
                        {/* Sıra No */}
                        <td className="py-3 px-4 text-center font-bold text-slate-400">
                          {idx + 1}
                        </td>

                        {/* Sigorta Şirketi Seçimi (13 Onaylı Şirket) */}
                        <td className="py-3 px-4">
                          <select
                            value={offer.company}
                            onChange={(e) => handleOfferChange(idx, 'company', e.target.value)}
                            className="w-full px-3 py-1.5 text-xs font-bold text-slate-800 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none cursor-pointer"
                          >
                            {COMPANIES.map((c) => (
                              <option key={c} value={c}>
                                {c}
                              </option>
                            ))}
                          </select>
                        </td>

                        {/* Teklif Durumu (Teklif Alındı / Teklif Alınamadı / Bekleniyor) */}
                        <td className="py-3 px-4">
                          <select
                            value={isNoOffer ? 'teklif_alinamadi' : (hasPremium ? 'teklif_alindi' : 'bekleniyor')}
                            onChange={(e) => handleOfferChange(idx, 'status', e.target.value)}
                            className={`w-full px-2.5 py-1.5 text-xs font-bold rounded-lg border outline-none cursor-pointer transition-colors ${
                              isNoOffer
                                ? 'bg-rose-50 border-rose-300 text-rose-700 font-black'
                                : hasPremium
                                ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                                : 'bg-white border-slate-300 text-slate-700'
                            }`}
                          >
                            <option value="bekleniyor">⏳ Teklif Bekleniyor</option>
                            <option value="teklif_alindi">✓ Teklif Alındı</option>
                            <option value="teklif_alinamadi">❌ Teklif Alınamadı</option>
                          </select>
                        </td>

                        {/* Prim (TL) */}
                        <td className="py-3 px-4">
                          {isNoOffer ? (
                            <div className="relative">
                              <input
                                type="text"
                                disabled
                                value=""
                                placeholder="Teklif Alınamadı"
                                className="w-full px-3 py-1.5 text-xs font-semibold rounded-lg border border-rose-200 bg-rose-50/50 text-rose-600 italic outline-none cursor-not-allowed"
                              />
                            </div>
                          ) : (
                            <>
                              <div className="relative">
                                <input
                                  type="number"
                                  min="0"
                                  step="50"
                                  value={offer.premium}
                                  onChange={(e) =>
                                    handleOfferChange(
                                      idx,
                                      'premium',
                                      e.target.value !== '' ? Number(e.target.value) : ''
                                    )
                                  }
                                  placeholder="Prim giriniz (TL)"
                                  className={`w-full px-3 py-1.5 pr-7 text-xs font-bold rounded-lg border outline-none ${
                                    isLowest
                                      ? 'border-emerald-400 bg-white text-emerald-800 focus:ring-2 focus:ring-emerald-500/20'
                                      : 'border-slate-300 bg-white text-slate-900 focus:ring-2 focus:ring-blue-500/20'
                                  }`}
                                />
                                <span className="absolute right-2.5 top-1.5 text-xs font-bold text-slate-400">₺</span>
                              </div>
                              {hasPremium && (
                                <div className="text-[10px] text-slate-500 font-semibold mt-0.5">
                                  {formatCurrency(Number(offer.premium))}
                                </div>
                              )}
                            </>
                          )}
                        </td>

                        {/* Teklif Numarası */}
                        <td className="py-3 px-4">
                          {isNoOffer ? (
                            <input
                              type="text"
                              disabled
                              value=""
                              placeholder="Teklif No Yok"
                              className="w-full px-3 py-1.5 text-xs font-semibold rounded-lg border border-slate-200 bg-slate-50 text-slate-400 italic outline-none cursor-not-allowed"
                            />
                          ) : (
                            <div className="relative">
                              <input
                                type="text"
                                value={offer.quoteNumber}
                                onChange={(e) => handleOfferChange(idx, 'quoteNumber', e.target.value)}
                                placeholder="Örn: 2026-TK-001"
                                className="w-full px-3 py-1.5 pr-7 text-xs font-mono font-semibold border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                              />
                              {offer.quoteNumber && (
                                <button
                                  type="button"
                                  onClick={() => handleCopy(offer.quoteNumber, `offer-quote-${idx}`)}
                                  title="Teklif No Kopyala"
                                  className="absolute right-1.5 top-1.5 text-slate-400 hover:text-slate-700 cursor-pointer"
                                >
                                  {copiedField === `offer-quote-${idx}` ? (
                                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                                  ) : (
                                    <Copy className="w-3.5 h-3.5" />
                                  )}
                                </button>
                              )}
                            </div>
                          )}
                        </td>

                        {/* Durum / Vurgu */}
                        <td className="py-3 px-4">
                          {isNoOffer ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-rose-100 text-rose-800 border border-rose-300 shadow-2xs">
                              <XCircle className="w-3.5 h-3.5 text-rose-600" />
                              <span>Teklif Alınamadı</span>
                            </span>
                          ) : isLowest ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-black bg-emerald-100 text-emerald-800 border border-emerald-300 shadow-2xs">
                              <TrendingDown className="w-3.5 h-3.5 text-emerald-600" />
                              <span>En Uygun Teklif</span>
                            </span>
                          ) : hasPremium ? (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-semibold text-slate-600 bg-slate-100 border border-slate-200">
                              Teklif Alındı
                            </span>
                          ) : (
                            <span className="text-slate-400 text-xs italic">
                              Teklif Bekleniyor
                            </span>
                          )}
                        </td>

                        {/* İşlem (Bu Şirketle Poliçeleştir) */}
                        <td className="py-3 px-4 text-right">
                          {!isNoOffer && hasPremium && onConvertToPolicy ? (
                            <button
                              type="button"
                              onClick={() => handleSelectOfferToConvert(offer)}
                              title={`${offer.company} teklifi ile poliçeleştir`}
                              className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-2xs inline-flex items-center gap-1 transition-colors cursor-pointer"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>Poliçeleştir</span>
                            </button>
                          ) : isNoOffer ? (
                            <span className="text-[11px] text-rose-500 font-semibold italic">Teklif yok</span>
                          ) : (
                            <span className="text-slate-300 text-xs">—</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* SECTION 3: İŞ NOTLARI */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Görüşme ve Teklif Notları
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Şirketlerin özel teminatları, muafiyet veya müşteri talepleri hakkında notlar..."
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
            />
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-50 border-t border-slate-200">
          <div className="text-xs text-slate-500">
            {minValidPremium !== null && (
              <span>
                En Uygun Teklif:{' '}
                <strong className="text-emerald-700 font-bold text-sm">
                  {formatCurrency(minValidPremium)}
                </strong>
              </span>
            )}
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl transition-colors cursor-pointer"
            >
              Kapat
            </button>
            <button
              type="button"
              onClick={() => handleSave()}
              disabled={isSaving}
              className="px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>{isSaving ? 'Kaydediliyor...' : 'Değişiklikleri Kaydet'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
