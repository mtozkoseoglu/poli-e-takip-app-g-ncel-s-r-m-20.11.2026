import React, { useState, useEffect } from 'react';
import {
  Quote,
  COMPANIES,
  BRANCHES,
  QUOTE_STAGES,
  AlternativeQuote,
  BUSINESS_TYPES,
  BusinessType,
  USAGE_STYLES,
  FUEL_TYPES,
  NON_CONVERSION_REASONS,
} from '../types/insurance';
import { getTodayIso, addDays, generateId, isStandardCompany, normalizeQuoteStage } from '../services/storage';
import { X, Plus, Trash2, Shield, Calendar, DollarSign, FileText, AlertTriangle } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSave: (quote: Quote) => void;
  onDelete?: (id: string) => void;
  onConvertToPolicy?: (quote: Quote) => void;
  onConcludeNegative?: (quote: Quote) => void;
  initialQuote?: Quote | null;
}

export const QuoteModal: React.FC<Props> = ({
  isOpen,
  onClose,
  onSave,
  onDelete,
  onConvertToPolicy,
  onConcludeNegative,
  initialQuote,
}) => {
  const [formData, setFormData] = useState<Partial<Quote>>({
    insured: '',
    phone: '',
    email: '',
    plate: '',
    vehicleBrand: '',
    vehicleModel: '',
    vehicleYear: '',
    vehicleDetail: '',
    company: COMPANIES[0],
    branch: 'Kasko',
    quoteNumber: '',
    quoteDate: getTodayIso(),
    validUntil: addDays(15),
    premium: 0,
    stage: 'MÜŞTERİYE SUNULACAK',
    notes: '',
    followDate: '',
    alternatives: [],
  });

  const [altCompany, setAltCompany] = useState<string>(COMPANIES[1]);
  const [altPremium, setAltPremium] = useState<number | ''>('');
  const [altNotes, setAltNotes] = useState('');

  useEffect(() => {
    if (initialQuote) {
      setFormData({
        ...initialQuote,
        stage: normalizeQuoteStage(initialQuote.stage),
        alternatives: initialQuote.alternatives ? [...initialQuote.alternatives] : [],
      });
    } else {
      setFormData({
        id: generateId(),
        type: 'quote',
        insured: '',
        businessType: 'Yenileme',
        phone: '',
        email: '',
        plate: '',
        licenseSerialNo: '',
        chassisNo: '',
        engineNo: '',
        usageStyle: 'OTOMOBİL',
        vehicleBrand: '',
        vehicleModel: '',
        vehicleYear: '',
        vehicleCode: '',
        fuelType: '',
        vehicleValue: undefined,
        vehicleDetail: '',
        company: COMPANIES[0],
        branch: 'Kasko',
        quoteNumber: 'TK-' + new Date().getFullYear() + '-' + Math.floor(100 + Math.random() * 900),
        quoteDate: getTodayIso(),
        validUntil: addDays(15),
        premium: 0,
        stage: 'MÜŞTERİYE SUNULACAK',
        status: 'active',
        notes: '',
        followDate: '',
        alternatives: [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
    }
  }, [initialQuote, isOpen]);

  if (!isOpen) return null;

  const handleAddAlternative = () => {
    if (!altPremium || Number(altPremium) <= 0) return;
    const newAlt: AlternativeQuote = {
      company: altCompany,
      premium: Number(altPremium),
      notes: altNotes.trim() || undefined,
    };
    setFormData((prev) => ({
      ...prev,
      alternatives: [...(prev.alternatives || []), newAlt],
    }));
    setAltPremium('');
    setAltNotes('');
  };

  const handleRemoveAlternative = (idx: number) => {
    setFormData((prev) => ({
      ...prev,
      alternatives: (prev.alternatives || []).filter((_, i) => i !== idx),
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.insured?.trim()) return;

    const finalQuote: Quote = {
      id: initialQuote?.id || formData.id || generateId(),
      type: 'quote',
      insured: formData.insured.trim(),
      businessType: (formData.businessType as BusinessType) || 'Yenileme',
      phone: formData.phone?.trim() || '',
      email: formData.email?.trim() || '',
      plate: formData.plate?.trim().toLocaleUpperCase('tr-TR').replace(/[ .-]/g, '') || '',
      licenseSerialNo: formData.licenseSerialNo?.trim().toLocaleUpperCase('tr-TR') || '',
      chassisNo: formData.chassisNo?.trim().toLocaleUpperCase('tr-TR') || '',
      engineNo: formData.engineNo?.trim().toLocaleUpperCase('tr-TR') || '',
      usageStyle: formData.usageStyle?.trim() || '',
      vehicleBrand: formData.vehicleBrand?.trim() || '',
      vehicleModel: formData.vehicleModel?.trim() || '',
      vehicleYear: formData.vehicleYear ? Number(formData.vehicleYear) : undefined,
      vehicleCode: formData.vehicleCode?.trim() || '',
      fuelType: formData.fuelType?.trim() || '',
      vehicleValue: formData.vehicleValue !== undefined && !isNaN(Number(formData.vehicleValue)) ? Number(formData.vehicleValue) : undefined,
      vehicleDetail: formData.vehicleDetail?.trim() || '',
      company: formData.company || COMPANIES[0],
      branch: formData.branch || 'Kasko',
      quoteNumber: formData.quoteNumber?.trim() || 'TK-' + Math.floor(1000 + Math.random() * 9000),
      quoteDate: formData.quoteDate || getTodayIso(),
      validUntil: formData.validUntil || addDays(15),
      premium: Number(formData.premium) || 0,
      stage: normalizeQuoteStage(formData.stage),
      status: formData.quoteStatus === 'reddedildi' ? 'concluded' : (initialQuote?.status || 'active'),
      quoteStatus: formData.quoteStatus || initialQuote?.quoteStatus || 'beklemede',
      outcome: formData.quoteStatus === 'reddedildi' ? 'rejected' : initialQuote?.outcome,
      convertedPolicyId: initialQuote?.convertedPolicyId,
      resultDate: formData.quoteStatus === 'reddedildi' ? (initialQuote?.resultDate || new Date().toISOString().split('T')[0]) : initialQuote?.resultDate,
      rejectionReason: formData.quoteStatus === 'reddedildi' ? (formData.nonConversionReason || formData.rejectionReason || NON_CONVERSION_REASONS[0]) : (initialQuote?.outcome === 'converted' ? undefined : initialQuote?.rejectionReason),
      nonConversionReason: formData.quoteStatus === 'reddedildi' ? (formData.nonConversionReason || formData.rejectionReason || NON_CONVERSION_REASONS[0]) : (initialQuote?.outcome === 'converted' ? undefined : initialQuote?.nonConversionReason),
      rejectionNote: initialQuote?.rejectionNote,
      progressLogs: initialQuote?.progressLogs || [
        {
          id: generateId(),
          stage: normalizeQuoteStage(formData.stage),
          status: formData.quoteStatus || 'beklemede',
          timestamp: new Date().toISOString(),
          note: 'Teklif sisteme kaydedildi.',
        },
      ],
      companyOffers: initialQuote?.companyOffers || formData.companyOffers,
      alternatives: formData.alternatives || [],
      notes: formData.notes?.trim() || '',
      followDate: formData.followDate || '',
      createdAt: initialQuote?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    onSave(finalQuote);
    onClose();
  };

  const isEditing = !!initialQuote;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="relative w-full max-w-3xl max-h-[92vh] overflow-y-auto bg-white rounded-2xl shadow-2xl border border-slate-200">
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 bg-white border-b border-slate-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">
                {isEditing ? 'Teklifi Düzenle' : 'Yeni Teklif Kaydı'}
              </h2>
              <p className="text-xs text-slate-500">Müşteriye sunulacak teklif ve fiyat karşılaştırmaları</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action shortcut banner for active quotes */}
        {isEditing && initialQuote?.status === 'active' && (
          <div className="mx-6 mt-4 p-3 bg-blue-50/70 border border-blue-200 rounded-xl flex items-center justify-between flex-wrap gap-2">
            <div className="text-xs text-blue-900">
              <span className="font-semibold">Hızlı Sonuçlandırma:</span> Teklif olumlu sonuçlandıysa poliçeleştirebilir
              veya olumsuz ise arşivleyebilirsiniz.
            </div>
            <div className="flex items-center gap-2">
              {onConvertToPolicy && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onConvertToPolicy(initialQuote);
                  }}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  ⚡ Poliçeye Dönüştür (Olumlu)
                </button>
              )}
              {onConcludeNegative && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onConcludeNegative(initialQuote);
                  }}
                  className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                >
                  ❌ Yapılmadı (Olumsuz)
                </button>
              )}
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="p-6 space-y-6">
            {/* 1. Müşteri Bilgileri */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  1. Müşteri & İletişim Bilgileri
                </h3>
                <span className="text-[10px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200 font-semibold">
                  ✓ KVKK Uyumlu (TCKN / Telefon Tutulmaz)
                </span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Müşteri Adı Soyadı veya Şirket Unvanı *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.insured || ''}
                    onChange={(e) => setFormData({ ...formData, insured: e.target.value })}
                    placeholder="Örn: Ahmet Yılmaz veya ABC Mimarlık Ltd. Şti."
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    İş Türü *
                  </label>
                  <select
                    value={formData.businessType || 'Yenileme'}
                    onChange={(e) => setFormData({ ...formData, businessType: e.target.value as BusinessType })}
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none cursor-pointer"
                  >
                    {BUSINESS_TYPES.map((bt) => (
                      <option key={bt} value={bt}>
                        {bt}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="md:col-span-3">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    E-Posta Adresi <span className="text-slate-400 font-normal">(İsteğe bağlı)</span>
                  </label>
                  <input
                    type="email"
                    value={formData.email || ''}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="ornek@sirket.com"
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                  />
                </div>
              </div>
            </div>

            {/* 2. Araç & Varlık Bilgileri */}
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
                2. Araç & Varlık Bilgileri
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Araç Plakası</label>
                  <input
                    type="text"
                    value={formData.plate || ''}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        plate: e.target.value.toLocaleUpperCase('tr-TR').replace(/[ .-]/g, ''),
                      })
                    }
                    placeholder="34ABC123"
                    className="w-full px-3 py-2 text-sm font-semibold uppercase tracking-wider border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Ruhsat Belge Seri No</label>
                  <input
                    type="text"
                    value={formData.licenseSerialNo || ''}
                    onChange={(e) => setFormData({ ...formData, licenseSerialNo: e.target.value.toLocaleUpperCase('tr-TR') })}
                    placeholder="Örn: AS123456"
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Şasi No (17 Hane)</label>
                  <input
                    type="text"
                    maxLength={25}
                    value={formData.chassisNo || ''}
                    onChange={(e) => setFormData({ ...formData, chassisNo: e.target.value.toLocaleUpperCase('tr-TR') })}
                    placeholder="WVWZZZ..."
                    className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Motor No</label>
                  <input
                    type="text"
                    value={formData.engineNo || ''}
                    onChange={(e) => setFormData({ ...formData, engineNo: e.target.value.toLocaleUpperCase('tr-TR') })}
                    placeholder="CAY123..."
                    className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Araç Kullanım Tarzı
                  </label>
                  <select
                    value={formData.usageStyle || ''}
                    onChange={(e) => setFormData({ ...formData, usageStyle: e.target.value })}
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none cursor-pointer"
                  >
                    <option value="">Seçiniz</option>
                    {/* Preserve old or custom value if outside USAGE_STYLES */}
                    {formData.usageStyle && !USAGE_STYLES.includes(formData.usageStyle as any) && (
                      <option value={formData.usageStyle}>{formData.usageStyle}</option>
                    )}
                    {USAGE_STYLES.map((style) => (
                      <option key={style} value={style}>
                        {style}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Model Yılı</label>
                  <input
                    type="number"
                    min="1970"
                    max="2035"
                    value={formData.vehicleYear || ''}
                    onChange={(e) => setFormData({ ...formData, vehicleYear: e.target.value ? Number(e.target.value) : '' })}
                    placeholder="Örn: 2022"
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Araç Markası</label>
                  <input
                    type="text"
                    value={formData.vehicleBrand || ''}
                    onChange={(e) => setFormData({ ...formData, vehicleBrand: e.target.value })}
                    placeholder="Örn: Volkswagen, Renault"
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Araç Modeli</label>
                  <input
                    type="text"
                    value={formData.vehicleModel || ''}
                    onChange={(e) => setFormData({ ...formData, vehicleModel: e.target.value })}
                    placeholder="Örn: Golf 1.5 eTSI, Clio"
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Araç Kodu (TSB)</label>
                  <input
                    type="text"
                    value={formData.vehicleCode || ''}
                    onChange={(e) => setFormData({ ...formData, vehicleCode: e.target.value })}
                    placeholder="Örn: 100234"
                    className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Yakıt Türü</label>
                  <select
                    value={formData.fuelType || ''}
                    onChange={(e) => setFormData({ ...formData, fuelType: e.target.value })}
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none cursor-pointer"
                  >
                    <option value="">Seçiniz</option>
                    {formData.fuelType && !FUEL_TYPES.includes(formData.fuelType as any) && (
                      <option value={formData.fuelType}>{formData.fuelType}</option>
                    )}
                    {FUEL_TYPES.map((ft) => (
                      <option key={ft} value={ft}>
                        {ft}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Araç Kasko Bedeli (TL)</label>
                  <input
                    type="number"
                    min="0"
                    step="1000"
                    value={formData.vehicleValue !== undefined && formData.vehicleValue !== null ? formData.vehicleValue : ''}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        vehicleValue: e.target.value ? Number(e.target.value) : undefined,
                      })
                    }
                    placeholder="1.250.000"
                    className="w-full px-3 py-2 text-sm font-bold border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Varlık / Konut / Ek Detay
                  </label>
                  <input
                    type="text"
                    value={formData.vehicleDetail || ''}
                    onChange={(e) => setFormData({ ...formData, vehicleDetail: e.target.value })}
                    placeholder="Örn: 1.5 eTSI Style Paket veya Kadıköy 3+1 Daire"
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                  />
                </div>
              </div>
            </div>

            {/* 2. Teklif Detayları */}
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3 flex items-center gap-2">
                <span>2. Sigorta Şirketi & Fiyat Bilgileri</span>
              </h3>
              {formData.company && !isStandardCompany(formData.company) && (
                <div className="mb-3 p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-900 flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <strong>Standart Dışı Şirket:</strong> Bu teklifte kayıtlı olan <em>"{formData.company}"</em> 13 yetkili sigorta şirketi listesinde yer almıyor. Lütfen aşağıdaki listeden yetkili bir sigorta şirketi seçiniz.
                  </div>
                </div>
              )}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Önerilen Şirket *</label>
                  <select
                    value={formData.company}
                    onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                    className={`w-full px-3 py-2 text-sm border rounded-lg focus:ring-2 focus:ring-blue-500/20 outline-none bg-white font-medium ${
                      formData.company && !isStandardCompany(formData.company)
                        ? 'border-amber-400 bg-amber-50/40 text-amber-900'
                        : 'border-slate-300 focus:border-blue-500'
                    }`}
                  >
                    {formData.company && !isStandardCompany(formData.company) && (
                      <option value={formData.company}>
                        ⚠️ {formData.company} (Standart Dışı - Lütfen Güncelleyin)
                      </option>
                    )}
                    {COMPANIES.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Branş *</label>
                  <select
                    value={formData.branch}
                    onChange={(e) => setFormData({ ...formData, branch: e.target.value })}
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none bg-white font-medium"
                  >
                    {BRANCHES.map((b) => (
                      <option key={b} value={b}>
                        {b}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Teklif / Referans No</label>
                  <input
                    type="text"
                    value={formData.quoteNumber || ''}
                    onChange={(e) => setFormData({ ...formData, quoteNumber: e.target.value })}
                    placeholder="TK-2026-..."
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Teklif Tarihi</label>
                  <input
                    type="date"
                    value={formData.quoteDate || ''}
                    onChange={(e) => setFormData({ ...formData, quoteDate: e.target.value })}
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Son Geçerlilik Tarihi *</label>
                  <input
                    type="date"
                    required
                    value={formData.validUntil || ''}
                    onChange={(e) => setFormData({ ...formData, validUntil: e.target.value })}
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none font-medium"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Önerilen Prim (TL) *</label>
                  <div className="relative">
                    <input
                      type="number"
                      step="0.01"
                      min="0"
                      required
                      value={formData.premium || ''}
                      onChange={(e) => setFormData({ ...formData, premium: parseFloat(e.target.value) || 0 })}
                      placeholder="0.00"
                      className="w-full px-3 py-2 pl-8 text-sm font-bold text-slate-900 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                    />
                    <span className="absolute left-3 top-2.5 text-slate-400 font-bold text-xs">₺</span>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Teklif Durumu</label>
                  <select
                    value={formData.quoteStatus || 'beklemede'}
                    onChange={(e) => setFormData({ ...formData, quoteStatus: e.target.value as any })}
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none bg-white font-medium"
                  >
                    <option value="beklemede">⏳ Beklemede / Süreçte</option>
                    <option value="kabul_edildi">✅ Kabul Edildi</option>
                    <option value="reddedildi">❌ Reddedildi (Poliçeleştirilmedi)</option>
                  </select>
                </div>
                {formData.quoteStatus === 'reddedildi' && (
                  <div>
                    <label className="block text-xs font-semibold text-rose-700 mb-1">
                      Poliçeleştirmeme Nedeni *
                    </label>
                    <select
                      value={formData.nonConversionReason || formData.rejectionReason || NON_CONVERSION_REASONS[0]}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          nonConversionReason: e.target.value,
                          rejectionReason: e.target.value,
                        })
                      }
                      className="w-full px-3 py-2 text-sm border border-rose-300 rounded-lg focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 outline-none bg-rose-50/50 font-medium"
                    >
                      {NON_CONVERSION_REASONS.map((r) => (
                        <option key={r} value={r}>
                          {r}
                        </option>
                      ))}
                    </select>
                  </div>
                )}
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Teklif Aşaması</label>
                  <select
                    value={formData.stage}
                    onChange={(e) => setFormData({ ...formData, stage: e.target.value as any })}
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none bg-white font-medium"
                  >
                    {QUOTE_STAGES.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Sonraki Takip / Arama Tarihi</label>
                  <input
                    type="date"
                    value={formData.followDate || ''}
                    onChange={(e) => setFormData({ ...formData, followDate: e.target.value })}
                    className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
                  />
                </div>
              </div>
            </div>

            {/* 3. Alternatif Teklifler Karşılaştırması (Opsiyonel) */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-700">
                  Alternatif Şirket Teklifleri (Karşılaştırma)
                </span>
                <span className="text-xs text-slate-500">Müşteriye sunulan diğer seçenekler</span>
              </div>

              {formData.alternatives && formData.alternatives.length > 0 && (
                <div className="space-y-2 mb-3">
                  {formData.alternatives.map((alt, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs"
                    >
                      <div className="flex items-center gap-3">
                        <span className="font-semibold text-slate-800">{alt.company}</span>
                        <span className="font-bold text-blue-600">
                          {new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(alt.premium)}
                        </span>
                        {alt.notes && <span className="text-slate-500">({alt.notes})</span>}
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRemoveAlternative(index)}
                        className="text-slate-400 hover:text-rose-600 transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-2">
                <select
                  value={altCompany}
                  onChange={(e) => setAltCompany(e.target.value)}
                  className="px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg bg-white"
                >
                  {COMPANIES.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
                <input
                  type="number"
                  placeholder="Prim (TL)"
                  value={altPremium}
                  onChange={(e) => setAltPremium(e.target.value ? Number(e.target.value) : '')}
                  className="px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg"
                />
                <input
                  type="text"
                  placeholder="Teminat / Kapsam notu"
                  value={altNotes}
                  onChange={(e) => setAltNotes(e.target.value)}
                  className="px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg"
                />
                <button
                  type="button"
                  onClick={handleAddAlternative}
                  className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-lg text-xs font-semibold flex items-center justify-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" /> Ekle
                </button>
              </div>
            </div>

            {/* 4. Notlar */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Görüşme & Teklif Notları</label>
              <textarea
                rows={3}
                value={formData.notes || ''}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="Örn: Müşteri muafiyetli kaskoyu kabul etmedi, 4 taksit istedi. Cuma günü aranacak."
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
              />
            </div>
          </div>

          {/* Footer */}
          <div className="sticky bottom-0 flex items-center justify-between px-6 py-4 bg-slate-50 border-t border-slate-200 rounded-b-2xl">
            {isEditing && onDelete ? (
              <button
                type="button"
                onClick={() => {
                  if (confirm('Bu teklifi kalıcı olarak silmek istiyor musunuz?')) {
                    onDelete(initialQuote.id);
                    onClose();
                  }
                }}
                className="px-3.5 py-2 text-xs font-semibold text-rose-600 hover:bg-rose-50 border border-rose-200 rounded-lg transition-colors cursor-pointer"
              >
                Teklifi Sil
              </button>
            ) : (
              <div />
            )}

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors cursor-pointer"
              >
                İptal
              </button>
              <button
                type="submit"
                className="px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm transition-colors cursor-pointer"
              >
                {isEditing ? 'Teklifi Güncelle' : 'Teklifi Kaydet'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
