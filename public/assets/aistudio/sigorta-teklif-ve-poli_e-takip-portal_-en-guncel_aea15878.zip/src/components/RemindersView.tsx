import React, { useState, useEffect, useMemo } from 'react';
import { Quote, Policy, BusinessType } from '../types/insurance';
import { calculateDaysLeft, formatCurrency, formatDateTr } from '../services/storage';
import {
  Bell,
  AlertTriangle,
  Clock,
  Calendar,
  CheckCircle2,
  Phone,
  Shield,
  FileText,
  Search,
  Filter,
  Sparkles,
  RefreshCw,
  Tag,
} from 'lucide-react';

interface Props {
  quotes: Quote[];
  policies: Policy[];
  reminderDays: number[];
  onViewQuote: (quote: Quote) => void;
  onViewPolicy: (policy: Policy) => void;
  onConvertToPolicy: (quote: Quote) => void;
  initialFilter?: 'all' | 'urgent';
}

export type ReminderBusinessTypeFilter = 'all' | 'Yenileme' | 'Yeni İş' | 'Belirtilmemiş';

export const RemindersView: React.FC<Props> = ({
  quotes,
  policies,
  reminderDays,
  onViewQuote,
  onViewPolicy,
  onConvertToPolicy,
  initialFilter = 'all',
}) => {
  const [businessTypeFilter, setBusinessTypeFilter] = useState<ReminderBusinessTypeFilter>('all');
  const [urgentOnly, setUrgentOnly] = useState<boolean>(initialFilter === 'urgent');
  const [search, setSearch] = useState('');

  // Sync with initialFilter if changed from navigation
  useEffect(() => {
    if (initialFilter === 'urgent') {
      setUrgentOnly(true);
    } else if (initialFilter === 'all') {
      setUrgentOnly(false);
    }
  }, [initialFilter]);

  // Normalize plate for reliable matching (e.g. "34 ABC 12" -> "34ABC12")
  const cleanPlate = (pl?: string) => (pl ? pl.replace(/\s+/g, '').toLocaleUpperCase('tr-TR') : '');

  // Helper to determine if a policy's renewal has already been completed for this period
  const isPolicyRenewalCompleted = (policy: Policy, allPolicies: Policy[]): boolean => {
    // 1. Explicitly concluded, cancelled or renewed status
    if (
      policy.status === 'Sonuçlandı' ||
      policy.status === 'İptal' ||
      policy.outcome === 'completed' ||
      policy.outcome === 'renewed' ||
      policy.outcome === 'cancelled'
    ) {
      return true;
    }

    // 2. Check if a newer policy exists for the same target asset (plate or insured + branch)
    const currentPlate = cleanPlate(policy.plate);
    const currentInsured = policy.insured.trim().toLocaleLowerCase('tr-TR');
    const currentBranch = policy.branch.trim().toLocaleLowerCase('tr-TR');
    const currentEndDate = policy.endDate ? new Date(policy.endDate).getTime() : 0;

    const hasSubsequentPolicy = allPolicies.some((other) => {
      if (other.id === policy.id) return false;
      if (other.status === 'İptal') return false;

      const otherPlate = cleanPlate(other.plate);
      const otherInsured = other.insured.trim().toLocaleLowerCase('tr-TR');
      const otherBranch = other.branch.trim().toLocaleLowerCase('tr-TR');
      const otherEndDate = other.endDate ? new Date(other.endDate).getTime() : 0;

      const isSameTarget = currentPlate && otherPlate
        ? currentPlate === otherPlate
        : currentInsured === otherInsured && currentBranch === otherBranch;

      if (!isSameTarget) return false;

      // If the other policy has a later end date, the renewal for this period was completed!
      return otherEndDate > currentEndDate;
    });

    return hasSubsequentPolicy;
  };

  // Helper to determine business type for policy
  // Portfolio policies due for renewal are inherently 'Yenileme' unless specified
  const getPolicyBusinessType = (p: Policy): 'Yenileme' | 'Yeni İş' | 'Belirtilmemiş' => {
    const raw = (p as any).businessType;
    if (raw === 'Yeni İş') return 'Yeni İş';
    if (raw === 'Yenileme') return 'Yenileme';
    return 'Yenileme'; // Standart acente kuralı: portföy poliçeleri yenileme takibindedir
  };

  // Helper to determine business type for quote
  const getQuoteBusinessType = (q: Quote): 'Yenileme' | 'Yeni İş' | 'Belirtilmemiş' => {
    if (q.businessType === 'Yenileme') return 'Yenileme';
    if (q.businessType === 'Yeni İş') return 'Yeni İş';
    return 'Belirtilmemiş';
  };

  // Base Reminders for policies:
  // - Exclude concluded and already renewed policies
  // - Overdue (days < 0) or ending within 14 days OR matching reminderDays
  // - Deduplicate identical records
  const rawPolicyReminders = useMemo(() => {
    const eligible = policies.filter((p) => !isPolicyRenewalCompleted(p, policies));

    const duePolicies = eligible.filter((p) => {
      const days = calculateDaysLeft(p.endDate);
      if (days === null) return false;
      return days < 0 || days <= 14 || reminderDays.includes(days);
    });

    const seen = new Set<string>();
    const deduplicated: Policy[] = [];
    for (const p of duePolicies) {
      const pPlate = cleanPlate(p.plate);
      const key = pPlate
        ? `${pPlate}-${p.branch.trim().toLowerCase()}`
        : `${p.insured.trim().toLowerCase()}-${p.branch.trim().toLowerCase()}-${p.policyNumber}`;
      if (!seen.has(key)) {
        seen.add(key);
        deduplicated.push(p);
      }
    }

    return deduplicated.sort(
      (a, b) => (calculateDaysLeft(a.endDate) ?? 9999) - (calculateDaysLeft(b.endDate) ?? 9999)
    );
  }, [policies, reminderDays]);

  // Base Reminders for quotes:
  // - Active quotes only (not concluded or converted)
  // - Expiring within 5 days OR has followDate matching today/past
  const rawQuoteReminders = useMemo(() => {
    return quotes
      .filter((q) => {
        if (q.status !== 'active' || q.outcome === 'converted' || q.outcome === 'rejected') {
          return false;
        }
        const days = calculateDaysLeft(q.validUntil);
        const followDays = calculateDaysLeft(q.followDate);
        return (days !== null && days <= 5) || (followDays !== null && followDays <= 1);
      })
      .sort((a, b) => (calculateDaysLeft(a.validUntil) ?? 9999) - (calculateDaysLeft(b.validUntil) ?? 9999));
  }, [quotes]);

  // Global counts across all reminders for KPI cards
  const totalYenilemeCount = useMemo(() => {
    const polYenileme = rawPolicyReminders.filter((p) => getPolicyBusinessType(p) === 'Yenileme').length;
    const quoteYenileme = rawQuoteReminders.filter((q) => getQuoteBusinessType(q) === 'Yenileme').length;
    return polYenileme + quoteYenileme;
  }, [rawPolicyReminders, rawQuoteReminders]);

  const totalYeniIsCount = useMemo(() => {
    const polYeni = rawPolicyReminders.filter((p) => getPolicyBusinessType(p) === 'Yeni İş').length;
    const quoteYeni = rawQuoteReminders.filter((q) => getQuoteBusinessType(q) === 'Yeni İş').length;
    return polYeni + quoteYeni;
  }, [rawPolicyReminders, rawQuoteReminders]);

  const totalUnspecifiedCount = useMemo(() => {
    const polUnspec = rawPolicyReminders.filter((p) => getPolicyBusinessType(p) === 'Belirtilmemiş').length;
    const quoteUnspec = rawQuoteReminders.filter((q) => getQuoteBusinessType(q) === 'Belirtilmemiş').length;
    return polUnspec + quoteUnspec;
  }, [rawPolicyReminders, rawQuoteReminders]);

  const totalUrgentCount = useMemo(() => {
    const polUrgent = rawPolicyReminders.filter((p) => {
      const d = calculateDaysLeft(p.endDate);
      return d !== null && d <= 14;
    }).length;
    const quoteUrgent = rawQuoteReminders.filter((q) => {
      const d = calculateDaysLeft(q.validUntil);
      return d !== null && d <= 3;
    }).length;
    return polUrgent + quoteUrgent;
  }, [rawPolicyReminders, rawQuoteReminders]);

  // Filtered Policies
  const filteredPolicies = useMemo(() => {
    const q = search.toLocaleLowerCase('tr-TR').trim();

    return rawPolicyReminders.filter((p) => {
      const bType = getPolicyBusinessType(p);

      // Business Type Filter
      if (businessTypeFilter !== 'all' && bType !== businessTypeFilter) {
        return false;
      }

      // Urgent Only Filter (<= 14 days or overdue)
      if (urgentOnly) {
        const days = calculateDaysLeft(p.endDate);
        if (days === null || days > 14) return false;
      }

      // Search Filter
      if (q) {
        const matches =
          p.insured.toLocaleLowerCase('tr-TR').includes(q) ||
          (p.plate && p.plate.toLocaleLowerCase('tr-TR').includes(q)) ||
          p.company.toLocaleLowerCase('tr-TR').includes(q) ||
          p.branch.toLocaleLowerCase('tr-TR').includes(q) ||
          (p.phone && p.phone.includes(q));
        if (!matches) return false;
      }

      return true;
    });
  }, [rawPolicyReminders, businessTypeFilter, urgentOnly, search]);

  // Filtered Quotes
  const filteredQuotes = useMemo(() => {
    const q = search.toLocaleLowerCase('tr-TR').trim();

    return rawQuoteReminders.filter((quote) => {
      const bType = getQuoteBusinessType(quote);

      // Business Type Filter
      if (businessTypeFilter !== 'all' && bType !== businessTypeFilter) {
        return false;
      }

      // Urgent Only Filter (<= 3 days or overdue)
      if (urgentOnly) {
        const days = calculateDaysLeft(quote.validUntil);
        const followDays = calculateDaysLeft(quote.followDate);
        const isUrgent = (days !== null && days <= 3) || (followDays !== null && followDays <= 0);
        if (!isUrgent) return false;
      }

      // Search Filter
      if (q) {
        const matches =
          quote.insured.toLocaleLowerCase('tr-TR').includes(q) ||
          (quote.plate && quote.plate.toLocaleLowerCase('tr-TR').includes(q)) ||
          quote.company.toLocaleLowerCase('tr-TR').includes(q) ||
          quote.branch.toLocaleLowerCase('tr-TR').includes(q) ||
          (quote.phone && quote.phone.includes(q)) ||
          (quote.stage && quote.stage.toLocaleLowerCase('tr-TR').includes(q));
        if (!matches) return false;
      }

      return true;
    });
  }, [rawQuoteReminders, businessTypeFilter, urgentOnly, search]);

  const totalFilteredCount = filteredPolicies.length + filteredQuotes.length;

  return (
    <div className="space-y-6">
      {/* Header & Status Indicator */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
              <Bell className="w-6 h-6 text-amber-600" />
              <span>Hatırlatmalar ve Takip Listesi</span>
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800">
              {totalFilteredCount} Kayıt
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Yenileme ve yeni iş süreçleri, bitişi yaklaşan poliçeler ve karar bekleyen teklifler.
          </p>
        </div>
        <div className="text-xs text-slate-600 bg-amber-50 border border-amber-200 px-3 py-1.5 rounded-xl font-medium flex items-center gap-2">
          <Clock className="w-4 h-4 text-amber-600" />
          <span>Takip Kuralı: Bitişe {reminderDays.join(', ')} gün kala</span>
        </div>
      </div>

      {/* KPI Cards: İş Türü & Acillik Özeti */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* Card 1: Toplam */}
        <div
          onClick={() => {
            setBusinessTypeFilter('all');
            setUrgentOnly(false);
          }}
          className={`p-4 rounded-2xl border transition-all cursor-pointer shadow-2xs ${
            businessTypeFilter === 'all' && !urgentOnly
              ? 'bg-slate-900 text-white border-slate-900'
              : 'bg-white border-slate-200 hover:border-slate-400'
          }`}
        >
          <div className="flex items-center justify-between text-xs font-semibold">
            <span className={businessTypeFilter === 'all' && !urgentOnly ? 'text-slate-200' : 'text-slate-500'}>
              Tüm Hatırlatmalar
            </span>
            <Bell className={`w-4 h-4 ${businessTypeFilter === 'all' && !urgentOnly ? 'text-slate-200' : 'text-slate-400'}`} />
          </div>
          <div className="text-2xl font-black mt-2">{rawPolicyReminders.length + rawQuoteReminders.length}</div>
          <div className={`text-xs mt-0.5 ${businessTypeFilter === 'all' && !urgentOnly ? 'text-slate-300' : 'text-slate-400'}`}>
            Poliçe & Teklif Takibi
          </div>
        </div>

        {/* Card 2: Yenileme */}
        <div
          onClick={() => setBusinessTypeFilter(businessTypeFilter === 'Yenileme' ? 'all' : 'Yenileme')}
          className={`p-4 rounded-2xl border transition-all cursor-pointer shadow-2xs ${
            businessTypeFilter === 'Yenileme'
              ? 'bg-indigo-50/80 border-indigo-400 ring-2 ring-indigo-500/20'
              : 'bg-white border-slate-200 hover:border-indigo-300'
          }`}
        >
          <div className="flex items-center justify-between text-indigo-900 text-xs font-semibold">
            <span className="flex items-center gap-1.5">
              <RefreshCw className="w-4 h-4 text-indigo-600" />
              <span>Yenileme İşleri</span>
            </span>
            <span className="text-[10px] font-bold uppercase tracking-wider bg-indigo-100 text-indigo-800 px-1.5 py-0.2 rounded">
              Yenileme
            </span>
          </div>
          <div className="text-2xl font-black text-indigo-950 mt-2">{totalYenilemeCount}</div>
          <div className="text-xs text-indigo-700 font-medium mt-0.5">Vadesi gelen portföy</div>
        </div>

        {/* Card 3: Yeni İş */}
        <div
          onClick={() => setBusinessTypeFilter(businessTypeFilter === 'Yeni İş' ? 'all' : 'Yeni İş')}
          className={`p-4 rounded-2xl border transition-all cursor-pointer shadow-2xs ${
            businessTypeFilter === 'Yeni İş'
              ? 'bg-emerald-50/80 border-emerald-400 ring-2 ring-emerald-500/20'
              : 'bg-white border-slate-200 hover:border-emerald-300'
          }`}
        >
          <div className="flex items-center justify-between text-emerald-900 text-xs font-semibold">
            <span className="flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-emerald-600" />
              <span>Yeni İşler</span>
            </span>
            <span className="text-[10px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800 px-1.5 py-0.2 rounded">
              Yeni İş
            </span>
          </div>
          <div className="text-2xl font-black text-emerald-950 mt-2">{totalYeniIsCount}</div>
          <div className="text-xs text-emerald-700 font-medium mt-0.5">İlk tanzim / yeni müşteri</div>
        </div>

        {/* Card 4: Acil & Gecikmiş */}
        <div
          onClick={() => setUrgentOnly(!urgentOnly)}
          className={`p-4 rounded-2xl border transition-all cursor-pointer shadow-2xs ${
            urgentOnly
              ? 'bg-amber-50/90 border-amber-500 ring-2 ring-amber-500/20'
              : 'bg-white border-slate-200 hover:border-amber-300'
          }`}
        >
          <div className="flex items-center justify-between text-amber-900 text-xs font-semibold">
            <span className="flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              <span>Acil / Gecikmiş</span>
            </span>
            <span className="text-[10px] font-bold bg-amber-100 text-amber-800 px-1.5 py-0.2 rounded">
              ≤ 14 Gün
            </span>
          </div>
          <div className="text-2xl font-black text-amber-950 mt-2">{totalUrgentCount}</div>
          <div className="text-xs text-amber-700 font-medium mt-0.5">Öncelikli müdahale</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs space-y-3.5">
        {/* İş Türü & Acillik Butonları */}
        <div className="flex flex-wrap items-center justify-between gap-3 pb-2 border-b border-slate-100">
          <div className="flex items-center gap-2 overflow-x-auto">
            <span className="text-xs font-bold text-slate-500 flex items-center gap-1 mr-1">
              <Tag className="w-3.5 h-3.5" />
              <span>İş Türü:</span>
            </span>

            <button
              onClick={() => setBusinessTypeFilter('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer shrink-0 ${
                businessTypeFilter === 'all'
                  ? 'bg-slate-900 text-white shadow-2xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              Tümü ({rawPolicyReminders.length + rawQuoteReminders.length})
            </button>

            <button
              onClick={() => setBusinessTypeFilter('Yenileme')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 ${
                businessTypeFilter === 'Yenileme'
                  ? 'bg-indigo-600 text-white shadow-2xs'
                  : 'text-indigo-700 bg-indigo-50 hover:bg-indigo-100'
              }`}
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Yenileme ({totalYenilemeCount})</span>
            </button>

            <button
              onClick={() => setBusinessTypeFilter('Yeni İş')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 ${
                businessTypeFilter === 'Yeni İş'
                  ? 'bg-emerald-600 text-white shadow-2xs'
                  : 'text-emerald-700 bg-emerald-50 hover:bg-emerald-100'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Yeni İş ({totalYeniIsCount})</span>
            </button>

            {totalUnspecifiedCount > 0 && (
              <button
                onClick={() => setBusinessTypeFilter('Belirtilmemiş')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shrink-0 ${
                  businessTypeFilter === 'Belirtilmemiş'
                    ? 'bg-slate-600 text-white shadow-2xs'
                    : 'text-slate-600 bg-slate-100 hover:bg-slate-200'
                }`}
              >
                <span>Belirtilmemiş ({totalUnspecifiedCount})</span>
              </button>
            )}
          </div>

          {/* Acil Yenileme Filtresi Toggle */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setUrgentOnly(!urgentOnly)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                urgentOnly
                  ? 'bg-amber-600 text-white ring-2 ring-amber-400/30 shadow-2xs'
                  : 'bg-amber-50 text-amber-800 hover:bg-amber-100 border border-amber-200'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Yalnızca Acil Yenilemeler (≤ 14 Gün)</span>
              {urgentOnly && <span className="ml-1 text-[11px] bg-white/20 px-1.5 rounded">Aktif</span>}
            </button>
          </div>
        </div>

        {/* Search input & reset */}
        <div className="flex flex-col sm:flex-row gap-3 pt-1">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Sigortalı adı, plaka, şirket veya branş ara..."
              className="w-full pl-9 pr-4 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-slate-500/20 focus:border-slate-500 outline-none"
            />
            {search && (
              <button
                onClick={() => setSearch('')}
                className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            )}
          </div>

          {(search || businessTypeFilter !== 'all' || urgentOnly) && (
            <button
              onClick={() => {
                setSearch('');
                setBusinessTypeFilter('all');
                setUrgentOnly(false);
              }}
              className="px-3.5 py-2 text-xs font-semibold text-rose-600 hover:bg-rose-50 rounded-xl transition-colors cursor-pointer self-start sm:self-auto"
            >
              Filtreleri Temizle
            </button>
          )}
        </div>
      </div>

      {/* Two Column Layout: Policies & Quotes */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Section 1: Poliçe Yenileme Hatırlatmaları */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-5 flex flex-col">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-indigo-600" />
              <h2 className="text-sm font-bold text-slate-900">
                Poliçe Yenileme Listesi ({filteredPolicies.length})
              </h2>
            </div>
            <span className="text-xs text-slate-400">Bitiş Tarihine Göre</span>
          </div>

          <div className="divide-y divide-slate-100 flex-1 space-y-1">
            {filteredPolicies.length > 0 ? (
              filteredPolicies.map((p) => {
                const days = calculateDaysLeft(p.endDate);
                const isOverdue = days !== null && days < 0;
                const isUrgent = days !== null && days >= 0 && days <= 7;
                const bType = getPolicyBusinessType(p);

                return (
                  <div key={p.id} className="py-3.5 flex items-center justify-between gap-3 text-xs hover:bg-slate-50/60 rounded-xl px-2 -mx-2 transition-colors">
                    <div>
                      <div className="font-bold text-slate-900 flex items-center gap-2 flex-wrap">
                        <span>{p.insured}</span>
                        {p.plate && (
                          <span className="px-1.5 py-0.5 rounded bg-slate-100 font-mono text-[11px] font-semibold text-slate-700">
                            {p.plate}
                          </span>
                        )}
                        <span
                          className={`text-[10px] font-bold px-1.5 py-0.2 rounded border ${
                            bType === 'Yenileme'
                              ? 'bg-indigo-50 text-indigo-700 border-indigo-200'
                              : bType === 'Yeni İş'
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                              : 'bg-slate-100 text-slate-600 border-slate-200'
                          }`}
                        >
                          {bType === 'Yenileme' ? '🔄 Yenileme' : bType === 'Yeni İş' ? '✨ Yeni İş' : 'Belirtilmemiş'}
                        </span>
                      </div>
                      <div className="text-slate-500 mt-1">
                        <strong className="text-slate-700">{p.company}</strong> · {p.branch} · Prim: {formatCurrency(p.premium)}
                      </div>
                      {p.phone && (
                        <div className="text-slate-400 text-[11px] flex items-center gap-1 mt-0.5">
                          <Phone className="w-3 h-3" />
                          <span>{p.phone}</span>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <div className="text-right">
                        <span
                          className={`inline-block px-2 py-0.5 rounded-full text-xs font-bold ${
                            isOverdue
                              ? 'bg-rose-50 text-rose-700 border border-rose-200'
                              : isUrgent
                              ? 'bg-amber-50 text-amber-700 border border-amber-200'
                              : 'bg-blue-50 text-blue-700 border border-blue-200'
                          }`}
                        >
                          {days !== null && days < 0
                            ? `${Math.abs(days)} gün gecikti`
                            : days === 0
                            ? 'Bugün!'
                            : `${days} gün kaldı`}
                        </span>
                        <div className="text-[11px] text-slate-400 mt-1">{formatDateTr(p.endDate)}</div>
                      </div>
                      <button
                        onClick={() => onViewPolicy(p)}
                        className="px-2.5 py-1 text-slate-700 hover:bg-slate-100 border border-slate-200 rounded-lg font-semibold cursor-pointer"
                      >
                        Aç
                      </button>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="py-12 text-center text-xs text-slate-400">
                Seçilen filtrelere uygun poliçe hatırlatması bulunmuyor.
              </div>
            )}
          </div>
        </div>

        {/* Section 2: Teklif Takip & Geçerlilik Hatırlatmaları */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-5 flex flex-col">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-blue-600" />
              <h2 className="text-sm font-bold text-slate-900">
                Teklif Takip ve Arama Listesi ({filteredQuotes.length})
              </h2>
            </div>
            <span className="text-xs text-slate-400">Karar Bekleyenler</span>
          </div>

          <div className="divide-y divide-slate-100 flex-1 space-y-1">
            {filteredQuotes.length > 0 ? (
              filteredQuotes.map((q) => {
                const days = calculateDaysLeft(q.validUntil);
                const isOverdue = days !== null && days < 0;
                const bType = getQuoteBusinessType(q);

                return (
                  <div key={q.id} className="py-3.5 flex items-center justify-between gap-3 text-xs hover:bg-slate-50/60 rounded-xl px-2 -mx-2 transition-colors">
                    <div>
                      <div className="font-bold text-slate-900 flex items-center gap-2 flex-wrap">
                        <span>{q.insured}</span>
                        {q.plate && (
                          <span className="px-1.5 py-0.5 rounded bg-slate-100 font-mono text-[11px] font-semibold text-slate-700">
                            {q.plate}
                          </span>
                        )}
                        <span
                          className={`text-[10px] font-bold px-1.5 py-0.2 rounded border ${
                            bType === 'Yenileme'
                              ? 'bg-indigo-50 text-indigo-700 border-indigo-200'
                              : bType === 'Yeni İş'
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                              : 'bg-slate-100 text-slate-600 border-slate-200'
                          }`}
                        >
                          {bType === 'Yenileme' ? '🔄 Yenileme' : bType === 'Yeni İş' ? '✨ Yeni İş' : 'Belirtilmemiş'}
                        </span>
                      </div>
                      <div className="text-slate-500 mt-1">
                        <strong className="text-slate-700">{q.company}</strong> · {q.branch} · Prim: {formatCurrency(q.premium)}
                      </div>
                      <div className="text-blue-600 font-medium text-[11px] mt-0.5">Aşama: {q.stage}</div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <div className="text-right">
                        <span
                          className={`inline-block px-2 py-0.5 rounded-full text-xs font-bold ${
                            isOverdue
                              ? 'bg-rose-50 text-rose-700 border border-rose-200'
                              : 'bg-amber-50 text-amber-700 border border-amber-200'
                          }`}
                        >
                          {days !== null && days < 0
                            ? 'Süre doldu'
                            : days === 0
                            ? 'Son gün!'
                            : `${days} gün kaldı`}
                        </span>
                        <div className="text-[11px] text-slate-400 mt-1">{formatDateTr(q.validUntil)}</div>
                      </div>
                      <button
                        onClick={() => onViewQuote(q)}
                        className="px-2.5 py-1 text-slate-700 hover:bg-slate-100 border border-slate-200 rounded-lg font-semibold cursor-pointer"
                      >
                        Aç
                      </button>
                      <button
                        onClick={() => onConvertToPolicy(q)}
                        className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold shadow-2xs cursor-pointer"
                      >
                        Poliçeleştir
                      </button>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="py-12 text-center text-xs text-slate-400">
                Seçilen filtrelere uygun teklif takip kaydı bulunmuyor.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
