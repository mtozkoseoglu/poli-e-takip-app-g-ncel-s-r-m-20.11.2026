import React from 'react';
import { Quote, Policy } from '../types/insurance';
import { calculateDaysLeft, formatCurrency, formatDateTr } from '../services/storage';
import {
  FileText,
  Shield,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Plus,
  ArrowRight,
  TrendingUp,
  RefreshCw,
} from 'lucide-react';

interface Props {
  quotes: Quote[];
  policies: Policy[];
  onOpenNewQuote: () => void;
  onOpenNewPolicy: () => void;
  onViewQuote: (quote: Quote) => void;
  onViewPolicy: (policy: Policy) => void;
  onConvertToPolicy: (quote: Quote) => void;
  onNavigateTab: (tab: 'dashboard' | 'quotes' | 'policies' | 'concluded' | 'reminders', filterOption?: string) => void;
}

export const DashboardView: React.FC<Props> = ({
  quotes,
  policies,
  onOpenNewQuote,
  onOpenNewPolicy,
  onViewQuote,
  onViewPolicy,
  onConvertToPolicy,
  onNavigateTab,
}) => {
  const activeQuotes = quotes.filter((q) => q.status === 'active');
  const activePolicies = policies.filter((p) => p.status !== 'Sonuçlandı' && p.status !== 'İptal');
  const concludedQuotes = quotes.filter((q) => q.status === 'concluded');
  const convertedCount = concludedQuotes.filter((q) => q.outcome === 'converted').length;
  const totalConcludedQuotes = concludedQuotes.length;
  const conversionRate = totalConcludedQuotes > 0 ? Math.round((convertedCount / totalConcludedQuotes) * 100) : 0;

  // Urgent policies (<= 14 days or overdue)
  const urgentPolicies = activePolicies
    .filter((p) => calculateDaysLeft(p.endDate) !== null)
    .sort((a, b) => (calculateDaysLeft(a.endDate) ?? 9999) - (calculateDaysLeft(b.endDate) ?? 9999))
    .slice(0, 5);

  // Active quotes sorted by urgency
  const recentQuotes = activeQuotes
    .sort((a, b) => (calculateDaysLeft(a.validUntil) ?? 9999) - (calculateDaysLeft(b.validUntil) ?? 9999))
    .slice(0, 5);

  const overduePoliciesCount = activePolicies.filter((p) => {
    const d = calculateDaysLeft(p.endDate);
    return d !== null && d < 0;
  }).length;

  const next14DaysCount = activePolicies.filter((p) => {
    const d = calculateDaysLeft(p.endDate);
    return d !== null && d >= 0 && d <= 14;
  }).length;

  const totalPortfolioPremium = activePolicies.reduce((acc, curr) => acc + (curr.premium || 0), 0);
  const totalQuotesPremium = activeQuotes.reduce((acc, curr) => acc + (curr.premium || 0), 0);

  return (
    <div className="space-y-6">
      {/* Welcome & Top Action Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-6 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl shadow-sm">
        <div>
          <span className="text-[11px] font-bold tracking-widest text-indigo-300 uppercase">
            Acente Yönetim Paneli
          </span>
          <h1 className="text-2xl font-black tracking-tight mt-0.5">Teklif ve Poliçe Takip Portalı</h1>
          <p className="text-xs text-slate-300 mt-1 max-w-xl">
            Teklif hazırlayın, olumlu teklifleri tek tıkla poliçeleştirin ve sonuçlanan tüm işlerinizi analiz edin.
          </p>
        </div>
        <div className="flex items-center gap-2.5 w-full sm:w-auto">
          <button
            onClick={onOpenNewQuote}
            className="flex-1 sm:flex-none px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold rounded-xl shadow-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>＋ Yeni Teklif</span>
          </button>
          <button
            onClick={onOpenNewPolicy}
            className="flex-1 sm:flex-none px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>＋ Yeni Poliçe</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* Card 1: Teklifler */}
        <div
          onClick={() => onNavigateTab('quotes')}
          className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs hover:border-blue-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span className="flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-blue-600" />
              <span>Aktif Teklifler</span>
            </span>
            <span className="text-[11px] text-blue-600 font-bold group-hover:translate-x-0.5 transition-transform">
              Tümü →
            </span>
          </div>
          <div className="text-2xl font-black text-slate-900 mt-2">{activeQuotes.length}</div>
          <div className="text-xs text-slate-500 mt-0.5">
            Potansiyel: <strong className="text-slate-800">{formatCurrency(totalQuotesPremium)}</strong>
          </div>
        </div>

        {/* Card 2: Sonuçlananlar (Poliçeleşenler) */}
        <div
          onClick={() => onNavigateTab('concluded', 'converted')}
          className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs hover:border-indigo-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span className="flex items-center gap-1.5">
              <Shield className="w-4 h-4 text-indigo-600" />
              <span>Sonuçlananlar</span>
            </span>
            <span className="text-[11px] text-indigo-600 font-bold group-hover:translate-x-0.5 transition-transform">
              Poliçeler →
            </span>
          </div>
          <div className="text-2xl font-black text-slate-900 mt-2">{activePolicies.length}</div>
          <div className="text-xs text-slate-500 mt-0.5">
            Poliçeleşen Portföy: <strong className="text-slate-800">{formatCurrency(totalPortfolioPremium)}</strong>
          </div>
        </div>

        {/* Card 3: Yaklaşan / Acil Yenilemeler */}
        <div
          onClick={() => onNavigateTab('reminders', 'urgent')}
          className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs hover:border-amber-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span className="flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-amber-600" />
              <span>Acil Yenilemeler</span>
            </span>
            {overduePoliciesCount > 0 ? (
              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-700">
                {overduePoliciesCount} Gecikmiş
              </span>
            ) : (
              <span className="text-[11px] text-amber-600 font-bold group-hover:translate-x-0.5 transition-transform">
                Git →
              </span>
            )}
          </div>
          <div className="text-2xl font-black text-amber-700 mt-2">{next14DaysCount + overduePoliciesCount}</div>
          <div className="text-xs text-slate-500 mt-0.5">14 gün içi ve gecikmişler</div>
        </div>

        {/* Card 4: Sonuçlananlar & Dönüşüm */}
        <div
          onClick={() => onNavigateTab('concluded')}
          className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs hover:border-emerald-300 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Sonuçlananlar</span>
            </span>
            <span className="text-[11px] text-emerald-600 font-bold group-hover:translate-x-0.5 transition-transform">
              İncele →
            </span>
          </div>
          <div className="text-2xl font-black text-emerald-700 mt-2">%{conversionRate} Başarı</div>
          <div className="text-xs text-slate-500 mt-0.5">
            {convertedCount} teklif poliçeleştirildi
          </div>
        </div>
      </div>

      {/* Two Columns: Urgent Policies & Active Quotes */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Column 1: Yaklaşan & Geciken Yenilemeler */}
        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-2xs flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600" />
                <span>Öncelikli Yenilemeler</span>
              </h2>
              <p className="text-xs text-slate-500">Bitiş tarihi yaklaşan veya gecikmiş poliçeler</p>
            </div>
            <button
              onClick={() => onNavigateTab('reminders', 'urgent')}
              className="text-xs font-semibold text-amber-700 hover:text-amber-800"
            >
              Hatırlatmalar & Yenilemeler →
            </button>
          </div>

          <div className="divide-y divide-slate-100 flex-1">
            {urgentPolicies.length > 0 ? (
              urgentPolicies.map((p) => {
                const days = calculateDaysLeft(p.endDate);
                return (
                  <div key={p.id} className="py-3 flex items-center justify-between gap-3 text-xs">
                    <div>
                      <div className="font-bold text-slate-900">{p.insured}</div>
                      <div className="text-slate-500 flex items-center gap-1.5 mt-0.5">
                        {p.plate && <span className="font-mono font-semibold text-slate-700">{p.plate} ·</span>}
                        <span>
                          {p.company} / {p.branch}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2.5">
                      <div className="text-right">
                        <div
                          className={`font-bold ${
                            days !== null && days < 0
                              ? 'text-rose-600'
                              : days !== null && days <= 7
                              ? 'text-amber-600'
                              : 'text-slate-800'
                          }`}
                        >
                          {days !== null && days < 0
                            ? `${Math.abs(days)} gün gecikti`
                            : days === 0
                            ? 'Bugün bitiyor'
                            : `${days} gün kaldı`}
                        </div>
                        <div className="text-[11px] text-slate-400">{formatDateTr(p.endDate)}</div>
                      </div>
                      <button
                        onClick={() => onViewPolicy(p)}
                        className="px-2.5 py-1 text-slate-700 hover:bg-slate-100 border border-slate-200 rounded-lg text-xs font-semibold cursor-pointer"
                      >
                        Aç
                      </button>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="py-8 text-center text-xs text-slate-400">Şu an acil yenileme bulunmuyor.</div>
            )}
          </div>
        </div>

        {/* Column 2: Takipteki Teklifler */}
        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-2xs flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <FileText className="w-4 h-4 text-blue-600" />
                <span>Takipteki Teklifler</span>
              </h2>
              <p className="text-xs text-slate-500">Müşteriye sunulan ve karar beklenen teklifler</p>
            </div>
            <button
              onClick={() => onNavigateTab('quotes')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-800"
            >
              Tüm Teklifler →
            </button>
          </div>

          <div className="divide-y divide-slate-100 flex-1">
            {recentQuotes.length > 0 ? (
              recentQuotes.map((q) => {
                const days = calculateDaysLeft(q.validUntil);
                return (
                  <div key={q.id} className="py-3 flex items-center justify-between gap-3 text-xs">
                    <div>
                      <div className="font-bold text-slate-900">{q.insured}</div>
                      <div className="text-slate-500 flex items-center gap-1.5 mt-0.5">
                        <span className="font-semibold text-slate-700">{q.branch}</span>
                        <span>· {q.company}</span>
                        <span className="text-slate-400 font-mono">({q.quoteNumber || 'No yok'})</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="text-right">
                        <div className="font-black text-slate-900">{formatCurrency(q.premium)}</div>
                        <div className="text-[11px] text-blue-600 font-medium">{q.stage}</div>
                      </div>
                      <button
                        onClick={() => onConvertToPolicy(q)}
                        title="Hızlı Poliçeleştir"
                        className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-2xs cursor-pointer flex items-center gap-1"
                      >
                        <CheckCircle2 className="w-3 h-3" />
                        <span>Poliçeleştir</span>
                      </button>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="py-8 text-center text-xs text-slate-400">Şu an aktif teklif bulunmuyor.</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
